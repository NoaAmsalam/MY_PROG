﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmStudentsCourse : DriveSchool.Form1
    {
        Bll.courseActually courseActually;
        Bll.StudentCourse studentCourse;
        Bll.StudentCourseTable studentCourseTable;
        Bll.Course course;
       
        public frmStudentsCourse(Bll.courseActually c)
        {
            courseActually = c;
            InitializeComponent();
            course = courseActually.GetCourse();

            studentCourseTable = new Bll.StudentCourseTable();
            studentCourse = new Bll.StudentCourse();
            //dataGridView1.DataSource = studentCourseTable.GetList();
            int i = studentCourseTable.GetList().Where(x => x.CourseActuallyId == courseActually.CourseActuallyaId).Count();
            dataGridView1.DataSource = studentCourseTable.GetList().Where(x => x.CourseActuallyId == courseActually.CourseActuallyaId).Select(x => new {  v = x.GetStudent().ToString()}).ToList();
            label4.Text = course.CourseName;
            label5.Text = i.ToString();
            label6.Text = ((course.StudentMax) - i).ToString();
            if(course.StudentMin>i)
            {
                textBox1.BackColor = Color.Red;
                textBox1.Text = "הקורס לא ייפתח";
            }
            else
            {
                textBox1.BackColor = Color.LightGreen;
                textBox1.Text = "הקורס  ייפתח";
            }
            ChangeHeaders();


        
        }
        public void ChangeHeaders()
        {
            dataGridView1.Columns["v"].HeaderText = "שם תלמיד";
           


        }
        private void frmStudentsCourse_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
