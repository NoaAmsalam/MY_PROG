﻿namespace DriveSchool.Gui
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCity = new System.Windows.Forms.Button();
            this.btnRoom = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnTeacher = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCity
            // 
            this.btnCity.Location = new System.Drawing.Point(64, 64);
            this.btnCity.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCity.Name = "btnCity";
            this.btnCity.Size = new System.Drawing.Size(267, 52);
            this.btnCity.TabIndex = 0;
            this.btnCity.Text = "ערים";
            this.btnCity.UseVisualStyleBackColor = true;
            this.btnCity.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnRoom
            // 
            this.btnRoom.Location = new System.Drawing.Point(64, 241);
            this.btnRoom.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRoom.Name = "btnRoom";
            this.btnRoom.Size = new System.Drawing.Size(267, 52);
            this.btnRoom.TabIndex = 1;
            this.btnRoom.Text = "חדרים";
            this.btnRoom.UseVisualStyleBackColor = true;
            this.btnRoom.Click += new System.EventHandler(this.btnRoom_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(64, 154);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(267, 52);
            this.button1.TabIndex = 2;
            this.button1.Text = "תלמידים";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btnTeacher
            // 
            this.btnTeacher.Location = new System.Drawing.Point(64, 321);
            this.btnTeacher.Margin = new System.Windows.Forms.Padding(4);
            this.btnTeacher.Name = "btnTeacher";
            this.btnTeacher.Size = new System.Drawing.Size(267, 52);
            this.btnTeacher.TabIndex = 3;
            this.btnTeacher.Text = "מורים";
            this.btnTeacher.UseVisualStyleBackColor = true;
            this.btnTeacher.Click += new System.EventHandler(this.btnTeacher_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btnTeacher);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnRoom);
            this.Controls.Add(this.btnCity);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmMain";
            this.Text = "frmMain";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCity;
        private System.Windows.Forms.Button btnRoom;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnTeacher;
    }
}