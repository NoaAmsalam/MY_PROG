﻿using DriveSchool.Bll;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmStudent : Form
    {
        string state;
        Bll.student student;
        Bll.studentTable studentTable;

        public frmStudent()
        {


            InitializeComponent();
            state = "Add";
            //אתחול משתנים   
            student = new Bll.student();
            studentTable = new Bll.studentTable();
            //הצגת הנתונים בפקד הרשימה    
            CityTable ct = new CityTable();
            cnbCity.DataSource = ct.GetList();
            button1.Visible = false;
            button3.Visible = false;
        }
       public frmStudent(string id)
        {
            InitializeComponent();
            state = "Add";
            txtId.Text = id;
            //אתחול משתנים   
            student = new Bll.student();
            studentTable = new Bll.studentTable();
            //הצגת הנתונים בפקד הרשימה    
            CityTable ct = new CityTable();
            cnbCity.DataSource = ct.GetList();
            button1.Visible = false;
            button3.Visible = false;
        }
        public frmStudent(Bll.student c)
        {
            InitializeComponent();
            state = "update";

            student = c;
            studentTable = new studentTable();

            CityTable ct = new CityTable();
            cnbCity.DataSource = ct.GetList();

            FillTextBox();

        }
        public void FillTextBox()
        {
            txtId.Text = student.StudentId.ToString();
            txtFirstName.Text = student.StudentFirstName;
            txtLastname.Text = student.StudentLastName;
            txtNum.Text = student.Num.ToString();
            txtStreet.Text = student.Street;
            txtNotes.Text = student.Notes;
            txtPhone.Text = student.Phone;
            dateTimePicker1.Value = student.BirthDate; 
            chbGreenFrm.Checked = student.GreenForm;
          


            cnbCity.Text = student.GetCity().CityName;
        }


        private void FrmCustomer_Load(object sender, EventArgs e)
        {

        }

        private void lblcstlestname_Click(object sender, EventArgs e)
        {

        }

        private void lblcsthuosenum_Click(object sender, EventArgs e)
        {

        }

        private void btnctssave_Click(object sender, EventArgs e)
        {
            if (Check())
            {
                if (state == "Add")
                {
                    try
                    {
                        studentTable.Add(student);
                        MessageBox.Show("התלמיד נשמר בהצלחה");
                    }
                    catch
                    {
                        MessageBox.Show("בעיה בשמירת התלמיד");
                    }
                    this.Close();
                }


                if (state == "update")
                {
                    try
                    {
                        studentTable.Update(student);
                        MessageBox.Show("התלמיד עודכן בהצלחה");
                    }
                    catch
                    {
                        MessageBox.Show("בעיה בעידכון תלמיד");
                    }
                    this.Close();
                }

            }
        }
        public bool Check()
        {
            bool ok = true;
            errorProvider1.Clear();
            try
            {
                student.StudentFirstName = txtFirstName.Text;
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtFirstName, ex.Message);
                ok = false;
            }
            try
            {
                student.StudentLastName = txtLastname.Text;
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtLastname, ex.Message);
                ok = false;
            }
            try
            {
                student.Street = txtStreet.Text;
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtStreet, ex.Message);
                ok = false;
            }
            try
            {
                student.Num = Convert.ToInt32(txtNum.Text);
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtNum, ex.Message);
                ok = false;
            }
            try
            {
                student.Phone = txtPhone.Text;
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtPhone, ex.Message);
                ok = false;
            }

            student.CityId = ((City)cnbCity.SelectedItem).CityId;
            try
            {
                student.StudentId = txtId.Text;
            }
            catch (Exception ex)
            {

                errorProvider1.SetError(txtId, ex.Message);
                ok = false;
            }
            try
            {
                student.BirthDate = dateTimePicker1.Value;
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(dateTimePicker1, ex.Message);
                ok = false;

            }

            student.GreenForm = chbGreenFrm.Checked;


            return ok;
        }

        private void FrmCustomer_Load_1(object sender, EventArgs e)
        {

        }

        private void btnctssave_Click_1(object sender, EventArgs e)
        {

        }

        private void btnAddcity_Click(object sender, EventArgs e)
        {
            Frmcity f = new Frmcity(true);
            f.Show();

            CityTable ct = new CityTable();
            cnbCity.DataSource = ct.GetList();
        }

        private void frmStudent_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            frmLessonsStudent s = new frmLessonsStudent(student);
            s.Show();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            frmlicenceStudent f = new frmlicenceStudent(student);
            f.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (chbGreenFrm.Checked)
            {
                frmLicencesStudent f = new frmLicencesStudent(student);
                f.Show();
            }
            else
                MessageBox.Show("אין לתלמיד טופס ירוק ");
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            CityTable ct = new CityTable();
            cnbCity.DataSource = ct.GetList();
        }
    }
}