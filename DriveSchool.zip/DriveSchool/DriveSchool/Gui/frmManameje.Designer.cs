﻿
namespace DriveSchool.Gui
{
    partial class frmManameje
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLicences = new System.Windows.Forms.Button();
            this.btnCourse = new System.Windows.Forms.Button();
            this.btnTeacher = new System.Windows.Forms.Button();
            this.btnRoom = new System.Windows.Forms.Button();
            this.btnCity = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLicences
            // 
            this.btnLicences.BackColor = System.Drawing.Color.White;
            this.btnLicences.Font = new System.Drawing.Font("Times New Roman", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLicences.ForeColor = System.Drawing.Color.Navy;
            this.btnLicences.Location = new System.Drawing.Point(18, 211);
            this.btnLicences.Margin = new System.Windows.Forms.Padding(4);
            this.btnLicences.Name = "btnLicences";
            this.btnLicences.Size = new System.Drawing.Size(131, 120);
            this.btnLicences.TabIndex = 10;
            this.btnLicences.Text = "רישיונות";
            this.btnLicences.UseVisualStyleBackColor = false;
            this.btnLicences.Click += new System.EventHandler(this.btnLicences_Click);
            // 
            // btnCourse
            // 
            this.btnCourse.BackColor = System.Drawing.Color.White;
            this.btnCourse.Font = new System.Drawing.Font("Times New Roman", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCourse.ForeColor = System.Drawing.Color.Navy;
            this.btnCourse.Location = new System.Drawing.Point(435, 211);
            this.btnCourse.Margin = new System.Windows.Forms.Padding(4);
            this.btnCourse.Name = "btnCourse";
            this.btnCourse.Size = new System.Drawing.Size(131, 120);
            this.btnCourse.TabIndex = 9;
            this.btnCourse.Text = "קורסים";
            this.btnCourse.UseVisualStyleBackColor = false;
            this.btnCourse.Click += new System.EventHandler(this.btnCourse_Click);
            // 
            // btnTeacher
            // 
            this.btnTeacher.BackColor = System.Drawing.Color.White;
            this.btnTeacher.Font = new System.Drawing.Font("Times New Roman", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTeacher.ForeColor = System.Drawing.Color.Navy;
            this.btnTeacher.Location = new System.Drawing.Point(157, 211);
            this.btnTeacher.Margin = new System.Windows.Forms.Padding(4);
            this.btnTeacher.Name = "btnTeacher";
            this.btnTeacher.Size = new System.Drawing.Size(131, 120);
            this.btnTeacher.TabIndex = 8;
            this.btnTeacher.Text = "מורים";
            this.btnTeacher.UseVisualStyleBackColor = false;
            this.btnTeacher.Click += new System.EventHandler(this.btnTeacher_Click);
            // 
            // btnRoom
            // 
            this.btnRoom.BackColor = System.Drawing.Color.White;
            this.btnRoom.Font = new System.Drawing.Font("Times New Roman", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRoom.ForeColor = System.Drawing.Color.Navy;
            this.btnRoom.Location = new System.Drawing.Point(296, 211);
            this.btnRoom.Margin = new System.Windows.Forms.Padding(4);
            this.btnRoom.Name = "btnRoom";
            this.btnRoom.Size = new System.Drawing.Size(131, 120);
            this.btnRoom.TabIndex = 7;
            this.btnRoom.Text = "חדרים";
            this.btnRoom.UseVisualStyleBackColor = false;
            this.btnRoom.Click += new System.EventHandler(this.btnRoom_Click);
            // 
            // btnCity
            // 
            this.btnCity.BackColor = System.Drawing.Color.White;
            this.btnCity.Font = new System.Drawing.Font("Times New Roman", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCity.ForeColor = System.Drawing.Color.Navy;
            this.btnCity.Location = new System.Drawing.Point(574, 211);
            this.btnCity.Margin = new System.Windows.Forms.Padding(4);
            this.btnCity.Name = "btnCity";
            this.btnCity.Size = new System.Drawing.Size(131, 120);
            this.btnCity.TabIndex = 6;
            this.btnCity.Text = "ערים";
            this.btnCity.UseVisualStyleBackColor = false;
            this.btnCity.Click += new System.EventHandler(this.btnCity_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DriveSchool.Properties.Resources.לוגו1;
            this.pictureBox1.Location = new System.Drawing.Point(18, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(691, 192);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // frmManameje
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(721, 344);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnLicences);
            this.Controls.Add(this.btnCourse);
            this.Controls.Add(this.btnTeacher);
            this.Controls.Add(this.btnRoom);
            this.Controls.Add(this.btnCity);
            this.Name = "frmManameje";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "הנהלה";
            this.Load += new System.EventHandler(this.frmManameje_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLicences;
        private System.Windows.Forms.Button btnCourse;
        private System.Windows.Forms.Button btnTeacher;
        private System.Windows.Forms.Button btnRoom;
        private System.Windows.Forms.Button btnCity;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
