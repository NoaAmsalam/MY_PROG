﻿using DriveSchool.Bll;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmLesson : Form
    {
        Bll.lesson lesson;
        Bll.lessonTable lessonTable;
        string state;
        public frmLesson()
        {
            InitializeComponent();
            state = "Add";
            lesson = new lesson();
            lessonTable = new lessonTable();
            lesson.Lessonid = lessonTable.getnewkey();
            lblKod.Text = lesson.Lessonid.ToString();
            //רשימה של סוגי רישיון
            licencesTable ct = new licencesTable();
            comboBox1.DataSource = ct.GetList();
        }
        public frmLesson(lesson t)
        {
            InitializeComponent();
            state = "Update";

            lesson = t;
            lessonTable = new lessonTable();
            //רשימה של סוגי רישיון
            licencesTable ct = new licencesTable();
            comboBox1.DataSource = ct.GetList();

            FillTextBox();
        }
        public void FillTextBox()
        {
            lblKod.Text = lesson.Lessonid.ToString();
            txtName.Text = lesson.LessonName.ToString();
            nmcMax.Value = lesson.StudentMax;
            nmcMin.Value = lesson.StudentMin;
            nmcMax.Value = lesson.StudentMax;
            nmcLength.Value = lesson.LessonLength;

        }
        public bool Check()
        {
            bool ok = true;
            errorProvider1.Clear();

            try
            {
                lesson.LessonName = txtName.Text;
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtName, ex.Message);
                ok = false;
            }
            try
            {
                lesson.LessonLength = Convert.ToInt32(nmcLength.Text);
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(nmcLength, ex.Message);
                ok = false;
            }
            try
            {
                lesson.StudentMax = Convert.ToInt32(nmcMax.Value);
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(nmcMax, ex.Message);
                ok = false;
            }
            lesson.LicenceId = ((licences)comboBox1.SelectedItem).LicenceId;
            return ok;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (Check())
            {
                if (state == "Add")
                {
                    try
                    {
                        lessonTable.Add(lesson);
                        MessageBox.Show("סוג השיעור נשמר בהצלחה");
                    }
                    catch
                    {
                        MessageBox.Show("בעיה בשמירת סוג שיעור");
                    }
                    this.Close();
                }


                if (state == "Update")
                {
                    try
                    {
                        lessonTable.Update(lesson);
                        MessageBox.Show("סוג שיעור עודכן בהצלחה");
                    }
                    catch
                    {
                        MessageBox.Show("בעיה בעידכון סוג שיעור");
                    }
                    this.Close();
                }
            }
        }
    }
}
