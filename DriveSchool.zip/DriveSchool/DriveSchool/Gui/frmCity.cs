﻿using DriveSchool.Bll;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    

 public partial class Frmcity : Form
    {
        Bll.City city;
        Bll.CityTable cityTable;
        IEnumerable<Bll.City> filter;
        bool close_after_save = false;

        public Frmcity(bool close_form=false)
        {
            InitializeComponent();
            city = new Bll.City();
            cityTable = new Bll.CityTable();
            rdbadd.Checked = true;
            refresh();
            ChangeHeaders();
            filter = cityTable.GetList();
            close_after_save = close_form;
        }
        public void ChangeHeaders()
        {
            dgvcity.Columns["cityid"].HeaderText = "קוד עיר";
            dgvcity.Columns["cityname"].HeaderText = "שם עיר";
        }
        public bool check()
        {
            bool ok = true;
            try
            {
                city.CityName = txtnamecity.Text;
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtnamecity, ex.Message);
                ok = false;
            }
            return ok;
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void rdbadd_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbadd.Checked)
                grbadd.Text = "הוספה";
            else
                grbadd.Text = "עידכון";


        }

        private void txtreserchcity_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnok_Click(object sender, EventArgs e)
        {
            errorProvider1.Clear();
            if (cityTable.GetList().Any(x => x.CityName == txtnamecity.Text) == true)
                errorProvider1.SetError(txtnamecity, "city exists");
            else
            {
                if (check() == true)
                {
                    if (rdbupdate.Checked == true)
                    {
                        cityTable.Update(city);
                        Refresh();
                        txtnamecity.Text = "";
                        lblsaved.Visible = true;
                        timer1.Enabled = true;
                        txtnamecity.Text = "";
                        refresh();

                    }
                    else
                    {
                        city.CityId = cityTable.getnewkey();
                        cityTable.Add(city);
                        refresh();
                        lblsaved.Visible = true;
                        timer1.Enabled = true;
                        txtnamecity.Text = "";
                    }
                }
            }
            if (close_after_save)
                this.Close();
        }
        public void refresh()
        {

            dgvcity.DataSource = cityTable.GetList().Select(x => new { x.CityId, x.CityName }).ToList();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvcity_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (rdbupdate.Checked)
            {
                int id = Convert.ToInt32(dgvcity.SelectedRows[0].Cells[0].Value);
                city = new Bll.City();
                city = cityTable.GetList().FirstOrDefault(x => x.CityId == id);
                txtnamecity.Text = city.CityName;
            }


        }

        private void rdbupdate_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void lblsaved_Click(object sender, EventArgs e)
        {

        }

        private void lblreserchcity_Click(object sender, EventArgs e)
        {

        }

        private void Frmcity_Load(object sender, EventArgs e)
        {

        }
        int i;//מונה למספר שניות
        private void timer1_Tick(object sender, EventArgs e)
        {
            i++;
            if (i == 4)
            {
                timer1.Enabled = false;
                lblsaved.Visible = false;
                i = 0;

            }
        }
        public void filldgvfilter()
        {
            dgvcity.DataSource = filter.ToList().Select(x => new { x.CityId, x.CityName }).ToList();

        }

        private void txtreserchcity_KeyUp(object sender, KeyEventArgs e)
        {
            filter = filter.Where(x => (x.CityName.Contains(txtreserchcity.Text)));
            filldgvfilter();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            refresh();
            txtreserchcity.Text = "";
        }

        private void txtreserchcity_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void Txtnamecity_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblreserchcity_Click_1(object sender, EventArgs e)
        {

        }

        private void Frmcity_Load_1(object sender, EventArgs e)
        {

        }
    }
}

