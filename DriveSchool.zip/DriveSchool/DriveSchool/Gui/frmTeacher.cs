﻿using DriveSchool.Bll;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmTeacher : DriveSchool.Form1
    {
        teacher teacher;
        teachertable teachertable;
        string state;

        public frmTeacher()
        {
            InitializeComponent();
            state = "Add";
            teacher = new teacher();
            teachertable = new teachertable();
            CityTable ct = new CityTable();
            cnbCity.DataSource = ct.GetList();
            button1.Visible = false;
            button2.Visible = false;
        }
        public frmTeacher(string id)
        {

            InitializeComponent();
            state = "Add";
            teacher = new teacher();
            teachertable = new teachertable();
            CityTable ct = new CityTable();
            cnbCity.DataSource = ct.GetList();
            txtId.Text = id;
            button1.Visible = false;
            button2.Visible = false;
        }
        public frmTeacher (teacher t)
        {
            InitializeComponent();
            state = "Update";

            teacher = t;
            teachertable = new teachertable();

            CityTable ct = new CityTable();
            cnbCity.DataSource = ct.GetList();

            FillTextBox();
        }
        public void FillTextBox()
        {
            txtId.Text = teacher.TeacherId.ToString();
            txtFirstName.Text = teacher.TeacherFirstName;
            int i = 0;//מונה למספר שניות
            txtLastname.Text = teacher.TeacherLasttName;
            txtNum.Text = teacher.Num.ToString();
            txtStreet.Text = teacher.Street;
            dateTimePicker1.Value = teacher.StartWorking;
            txtPhone.Text = teacher.Phone;
            


            cnbCity.Text = teacher.GetCity().CityName;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if(check())
            {
                if (state == "Add")
                {
                    try
                    {
                        teachertable.Add(teacher);
                        MessageBox.Show("המורה נשמר בהצלחה");
                    }
                    catch
                    {
                        MessageBox.Show("בעיה בשמירת המורה");
                    }
                    this.Close();
                }


                if (state == "Update")
                {
                    try
                    {
                        teachertable.Update(teacher);
                        MessageBox.Show("מורה עודכן בהצלחה");
                    }
                    catch
                    {
                        MessageBox.Show("בעיה בעידכון מורה");
                    }
                    this.Close();

                }
            }
        }
        public bool check()
        {
            bool ok = true;
            errorProvider1.Clear();
            try
            { 
                teacher.TeacherId = txtId.Text;
                
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtId, ex.Message);
                ok = false;
            }
            try
            {
               teacher.TeacherFirstName = txtFirstName.Text;
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtFirstName, ex.Message);
                ok = false;
            }
            try
            {
                teacher.TeacherLasttName = txtLastname.Text;
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtLastname, ex.Message);
                ok = false;
            }
            try
            {
                teacher.Street = txtStreet.Text;
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtStreet, ex.Message);
                ok = false;
            }
            try
            {
                teacher.Num = Convert.ToInt32(txtNum.Text);
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtNum, ex.Message);
                ok = false;
            }
            try
            {
                teacher.Phone = txtPhone.Text;
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtPhone, ex.Message);
                ok = false;
            }
            //השמה של תאריך ללא בדיקה
            teacher.StartWorking = dateTimePicker1.Value;
            //השמה של עיר ללא בדיקה
           teacher.CityId = ((City)cnbCity.SelectedItem).CityId;

            return ok;
        }

        private void btnAddcity_Click(object sender, EventArgs e)
        {
            Frmcity f = new Frmcity(true);
            f.Show();

            CityTable ct = new CityTable();
            cnbCity.DataSource = ct.GetList();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            frmLicenceTeacher f = new frmLicenceTeacher(teacher);
            f.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmLicencesTeacher f = new frmLicencesTeacher(teacher);
            f.Show();
        }

       

        private void button1_Click_1(object sender, EventArgs e)
        {
            frmTeacherCourses f = new frmTeacherCourses(teacher);
            f.Show();
        }

        private void frmTeacher_Load(object sender, EventArgs e)
        {

        }
    }
    }


