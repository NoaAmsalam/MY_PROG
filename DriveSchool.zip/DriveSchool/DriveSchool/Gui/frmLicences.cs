﻿using DriveSchool.Bll;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmLicences : Form
    {
        string state;
        Bll.licencesTable licencesTable;
        Bll.licences licence;
        public frmLicences(bool b)
        {
            InitializeComponent();
            licencesTable = new Bll.licencesTable();
            licence = new licences();
            dgvLicences.DataSource = licencesTable.GetList();
            ChangeHeaders();
            if (b == false)
            {
                button1.Visible = false;
                button2.Visible = false;
            }
        }
        public void ChangeHeaders()
        {
            dgvLicences.Columns["licenceId"].HeaderText = "קוד רישיון";
            dgvLicences.Columns["licenceName"].HeaderText = "שם רישיון";
            dgvLicences.Columns["lessonMin"].HeaderText = "מספר שיעורים מנימלי";
            dgvLicences.Columns["ageMin"].HeaderText = "גיל מינמלי";
            dgvLicences.Columns["priceLesson"].HeaderText = "מחיר שיעור ";
            dgvLicences.Columns["GlobalPrice"].HeaderText = "מחיר גלובלי";
            dgvLicences.Columns["drow"].Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmLicence f = new frmLicence();
            f.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmLicence f = new frmLicence(licence);
            f.Show();
        }

        private void dgvLicences_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int id = Convert.ToInt32(dgvLicences.SelectedRows[0].Cells[0].Value);

            licence = licencesTable.GetList().FirstOrDefault(x => x.LicenceId == id);
        }

        private void dgvLicences_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int id = Convert.ToInt32(dgvLicences.SelectedRows[0].Cells[0].Value);

            licence = licencesTable.GetList().FirstOrDefault(x => x.LicenceId == id);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
         //   dgvLicences.DataSource = new Bll.licencesTable().GetList().FindAll(x => x.LicenceName.StartsWith(txtSearch.Text));// || x..StartsWith(txtSearch.Text));
        }

        private void frmLicences_Load(object sender, EventArgs e)
        {

        }
    }
}
