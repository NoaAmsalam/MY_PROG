﻿using DriveSchool.Bll;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    

    public partial class frmLicence : Form
    {
        string state;
        Bll.licencesTable licencesTable;
        Bll.licences licence;
        public frmLicence()
        {
            InitializeComponent();
            state = "Add";
            //אתחול משתנים   
            licence = new Bll.licences();
            licencesTable = new Bll.licencesTable();
            licence.LicenceId = licencesTable.getnewkey();
            lblKod.Text = licence.LicenceId.ToString();
        }
        public frmLicence(Bll.licences c)
        {
            InitializeComponent();
            state = "update";
            licence = c;
            licencesTable = new licencesTable();
            FillTextBox();

        }
        public void FillTextBox()
        {
            lblKod.Text = licence.LicenceId.ToString();
            txtAge.Text = licence.AgeMin.ToString();
            txtGlobalPrice.Text = licence.GlobalPrice.ToString();
            txtLessonPrice.Text = licence.PriceLesson.ToString();
            txtName.Text = licence.LicenceName;
            nmcNumLessonMin.Value = Convert.ToInt32 (licence.LessonMin);
        }
        public bool Check()
        {
            bool ok = true;
            errorProvider1.Clear();
            try
            {
                licence.GlobalPrice = Convert.ToInt32(txtGlobalPrice.Text);
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtGlobalPrice, ex.Message);
                ok = false;
            }
            try
            {
                licence.LessonMin = Convert.ToInt32( nmcNumLessonMin.Value);
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(nmcNumLessonMin, ex.Message);
                ok = false;
            }
            try
            {
                licence.PriceLesson = Convert.ToInt32(txtLessonPrice.Text);
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtLessonPrice, ex.Message);
                ok = false;
            }
            try
            {
                licence.LicenceName = txtName.Text;
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtName, ex.Message);
                ok = false;
            }
            try
            {
                licence.AgeMin = Convert.ToDouble(txtAge.Text);
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtAge, ex.Message);
                ok = false;
            }
           
            return ok;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (Check())
            {
                if (state == "Add")
                {
                    try
                    {
                        licencesTable.Add(licence);
                        MessageBox.Show("סוג הרישיון נשמר בהצלחה");
                    }
                    catch
                    {
                        MessageBox.Show("בעיה בשמירת סוג הרישיון");
                    }
                    this.Close();
                }


                if (state == "update")
                {
                    try
                    {
                        licencesTable.Update(licence);
                        MessageBox.Show("סוג הרישיון עודכן בהצלחה");
                    }
                    catch
                    {
                        MessageBox.Show("בעיה בעידכון סוג הרישיון");
                    }
                    this.Close();
                }

            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void frmLicence_Load(object sender, EventArgs e)
        {

        }
    }
}
