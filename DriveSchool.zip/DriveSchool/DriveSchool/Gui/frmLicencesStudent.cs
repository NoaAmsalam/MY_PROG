﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmLicencesStudent : Form
    {
        Bll.licencesStudent licencesStudent;
        Bll.licencesStudentTable licencesStudentTable;
        Bll.student student;
        License license;
        
        public frmLicencesStudent(Bll.student s)
        {
            InitializeComponent();
            licencesStudent = new Bll.licencesStudent();
            licencesStudentTable = new Bll.licencesStudentTable();
            student = s;
            txtname.Text = s.ToString();
            dataGridView1.DataSource = licencesStudentTable.GetList().Where<Bll.licencesStudent>(x =>  x.StudentId == s.StudentId).ToList().Select(x => new {x.LicenceStudentId, x.GetLicences().LicenceName,x.Theory ,x.PayPackage, x.Test }).ToList();
            ChangeHeaders();

        }

        public void ChangeHeaders()
        {
            dataGridView1.Columns["LicenceStudentId"].HeaderText = "קוד רישיון לתלמיד";
            dataGridView1.Columns["LicenceName"].HeaderText = "שם רישיון";
            dataGridView1.Columns["PayPackage"].HeaderText = "שולם חבילה";
            dataGridView1.Columns["Test"].HeaderText = "עבר טסט";
            dataGridView1.Columns["theory"].HeaderText = "עבר תאוריה";
        }

            private void button2_Click(object sender, EventArgs e)
        {
            frmlicenceStudent f = new frmlicenceStudent(student);
            f.Show();
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.ColumnIndex == 4 && (bool)e.Value == false)
                dataGridView1.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.LightGreen;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                licencesStudent = new Bll.licencesStudentTable().GetList().FirstOrDefault(x=>x.LicenceStudentId==Convert.ToInt32( dataGridView1.SelectedRows[0].Cells[0].Value));
                frmlicenceStudent f = new frmlicenceStudent(licencesStudent);
                f.Show();
            }
            else
                MessageBox.Show("בחר שורה");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            
        }

        private void frmLicencesStudent_Load(object sender, EventArgs e)
        {

        }
    }
}
