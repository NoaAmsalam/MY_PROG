﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmbeetwinSchedule : DriveSchool.Form1
    {
        public frmbeetwinSchedule()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmSS f = new frmSS();
            f.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmDD f = new frmDD();
            f.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmLessonsActually f = new frmLessonsActually();
            f.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmCoursesActually f = new frmCoursesActually();
            f.Show();
        }

        private void frmbeetwinSchedule_Load(object sender, EventArgs e)
        {

        }
    }
}
