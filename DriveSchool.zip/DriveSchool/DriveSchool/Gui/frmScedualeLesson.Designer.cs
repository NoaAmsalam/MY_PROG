﻿namespace DriveSchool.Gui
{
    partial class frmScedualeLesson
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.b_date = new System.Windows.Forms.Label();
            this.c_date = new System.Windows.Forms.Label();
            this.d_date = new System.Windows.Forms.Label();
            this.e_date = new System.Windows.Forms.Label();
            this.f_date = new System.Windows.Forms.Label();
            this.a_date = new System.Windows.Forms.Label();
            this.b_name = new System.Windows.Forms.Label();
            this.c_name = new System.Windows.Forms.Label();
            this.d_name = new System.Windows.Forms.Label();
            this.e_name = new System.Windows.Forms.Label();
            this.f_name = new System.Windows.Forms.Label();
            this.a_name = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.e0800 = new System.Windows.Forms.Label();
            this.c1530 = new System.Windows.Forms.Label();
            this.e1000 = new System.Windows.Forms.Label();
            this.e1900 = new System.Windows.Forms.Label();
            this.e1500 = new System.Windows.Forms.Label();
            this.e1400 = new System.Windows.Forms.Label();
            this.e1800 = new System.Windows.Forms.Label();
            this.e1200 = new System.Windows.Forms.Label();
            this.e1100 = new System.Windows.Forms.Label();
            this.e1700 = new System.Windows.Forms.Label();
            this.e0900 = new System.Windows.Forms.Label();
            this.e1600 = new System.Windows.Forms.Label();
            this.e1300 = new System.Windows.Forms.Label();
            this.e2000 = new System.Windows.Forms.Label();
            this.b1800 = new System.Windows.Forms.Label();
            this.b1600 = new System.Windows.Forms.Label();
            this.b2000 = new System.Windows.Forms.Label();
            this.b1500 = new System.Windows.Forms.Label();
            this.b1900 = new System.Windows.Forms.Label();
            this.b1000 = new System.Windows.Forms.Label();
            this.b1400 = new System.Windows.Forms.Label();
            this.b0800 = new System.Windows.Forms.Label();
            this.b1700 = new System.Windows.Forms.Label();
            this.b1100 = new System.Windows.Forms.Label();
            this.b0900 = new System.Windows.Forms.Label();
            this.b1300 = new System.Windows.Forms.Label();
            this.b1200 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.f1200 = new System.Windows.Forms.Label();
            this.f0900 = new System.Windows.Forms.Label();
            this.f0800 = new System.Windows.Forms.Label();
            this.f1100 = new System.Windows.Forms.Label();
            this.f1300 = new System.Windows.Forms.Label();
            this.f1000 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.c0800 = new System.Windows.Forms.Label();
            this.c1000 = new System.Windows.Forms.Label();
            this.c1300 = new System.Windows.Forms.Label();
            this.c1700 = new System.Windows.Forms.Label();
            this.c9000 = new System.Windows.Forms.Label();
            this.c1400 = new System.Windows.Forms.Label();
            this.c1600 = new System.Windows.Forms.Label();
            this.c1500 = new System.Windows.Forms.Label();
            this.c1900 = new System.Windows.Forms.Label();
            this.c1100 = new System.Windows.Forms.Label();
            this.c1200 = new System.Windows.Forms.Label();
            this.c1800 = new System.Windows.Forms.Label();
            this.c2000 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.d1000 = new System.Windows.Forms.Label();
            this.d0800 = new System.Windows.Forms.Label();
            this.d1400 = new System.Windows.Forms.Label();
            this.d1900 = new System.Windows.Forms.Label();
            this.d1800 = new System.Windows.Forms.Label();
            this.d1200 = new System.Windows.Forms.Label();
            this.d1700 = new System.Windows.Forms.Label();
            this.d2000 = new System.Windows.Forms.Label();
            this.d0900 = new System.Windows.Forms.Label();
            this.d1100 = new System.Windows.Forms.Label();
            this.d1500 = new System.Windows.Forms.Label();
            this.d1300 = new System.Windows.Forms.Label();
            this.d1600 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.a1700 = new System.Windows.Forms.Label();
            this.a2000 = new System.Windows.Forms.Label();
            this.a1000 = new System.Windows.Forms.Label();
            this.a1400 = new System.Windows.Forms.Label();
            this.a1500 = new System.Windows.Forms.Label();
            this.a0800 = new System.Windows.Forms.Label();
            this.a1100 = new System.Windows.Forms.Label();
            this.a1300 = new System.Windows.Forms.Label();
            this.a1900 = new System.Windows.Forms.Label();
            this.a0900 = new System.Windows.Forms.Label();
            this.a1200 = new System.Windows.Forms.Label();
            this.a1600 = new System.Windows.Forms.Label();
            this.a1800 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtLicence = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // b_date
            // 
            this.b_date.AutoSize = true;
            this.b_date.Location = new System.Drawing.Point(519, 144);
            this.b_date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b_date.Name = "b_date";
            this.b_date.Size = new System.Drawing.Size(52, 17);
            this.b_date.TabIndex = 94;
            this.b_date.Text = "b_date";
            // 
            // c_date
            // 
            this.c_date.AutoSize = true;
            this.c_date.Location = new System.Drawing.Point(745, 144);
            this.c_date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.c_date.Name = "c_date";
            this.c_date.Size = new System.Drawing.Size(51, 17);
            this.c_date.TabIndex = 93;
            this.c_date.Text = "c_date";
            // 
            // d_date
            // 
            this.d_date.AutoSize = true;
            this.d_date.Location = new System.Drawing.Point(972, 144);
            this.d_date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d_date.Name = "d_date";
            this.d_date.Size = new System.Drawing.Size(52, 17);
            this.d_date.TabIndex = 92;
            this.d_date.Text = "d_date";
            // 
            // e_date
            // 
            this.e_date.AutoSize = true;
            this.e_date.Location = new System.Drawing.Point(1199, 144);
            this.e_date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e_date.Name = "e_date";
            this.e_date.Size = new System.Drawing.Size(52, 17);
            this.e_date.TabIndex = 91;
            this.e_date.Text = "e_date";
            // 
            // f_date
            // 
            this.f_date.AutoSize = true;
            this.f_date.Location = new System.Drawing.Point(1429, 144);
            this.f_date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.f_date.Name = "f_date";
            this.f_date.Size = new System.Drawing.Size(48, 17);
            this.f_date.TabIndex = 90;
            this.f_date.Text = "f_date";
            // 
            // a_date
            // 
            this.a_date.AutoSize = true;
            this.a_date.Location = new System.Drawing.Point(292, 144);
            this.a_date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a_date.Name = "a_date";
            this.a_date.Size = new System.Drawing.Size(52, 17);
            this.a_date.TabIndex = 89;
            this.a_date.Text = "a_date";
            // 
            // b_name
            // 
            this.b_name.AutoSize = true;
            this.b_name.Font = new System.Drawing.Font("Snap ITC", 9.75F, System.Drawing.FontStyle.Bold);
            this.b_name.Location = new System.Drawing.Point(475, 141);
            this.b_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b_name.Name = "b_name";
            this.b_name.Size = new System.Drawing.Size(36, 23);
            this.b_name.TabIndex = 88;
            this.b_name.Text = "שני";
            // 
            // c_name
            // 
            this.c_name.AutoSize = true;
            this.c_name.Font = new System.Drawing.Font("Snap ITC", 9.75F, System.Drawing.FontStyle.Bold);
            this.c_name.Location = new System.Drawing.Point(672, 139);
            this.c_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.c_name.Name = "c_name";
            this.c_name.Size = new System.Drawing.Size(58, 23);
            this.c_name.TabIndex = 87;
            this.c_name.Text = "שלישי";
            // 
            // d_name
            // 
            this.d_name.AutoSize = true;
            this.d_name.Font = new System.Drawing.Font("Snap ITC", 9.75F, System.Drawing.FontStyle.Bold);
            this.d_name.Location = new System.Drawing.Point(899, 139);
            this.d_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d_name.Name = "d_name";
            this.d_name.Size = new System.Drawing.Size(51, 23);
            this.d_name.TabIndex = 86;
            this.d_name.Text = "רביעי";
            // 
            // e_name
            // 
            this.e_name.AutoSize = true;
            this.e_name.Font = new System.Drawing.Font("Snap ITC", 9.75F, System.Drawing.FontStyle.Bold);
            this.e_name.Location = new System.Drawing.Point(1125, 139);
            this.e_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e_name.Name = "e_name";
            this.e_name.Size = new System.Drawing.Size(58, 23);
            this.e_name.TabIndex = 85;
            this.e_name.Text = "חמישי";
            // 
            // f_name
            // 
            this.f_name.AutoSize = true;
            this.f_name.Font = new System.Drawing.Font("Snap ITC", 9.75F, System.Drawing.FontStyle.Bold);
            this.f_name.Location = new System.Drawing.Point(1352, 139);
            this.f_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.f_name.Name = "f_name";
            this.f_name.Size = new System.Drawing.Size(48, 23);
            this.f_name.TabIndex = 84;
            this.f_name.Text = "שישי";
            // 
            // a_name
            // 
            this.a_name.AutoSize = true;
            this.a_name.Font = new System.Drawing.Font("Snap ITC", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a_name.Location = new System.Drawing.Point(225, 139);
            this.a_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a_name.Name = "a_name";
            this.a_name.Size = new System.Drawing.Size(56, 23);
            this.a_name.TabIndex = 83;
            this.a_name.Text = "ראשון";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.e0800);
            this.panel5.Controls.Add(this.c1530);
            this.panel5.Controls.Add(this.e1000);
            this.panel5.Controls.Add(this.e1900);
            this.panel5.Controls.Add(this.e1500);
            this.panel5.Controls.Add(this.e1400);
            this.panel5.Controls.Add(this.e1800);
            this.panel5.Controls.Add(this.e1200);
            this.panel5.Controls.Add(this.e1100);
            this.panel5.Controls.Add(this.e1700);
            this.panel5.Controls.Add(this.e0900);
            this.panel5.Controls.Add(this.e1600);
            this.panel5.Controls.Add(this.e1300);
            this.panel5.Controls.Add(this.e2000);
            this.panel5.Location = new System.Drawing.Point(1099, 166);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(189, 598);
            this.panel5.TabIndex = 82;
            this.panel5.Click += new System.EventHandler(this.a0800_Click);
            // 
            // e0800
            // 
            this.e0800.BackColor = System.Drawing.Color.LightGreen;
            this.e0800.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.e0800.Location = new System.Drawing.Point(47, 26);
            this.e0800.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e0800.Name = "e0800";
            this.e0800.Size = new System.Drawing.Size(90, 25);
            this.e0800.TabIndex = 54;
            this.e0800.Text = " ";
            this.e0800.Click += new System.EventHandler(this.a0800_Click);
            // 
            // c1530
            // 
            this.c1530.BackColor = System.Drawing.Color.LightGreen;
            this.c1530.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c1530.Location = new System.Drawing.Point(-52, 601);
            this.c1530.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.c1530.Name = "c1530";
            this.c1530.Size = new System.Drawing.Size(90, 25);
            this.c1530.TabIndex = 52;
            this.c1530.Text = " ";
            this.c1530.Click += new System.EventHandler(this.a0800_Click);
            // 
            // e1000
            // 
            this.e1000.BackColor = System.Drawing.Color.LightGreen;
            this.e1000.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.e1000.Location = new System.Drawing.Point(47, 114);
            this.e1000.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e1000.Name = "e1000";
            this.e1000.Size = new System.Drawing.Size(90, 25);
            this.e1000.TabIndex = 42;
            this.e1000.Text = " ";
            this.e1000.Click += new System.EventHandler(this.a0800_Click);
            // 
            // e1900
            // 
            this.e1900.BackColor = System.Drawing.Color.LightGreen;
            this.e1900.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.e1900.Location = new System.Drawing.Point(47, 510);
            this.e1900.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e1900.Name = "e1900";
            this.e1900.Size = new System.Drawing.Size(90, 25);
            this.e1900.TabIndex = 41;
            this.e1900.Text = " ";
            this.e1900.Click += new System.EventHandler(this.a0800_Click);
            // 
            // e1500
            // 
            this.e1500.BackColor = System.Drawing.Color.LightGreen;
            this.e1500.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.e1500.Location = new System.Drawing.Point(47, 334);
            this.e1500.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e1500.Name = "e1500";
            this.e1500.Size = new System.Drawing.Size(90, 25);
            this.e1500.TabIndex = 51;
            this.e1500.Text = " ";
            this.e1500.Click += new System.EventHandler(this.a0800_Click);
            // 
            // e1400
            // 
            this.e1400.BackColor = System.Drawing.Color.LightGreen;
            this.e1400.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.e1400.Location = new System.Drawing.Point(47, 290);
            this.e1400.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e1400.Name = "e1400";
            this.e1400.Size = new System.Drawing.Size(90, 25);
            this.e1400.TabIndex = 49;
            this.e1400.Text = " ";
            this.e1400.Click += new System.EventHandler(this.a0800_Click);
            // 
            // e1800
            // 
            this.e1800.BackColor = System.Drawing.Color.LightGreen;
            this.e1800.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.e1800.Location = new System.Drawing.Point(47, 466);
            this.e1800.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e1800.Name = "e1800";
            this.e1800.Size = new System.Drawing.Size(90, 25);
            this.e1800.TabIndex = 45;
            this.e1800.Text = " ";
            this.e1800.Click += new System.EventHandler(this.a0800_Click);
            // 
            // e1200
            // 
            this.e1200.BackColor = System.Drawing.Color.LightGreen;
            this.e1200.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.e1200.Location = new System.Drawing.Point(47, 202);
            this.e1200.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e1200.Name = "e1200";
            this.e1200.Size = new System.Drawing.Size(90, 25);
            this.e1200.TabIndex = 46;
            this.e1200.Text = " ";
            this.e1200.Click += new System.EventHandler(this.a0800_Click);
            // 
            // e1100
            // 
            this.e1100.BackColor = System.Drawing.Color.LightGreen;
            this.e1100.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.e1100.Location = new System.Drawing.Point(47, 158);
            this.e1100.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e1100.Name = "e1100";
            this.e1100.Size = new System.Drawing.Size(90, 25);
            this.e1100.TabIndex = 44;
            this.e1100.Text = " ";
            this.e1100.Click += new System.EventHandler(this.a0800_Click);
            // 
            // e1700
            // 
            this.e1700.BackColor = System.Drawing.Color.LightGreen;
            this.e1700.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.e1700.Location = new System.Drawing.Point(47, 422);
            this.e1700.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e1700.Name = "e1700";
            this.e1700.Size = new System.Drawing.Size(90, 25);
            this.e1700.TabIndex = 43;
            this.e1700.Text = " ";
            this.e1700.Click += new System.EventHandler(this.a0800_Click);
            // 
            // e0900
            // 
            this.e0900.BackColor = System.Drawing.Color.LightGreen;
            this.e0900.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.e0900.Location = new System.Drawing.Point(47, 70);
            this.e0900.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e0900.Name = "e0900";
            this.e0900.Size = new System.Drawing.Size(90, 25);
            this.e0900.TabIndex = 52;
            this.e0900.Text = " ";
            this.e0900.Click += new System.EventHandler(this.a0800_Click);
            // 
            // e1600
            // 
            this.e1600.BackColor = System.Drawing.Color.LightGreen;
            this.e1600.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.e1600.Location = new System.Drawing.Point(47, 378);
            this.e1600.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e1600.Name = "e1600";
            this.e1600.Size = new System.Drawing.Size(90, 25);
            this.e1600.TabIndex = 53;
            this.e1600.Text = " ";
            this.e1600.Click += new System.EventHandler(this.a0800_Click);
            // 
            // e1300
            // 
            this.e1300.BackColor = System.Drawing.Color.LightGreen;
            this.e1300.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.e1300.Location = new System.Drawing.Point(47, 246);
            this.e1300.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e1300.Name = "e1300";
            this.e1300.Size = new System.Drawing.Size(90, 25);
            this.e1300.TabIndex = 47;
            this.e1300.Text = " ";
            this.e1300.Click += new System.EventHandler(this.a0800_Click);
            // 
            // e2000
            // 
            this.e2000.BackColor = System.Drawing.Color.LightGreen;
            this.e2000.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.e2000.Location = new System.Drawing.Point(47, 554);
            this.e2000.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e2000.Name = "e2000";
            this.e2000.Size = new System.Drawing.Size(90, 25);
            this.e2000.TabIndex = 48;
            this.e2000.Text = " ";
            this.e2000.Click += new System.EventHandler(this.a0800_Click);
            // 
            // b1800
            // 
            this.b1800.BackColor = System.Drawing.Color.LightGreen;
            this.b1800.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b1800.Location = new System.Drawing.Point(48, 464);
            this.b1800.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b1800.Name = "b1800";
            this.b1800.Size = new System.Drawing.Size(90, 25);
            this.b1800.TabIndex = 41;
            this.b1800.Text = " ";
            this.b1800.Click += new System.EventHandler(this.a0800_Click);
            // 
            // b1600
            // 
            this.b1600.BackColor = System.Drawing.Color.LightGreen;
            this.b1600.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b1600.Location = new System.Drawing.Point(48, 374);
            this.b1600.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b1600.Name = "b1600";
            this.b1600.Size = new System.Drawing.Size(90, 25);
            this.b1600.TabIndex = 53;
            this.b1600.Text = " ";
            this.b1600.Click += new System.EventHandler(this.a0800_Click);
            // 
            // b2000
            // 
            this.b2000.BackColor = System.Drawing.Color.LightGreen;
            this.b2000.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b2000.Location = new System.Drawing.Point(48, 554);
            this.b2000.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b2000.Name = "b2000";
            this.b2000.Size = new System.Drawing.Size(90, 25);
            this.b2000.TabIndex = 52;
            this.b2000.Text = " ";
            this.b2000.Click += new System.EventHandler(this.a0800_Click);
            // 
            // b1500
            // 
            this.b1500.BackColor = System.Drawing.Color.LightGreen;
            this.b1500.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b1500.Location = new System.Drawing.Point(48, 329);
            this.b1500.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b1500.Name = "b1500";
            this.b1500.Size = new System.Drawing.Size(90, 25);
            this.b1500.TabIndex = 51;
            this.b1500.Text = " ";
            this.b1500.Click += new System.EventHandler(this.a0800_Click);
            // 
            // b1900
            // 
            this.b1900.BackColor = System.Drawing.Color.LightGreen;
            this.b1900.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b1900.Location = new System.Drawing.Point(48, 509);
            this.b1900.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b1900.Name = "b1900";
            this.b1900.Size = new System.Drawing.Size(90, 25);
            this.b1900.TabIndex = 50;
            this.b1900.Text = " ";
            this.b1900.Click += new System.EventHandler(this.a0800_Click);
            // 
            // b1000
            // 
            this.b1000.BackColor = System.Drawing.Color.LightGreen;
            this.b1000.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b1000.Location = new System.Drawing.Point(48, 104);
            this.b1000.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b1000.Name = "b1000";
            this.b1000.Size = new System.Drawing.Size(90, 25);
            this.b1000.TabIndex = 42;
            this.b1000.Text = " ";
            this.b1000.Click += new System.EventHandler(this.a0800_Click);
            // 
            // b1400
            // 
            this.b1400.BackColor = System.Drawing.Color.LightGreen;
            this.b1400.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b1400.Location = new System.Drawing.Point(48, 284);
            this.b1400.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b1400.Name = "b1400";
            this.b1400.Size = new System.Drawing.Size(90, 25);
            this.b1400.TabIndex = 49;
            this.b1400.Text = " ";
            this.b1400.Click += new System.EventHandler(this.a0800_Click);
            // 
            // b0800
            // 
            this.b0800.BackColor = System.Drawing.Color.LightGreen;
            this.b0800.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b0800.Location = new System.Drawing.Point(48, 14);
            this.b0800.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b0800.Name = "b0800";
            this.b0800.Size = new System.Drawing.Size(90, 25);
            this.b0800.TabIndex = 43;
            this.b0800.Text = " ";
            this.b0800.Click += new System.EventHandler(this.a0800_Click);
            // 
            // b1700
            // 
            this.b1700.BackColor = System.Drawing.Color.LightGreen;
            this.b1700.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b1700.Location = new System.Drawing.Point(48, 419);
            this.b1700.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b1700.Name = "b1700";
            this.b1700.Size = new System.Drawing.Size(90, 25);
            this.b1700.TabIndex = 48;
            this.b1700.Text = " ";
            this.b1700.Click += new System.EventHandler(this.a0800_Click);
            // 
            // b1100
            // 
            this.b1100.BackColor = System.Drawing.Color.LightGreen;
            this.b1100.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b1100.Location = new System.Drawing.Point(48, 149);
            this.b1100.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b1100.Name = "b1100";
            this.b1100.Size = new System.Drawing.Size(90, 25);
            this.b1100.TabIndex = 44;
            this.b1100.Text = " ";
            this.b1100.Click += new System.EventHandler(this.a0800_Click);
            // 
            // b0900
            // 
            this.b0900.BackColor = System.Drawing.Color.LightGreen;
            this.b0900.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b0900.Location = new System.Drawing.Point(48, 59);
            this.b0900.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b0900.Name = "b0900";
            this.b0900.Size = new System.Drawing.Size(90, 25);
            this.b0900.TabIndex = 45;
            this.b0900.Text = " ";
            this.b0900.Click += new System.EventHandler(this.a0800_Click);
            // 
            // b1300
            // 
            this.b1300.BackColor = System.Drawing.Color.LightGreen;
            this.b1300.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b1300.Location = new System.Drawing.Point(48, 239);
            this.b1300.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b1300.Name = "b1300";
            this.b1300.Size = new System.Drawing.Size(90, 25);
            this.b1300.TabIndex = 47;
            this.b1300.Text = " ";
            this.b1300.Click += new System.EventHandler(this.a0800_Click);
            // 
            // b1200
            // 
            this.b1200.BackColor = System.Drawing.Color.LightGreen;
            this.b1200.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b1200.Location = new System.Drawing.Point(48, 194);
            this.b1200.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b1200.Name = "b1200";
            this.b1200.Size = new System.Drawing.Size(90, 25);
            this.b1200.TabIndex = 46;
            this.b1200.Text = " ";
            this.b1200.Click += new System.EventHandler(this.a0800_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.f1200);
            this.panel6.Controls.Add(this.f0900);
            this.panel6.Controls.Add(this.f0800);
            this.panel6.Controls.Add(this.f1100);
            this.panel6.Controls.Add(this.f1300);
            this.panel6.Controls.Add(this.f1000);
            this.panel6.Location = new System.Drawing.Point(1334, 165);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(189, 291);
            this.panel6.TabIndex = 81;
            // 
            // f1200
            // 
            this.f1200.BackColor = System.Drawing.Color.LightGreen;
            this.f1200.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f1200.Location = new System.Drawing.Point(53, 207);
            this.f1200.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.f1200.Name = "f1200";
            this.f1200.Size = new System.Drawing.Size(90, 25);
            this.f1200.TabIndex = 102;
            this.f1200.Text = " ";
            this.f1200.Click += new System.EventHandler(this.a0800_Click);
            // 
            // f0900
            // 
            this.f0900.BackColor = System.Drawing.Color.LightGreen;
            this.f0900.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f0900.Location = new System.Drawing.Point(51, 71);
            this.f0900.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.f0900.Name = "f0900";
            this.f0900.Size = new System.Drawing.Size(90, 25);
            this.f0900.TabIndex = 99;
            this.f0900.Text = " ";
            this.f0900.Click += new System.EventHandler(this.a0800_Click);
            // 
            // f0800
            // 
            this.f0800.BackColor = System.Drawing.Color.LightGreen;
            this.f0800.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f0800.Location = new System.Drawing.Point(51, 25);
            this.f0800.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.f0800.Name = "f0800";
            this.f0800.Size = new System.Drawing.Size(90, 25);
            this.f0800.TabIndex = 98;
            this.f0800.Text = " ";
            this.f0800.Click += new System.EventHandler(this.a0800_Click);
            // 
            // f1100
            // 
            this.f1100.BackColor = System.Drawing.Color.LightGreen;
            this.f1100.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f1100.Location = new System.Drawing.Point(53, 162);
            this.f1100.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.f1100.Name = "f1100";
            this.f1100.Size = new System.Drawing.Size(90, 25);
            this.f1100.TabIndex = 101;
            this.f1100.Text = " ";
            this.f1100.Click += new System.EventHandler(this.a0800_Click);
            // 
            // f1300
            // 
            this.f1300.BackColor = System.Drawing.Color.LightGreen;
            this.f1300.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f1300.Location = new System.Drawing.Point(53, 253);
            this.f1300.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.f1300.Name = "f1300";
            this.f1300.Size = new System.Drawing.Size(90, 25);
            this.f1300.TabIndex = 103;
            this.f1300.Text = " ";
            this.f1300.Click += new System.EventHandler(this.a0800_Click);
            // 
            // f1000
            // 
            this.f1000.BackColor = System.Drawing.Color.LightGreen;
            this.f1000.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f1000.Location = new System.Drawing.Point(53, 116);
            this.f1000.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.f1000.Name = "f1000";
            this.f1000.Size = new System.Drawing.Size(90, 25);
            this.f1000.TabIndex = 100;
            this.f1000.Text = " ";
            this.f1000.Click += new System.EventHandler(this.a0800_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.b0800);
            this.panel2.Controls.Add(this.b1800);
            this.panel2.Controls.Add(this.b1200);
            this.panel2.Controls.Add(this.b1300);
            this.panel2.Controls.Add(this.b1600);
            this.panel2.Controls.Add(this.b0900);
            this.panel2.Controls.Add(this.b2000);
            this.panel2.Controls.Add(this.b1100);
            this.panel2.Controls.Add(this.b1500);
            this.panel2.Controls.Add(this.b1700);
            this.panel2.Controls.Add(this.b1400);
            this.panel2.Controls.Add(this.b1900);
            this.panel2.Controls.Add(this.b1000);
            this.panel2.Location = new System.Drawing.Point(394, 166);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(189, 596);
            this.panel2.TabIndex = 80;
            this.panel2.Click += new System.EventHandler(this.a0800_Click);
            // 
            // c0800
            // 
            this.c0800.BackColor = System.Drawing.Color.LightGreen;
            this.c0800.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c0800.Location = new System.Drawing.Point(47, 15);
            this.c0800.Margin = new System.Windows.Forms.Padding(4, 0, 5, 0);
            this.c0800.Name = "c0800";
            this.c0800.Size = new System.Drawing.Size(90, 25);
            this.c0800.TabIndex = 55;
            this.c0800.Text = " ";
            this.c0800.Click += new System.EventHandler(this.a0800_Click);
            // 
            // c1000
            // 
            this.c1000.BackColor = System.Drawing.Color.LightGreen;
            this.c1000.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c1000.Location = new System.Drawing.Point(47, 103);
            this.c1000.Margin = new System.Windows.Forms.Padding(4, 0, 5, 0);
            this.c1000.Name = "c1000";
            this.c1000.Size = new System.Drawing.Size(90, 25);
            this.c1000.TabIndex = 42;
            this.c1000.Text = " ";
            this.c1000.Click += new System.EventHandler(this.a0800_Click);
            // 
            // c1300
            // 
            this.c1300.BackColor = System.Drawing.Color.LightGreen;
            this.c1300.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c1300.Location = new System.Drawing.Point(47, 238);
            this.c1300.Margin = new System.Windows.Forms.Padding(4, 0, 5, 0);
            this.c1300.Name = "c1300";
            this.c1300.Size = new System.Drawing.Size(90, 25);
            this.c1300.TabIndex = 47;
            this.c1300.Text = " ";
            this.c1300.Click += new System.EventHandler(this.a0800_Click);
            // 
            // c1700
            // 
            this.c1700.BackColor = System.Drawing.Color.LightGreen;
            this.c1700.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c1700.Location = new System.Drawing.Point(47, 419);
            this.c1700.Margin = new System.Windows.Forms.Padding(4, 0, 5, 0);
            this.c1700.Name = "c1700";
            this.c1700.Size = new System.Drawing.Size(90, 25);
            this.c1700.TabIndex = 43;
            this.c1700.Text = " ";
            this.c1700.Click += new System.EventHandler(this.a0800_Click);
            // 
            // c9000
            // 
            this.c9000.BackColor = System.Drawing.Color.LightGreen;
            this.c9000.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c9000.Location = new System.Drawing.Point(47, 58);
            this.c9000.Margin = new System.Windows.Forms.Padding(4, 0, 5, 0);
            this.c9000.Name = "c9000";
            this.c9000.Size = new System.Drawing.Size(90, 25);
            this.c9000.TabIndex = 45;
            this.c9000.Text = " ";
            this.c9000.Click += new System.EventHandler(this.a0800_Click);
            // 
            // c1400
            // 
            this.c1400.BackColor = System.Drawing.Color.LightGreen;
            this.c1400.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c1400.Location = new System.Drawing.Point(47, 283);
            this.c1400.Margin = new System.Windows.Forms.Padding(4, 0, 5, 0);
            this.c1400.Name = "c1400";
            this.c1400.Size = new System.Drawing.Size(90, 25);
            this.c1400.TabIndex = 49;
            this.c1400.Text = " ";
            this.c1400.Click += new System.EventHandler(this.a0800_Click);
            // 
            // c1600
            // 
            this.c1600.BackColor = System.Drawing.Color.LightGreen;
            this.c1600.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c1600.Location = new System.Drawing.Point(47, 374);
            this.c1600.Margin = new System.Windows.Forms.Padding(4, 0, 5, 0);
            this.c1600.Name = "c1600";
            this.c1600.Size = new System.Drawing.Size(90, 25);
            this.c1600.TabIndex = 53;
            this.c1600.Text = " ";
            this.c1600.Click += new System.EventHandler(this.a0800_Click);
            // 
            // c1500
            // 
            this.c1500.BackColor = System.Drawing.Color.LightGreen;
            this.c1500.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c1500.Location = new System.Drawing.Point(47, 328);
            this.c1500.Margin = new System.Windows.Forms.Padding(4, 0, 5, 0);
            this.c1500.Name = "c1500";
            this.c1500.Size = new System.Drawing.Size(90, 25);
            this.c1500.TabIndex = 51;
            this.c1500.Text = " ";
            this.c1500.Click += new System.EventHandler(this.a0800_Click);
            // 
            // c1900
            // 
            this.c1900.BackColor = System.Drawing.Color.LightGreen;
            this.c1900.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c1900.Location = new System.Drawing.Point(47, 508);
            this.c1900.Margin = new System.Windows.Forms.Padding(4, 0, 5, 0);
            this.c1900.Name = "c1900";
            this.c1900.Size = new System.Drawing.Size(90, 25);
            this.c1900.TabIndex = 41;
            this.c1900.Text = " ";
            this.c1900.Click += new System.EventHandler(this.a0800_Click);
            // 
            // c1100
            // 
            this.c1100.BackColor = System.Drawing.Color.LightGreen;
            this.c1100.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c1100.Location = new System.Drawing.Point(47, 148);
            this.c1100.Margin = new System.Windows.Forms.Padding(4, 0, 5, 0);
            this.c1100.Name = "c1100";
            this.c1100.Size = new System.Drawing.Size(90, 25);
            this.c1100.TabIndex = 44;
            this.c1100.Text = " ";
            this.c1100.Click += new System.EventHandler(this.a0800_Click);
            // 
            // c1200
            // 
            this.c1200.BackColor = System.Drawing.Color.LightGreen;
            this.c1200.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c1200.Location = new System.Drawing.Point(47, 192);
            this.c1200.Margin = new System.Windows.Forms.Padding(4, 0, 5, 0);
            this.c1200.Name = "c1200";
            this.c1200.Size = new System.Drawing.Size(90, 25);
            this.c1200.TabIndex = 46;
            this.c1200.Text = " ";
            this.c1200.Click += new System.EventHandler(this.a0800_Click);
            // 
            // c1800
            // 
            this.c1800.BackColor = System.Drawing.Color.LightGreen;
            this.c1800.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c1800.Location = new System.Drawing.Point(47, 463);
            this.c1800.Margin = new System.Windows.Forms.Padding(4, 0, 5, 0);
            this.c1800.Name = "c1800";
            this.c1800.Size = new System.Drawing.Size(90, 25);
            this.c1800.TabIndex = 48;
            this.c1800.Text = " ";
            this.c1800.Click += new System.EventHandler(this.a0800_Click);
            // 
            // c2000
            // 
            this.c2000.BackColor = System.Drawing.Color.LightGreen;
            this.c2000.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c2000.Location = new System.Drawing.Point(47, 552);
            this.c2000.Margin = new System.Windows.Forms.Padding(4, 0, 5, 0);
            this.c2000.Name = "c2000";
            this.c2000.Size = new System.Drawing.Size(90, 25);
            this.c2000.TabIndex = 50;
            this.c2000.Text = " ";
            this.c2000.Click += new System.EventHandler(this.a0800_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.c0800);
            this.panel3.Controls.Add(this.c2000);
            this.panel3.Controls.Add(this.c1000);
            this.panel3.Controls.Add(this.c1800);
            this.panel3.Controls.Add(this.c1300);
            this.panel3.Controls.Add(this.c1200);
            this.panel3.Controls.Add(this.c1700);
            this.panel3.Controls.Add(this.c1100);
            this.panel3.Controls.Add(this.c9000);
            this.panel3.Controls.Add(this.c1900);
            this.panel3.Controls.Add(this.c1400);
            this.panel3.Controls.Add(this.c1500);
            this.panel3.Controls.Add(this.c1600);
            this.panel3.Location = new System.Drawing.Point(629, 165);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(189, 596);
            this.panel3.TabIndex = 79;
            this.panel3.Click += new System.EventHandler(this.a0800_Click);
            // 
            // d1000
            // 
            this.d1000.BackColor = System.Drawing.Color.LightGreen;
            this.d1000.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.d1000.Location = new System.Drawing.Point(49, 106);
            this.d1000.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d1000.Name = "d1000";
            this.d1000.Size = new System.Drawing.Size(90, 25);
            this.d1000.TabIndex = 42;
            this.d1000.Text = " ";
            this.d1000.Click += new System.EventHandler(this.a0800_Click);
            // 
            // d0800
            // 
            this.d0800.BackColor = System.Drawing.Color.LightGreen;
            this.d0800.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.d0800.Location = new System.Drawing.Point(49, 17);
            this.d0800.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d0800.Name = "d0800";
            this.d0800.Size = new System.Drawing.Size(90, 25);
            this.d0800.TabIndex = 52;
            this.d0800.Text = " ";
            this.d0800.Click += new System.EventHandler(this.a0800_Click);
            // 
            // d1400
            // 
            this.d1400.BackColor = System.Drawing.Color.LightGreen;
            this.d1400.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.d1400.Location = new System.Drawing.Point(49, 284);
            this.d1400.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d1400.Name = "d1400";
            this.d1400.Size = new System.Drawing.Size(90, 25);
            this.d1400.TabIndex = 49;
            this.d1400.Text = " ";
            this.d1400.Click += new System.EventHandler(this.a0800_Click);
            // 
            // d1900
            // 
            this.d1900.BackColor = System.Drawing.Color.LightGreen;
            this.d1900.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.d1900.Location = new System.Drawing.Point(49, 509);
            this.d1900.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d1900.Name = "d1900";
            this.d1900.Size = new System.Drawing.Size(90, 25);
            this.d1900.TabIndex = 41;
            this.d1900.Text = " ";
            this.d1900.Click += new System.EventHandler(this.a0800_Click);
            // 
            // d1800
            // 
            this.d1800.BackColor = System.Drawing.Color.LightGreen;
            this.d1800.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.d1800.Location = new System.Drawing.Point(49, 464);
            this.d1800.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d1800.Name = "d1800";
            this.d1800.Size = new System.Drawing.Size(90, 25);
            this.d1800.TabIndex = 43;
            this.d1800.Text = " ";
            this.d1800.Click += new System.EventHandler(this.a0800_Click);
            // 
            // d1200
            // 
            this.d1200.BackColor = System.Drawing.Color.LightGreen;
            this.d1200.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.d1200.Location = new System.Drawing.Point(49, 197);
            this.d1200.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d1200.Name = "d1200";
            this.d1200.Size = new System.Drawing.Size(90, 25);
            this.d1200.TabIndex = 46;
            this.d1200.Text = " ";
            this.d1200.Click += new System.EventHandler(this.a0800_Click);
            // 
            // d1700
            // 
            this.d1700.BackColor = System.Drawing.Color.LightGreen;
            this.d1700.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.d1700.Location = new System.Drawing.Point(49, 421);
            this.d1700.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d1700.Name = "d1700";
            this.d1700.Size = new System.Drawing.Size(90, 25);
            this.d1700.TabIndex = 48;
            this.d1700.Text = " ";
            this.d1700.Click += new System.EventHandler(this.a0800_Click);
            // 
            // d2000
            // 
            this.d2000.BackColor = System.Drawing.Color.LightGreen;
            this.d2000.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.d2000.Location = new System.Drawing.Point(49, 556);
            this.d2000.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d2000.Name = "d2000";
            this.d2000.Size = new System.Drawing.Size(90, 25);
            this.d2000.TabIndex = 50;
            this.d2000.Text = " ";
            this.d2000.Click += new System.EventHandler(this.a0800_Click);
            // 
            // d0900
            // 
            this.d0900.BackColor = System.Drawing.Color.LightGreen;
            this.d0900.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.d0900.Location = new System.Drawing.Point(49, 61);
            this.d0900.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d0900.Name = "d0900";
            this.d0900.Size = new System.Drawing.Size(90, 25);
            this.d0900.TabIndex = 53;
            this.d0900.Text = " ";
            this.d0900.Click += new System.EventHandler(this.a0800_Click);
            // 
            // d1100
            // 
            this.d1100.BackColor = System.Drawing.Color.LightGreen;
            this.d1100.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.d1100.Location = new System.Drawing.Point(49, 153);
            this.d1100.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d1100.Name = "d1100";
            this.d1100.Size = new System.Drawing.Size(90, 25);
            this.d1100.TabIndex = 44;
            this.d1100.Text = " ";
            this.d1100.Click += new System.EventHandler(this.a0800_Click);
            // 
            // d1500
            // 
            this.d1500.BackColor = System.Drawing.Color.LightGreen;
            this.d1500.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.d1500.Location = new System.Drawing.Point(49, 329);
            this.d1500.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d1500.Name = "d1500";
            this.d1500.Size = new System.Drawing.Size(90, 25);
            this.d1500.TabIndex = 51;
            this.d1500.Text = " ";
            this.d1500.Click += new System.EventHandler(this.a0800_Click);
            // 
            // d1300
            // 
            this.d1300.BackColor = System.Drawing.Color.LightGreen;
            this.d1300.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.d1300.Location = new System.Drawing.Point(49, 245);
            this.d1300.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d1300.Name = "d1300";
            this.d1300.Size = new System.Drawing.Size(90, 25);
            this.d1300.TabIndex = 47;
            this.d1300.Text = " ";
            this.d1300.Click += new System.EventHandler(this.a0800_Click);
            // 
            // d1600
            // 
            this.d1600.BackColor = System.Drawing.Color.LightGreen;
            this.d1600.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.d1600.Location = new System.Drawing.Point(49, 374);
            this.d1600.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d1600.Name = "d1600";
            this.d1600.Size = new System.Drawing.Size(90, 25);
            this.d1600.TabIndex = 45;
            this.d1600.Text = " ";
            this.d1600.Click += new System.EventHandler(this.a0800_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.d1000);
            this.panel4.Controls.Add(this.d2000);
            this.panel4.Controls.Add(this.d0800);
            this.panel4.Controls.Add(this.d1600);
            this.panel4.Controls.Add(this.d1400);
            this.panel4.Controls.Add(this.d1300);
            this.panel4.Controls.Add(this.d1900);
            this.panel4.Controls.Add(this.d1500);
            this.panel4.Controls.Add(this.d1800);
            this.panel4.Controls.Add(this.d1100);
            this.panel4.Controls.Add(this.d1200);
            this.panel4.Controls.Add(this.d0900);
            this.panel4.Controls.Add(this.d1700);
            this.panel4.Location = new System.Drawing.Point(864, 165);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(189, 596);
            this.panel4.TabIndex = 78;
            this.panel4.Click += new System.EventHandler(this.a0800_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(45, 61);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(112, 22);
            this.dateTimePicker1.TabIndex = 56;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Showcard Gothic", 9.75F);
            this.label14.Location = new System.Drawing.Point(87, 720);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 21);
            this.label14.TabIndex = 70;
            this.label14.Text = "20:00";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Showcard Gothic", 9.75F);
            this.label13.Location = new System.Drawing.Point(87, 674);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 21);
            this.label13.TabIndex = 69;
            this.label13.Text = "19:00";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Showcard Gothic", 9.75F);
            this.label11.Location = new System.Drawing.Point(87, 629);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 21);
            this.label11.TabIndex = 67;
            this.label11.Text = "18:00";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Showcard Gothic", 9.75F);
            this.label10.Location = new System.Drawing.Point(87, 538);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 21);
            this.label10.TabIndex = 66;
            this.label10.Text = "16:00";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Showcard Gothic", 9.75F);
            this.label9.Location = new System.Drawing.Point(87, 492);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 21);
            this.label9.TabIndex = 65;
            this.label9.Text = "15:00";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Showcard Gothic", 9.75F);
            this.label8.Location = new System.Drawing.Point(87, 447);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 21);
            this.label8.TabIndex = 64;
            this.label8.Text = "14:00";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Showcard Gothic", 9.75F);
            this.label7.Location = new System.Drawing.Point(87, 401);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 21);
            this.label7.TabIndex = 63;
            this.label7.Text = "13:00";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Showcard Gothic", 9.75F);
            this.label6.Location = new System.Drawing.Point(87, 356);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 21);
            this.label6.TabIndex = 62;
            this.label6.Text = "12:00";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Showcard Gothic", 9.75F);
            this.label5.Location = new System.Drawing.Point(87, 310);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 21);
            this.label5.TabIndex = 61;
            this.label5.Text = "11:00";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Showcard Gothic", 9.75F);
            this.label4.Location = new System.Drawing.Point(87, 265);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 21);
            this.label4.TabIndex = 60;
            this.label4.Text = "10:00";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Showcard Gothic", 9.75F);
            this.label3.Location = new System.Drawing.Point(87, 219);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 21);
            this.label3.TabIndex = 59;
            this.label3.Text = "09:00";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Showcard Gothic", 9.75F);
            this.label2.Location = new System.Drawing.Point(87, 583);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 21);
            this.label2.TabIndex = 58;
            this.label2.Text = "17:00";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(87, 174);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 21);
            this.label1.TabIndex = 57;
            this.label1.Text = "08:00";
            // 
            // a1700
            // 
            this.a1700.BackColor = System.Drawing.Color.LightGreen;
            this.a1700.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.a1700.Location = new System.Drawing.Point(47, 421);
            this.a1700.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a1700.Name = "a1700";
            this.a1700.Size = new System.Drawing.Size(90, 25);
            this.a1700.TabIndex = 41;
            this.a1700.Text = " ";
            this.a1700.Click += new System.EventHandler(this.a0800_Click);
            // 
            // a2000
            // 
            this.a2000.BackColor = System.Drawing.Color.LightGreen;
            this.a2000.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.a2000.Location = new System.Drawing.Point(47, 558);
            this.a2000.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a2000.Name = "a2000";
            this.a2000.Size = new System.Drawing.Size(90, 25);
            this.a2000.TabIndex = 95;
            this.a2000.Text = " ";
            this.a2000.Click += new System.EventHandler(this.a0800_Click);
            // 
            // a1000
            // 
            this.a1000.BackColor = System.Drawing.Color.LightGreen;
            this.a1000.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.a1000.Location = new System.Drawing.Point(47, 102);
            this.a1000.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a1000.Name = "a1000";
            this.a1000.Size = new System.Drawing.Size(90, 25);
            this.a1000.TabIndex = 27;
            this.a1000.Text = " ";
            this.a1000.Click += new System.EventHandler(this.a0800_Click);
            // 
            // a1400
            // 
            this.a1400.BackColor = System.Drawing.Color.LightGreen;
            this.a1400.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.a1400.Location = new System.Drawing.Point(47, 284);
            this.a1400.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a1400.Name = "a1400";
            this.a1400.Size = new System.Drawing.Size(90, 25);
            this.a1400.TabIndex = 35;
            this.a1400.Text = " ";
            this.a1400.Click += new System.EventHandler(this.a0800_Click);
            // 
            // a1500
            // 
            this.a1500.BackColor = System.Drawing.Color.LightGreen;
            this.a1500.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.a1500.Location = new System.Drawing.Point(47, 330);
            this.a1500.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a1500.Name = "a1500";
            this.a1500.Size = new System.Drawing.Size(90, 25);
            this.a1500.TabIndex = 37;
            this.a1500.Text = " ";
            this.a1500.Click += new System.EventHandler(this.a0800_Click);
            // 
            // a0800
            // 
            this.a0800.BackColor = System.Drawing.Color.LightGreen;
            this.a0800.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.a0800.Location = new System.Drawing.Point(45, 11);
            this.a0800.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a0800.Name = "a0800";
            this.a0800.Size = new System.Drawing.Size(90, 25);
            this.a0800.TabIndex = 22;
            this.a0800.Text = " ";
            this.a0800.Click += new System.EventHandler(this.a0800_Click);
            // 
            // a1100
            // 
            this.a1100.BackColor = System.Drawing.Color.LightGreen;
            this.a1100.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.a1100.Location = new System.Drawing.Point(47, 148);
            this.a1100.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a1100.Name = "a1100";
            this.a1100.Size = new System.Drawing.Size(90, 25);
            this.a1100.TabIndex = 29;
            this.a1100.Text = " ";
            this.a1100.Click += new System.EventHandler(this.a0800_Click);
            // 
            // a1300
            // 
            this.a1300.BackColor = System.Drawing.Color.LightGreen;
            this.a1300.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.a1300.Location = new System.Drawing.Point(47, 239);
            this.a1300.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a1300.Name = "a1300";
            this.a1300.Size = new System.Drawing.Size(90, 25);
            this.a1300.TabIndex = 32;
            this.a1300.Text = " ";
            this.a1300.Click += new System.EventHandler(this.a0800_Click);
            // 
            // a1900
            // 
            this.a1900.BackColor = System.Drawing.Color.LightGreen;
            this.a1900.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.a1900.Location = new System.Drawing.Point(47, 512);
            this.a1900.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a1900.Name = "a1900";
            this.a1900.Size = new System.Drawing.Size(90, 25);
            this.a1900.TabIndex = 96;
            this.a1900.Text = " ";
            this.a1900.Click += new System.EventHandler(this.a0800_Click);
            // 
            // a0900
            // 
            this.a0900.BackColor = System.Drawing.Color.LightGreen;
            this.a0900.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.a0900.Location = new System.Drawing.Point(45, 57);
            this.a0900.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a0900.Name = "a0900";
            this.a0900.Size = new System.Drawing.Size(90, 25);
            this.a0900.TabIndex = 25;
            this.a0900.Text = " ";
            this.a0900.Click += new System.EventHandler(this.a0800_Click);
            // 
            // a1200
            // 
            this.a1200.BackColor = System.Drawing.Color.LightGreen;
            this.a1200.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.a1200.Location = new System.Drawing.Point(47, 193);
            this.a1200.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a1200.Name = "a1200";
            this.a1200.Size = new System.Drawing.Size(90, 25);
            this.a1200.TabIndex = 31;
            this.a1200.Text = " ";
            this.a1200.Click += new System.EventHandler(this.a0800_Click);
            // 
            // a1600
            // 
            this.a1600.BackColor = System.Drawing.Color.LightGreen;
            this.a1600.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.a1600.Location = new System.Drawing.Point(47, 375);
            this.a1600.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a1600.Name = "a1600";
            this.a1600.Size = new System.Drawing.Size(90, 25);
            this.a1600.TabIndex = 39;
            this.a1600.Text = " ";
            this.a1600.Click += new System.EventHandler(this.a0800_Click);
            // 
            // a1800
            // 
            this.a1800.BackColor = System.Drawing.Color.LightGreen;
            this.a1800.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.a1800.Location = new System.Drawing.Point(47, 466);
            this.a1800.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a1800.Name = "a1800";
            this.a1800.Size = new System.Drawing.Size(90, 25);
            this.a1800.TabIndex = 97;
            this.a1800.Text = " ";
            this.a1800.Click += new System.EventHandler(this.a0800_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.a1900);
            this.panel1.Controls.Add(this.a1700);
            this.panel1.Controls.Add(this.a1800);
            this.panel1.Controls.Add(this.a1600);
            this.panel1.Controls.Add(this.a2000);
            this.panel1.Controls.Add(this.a1200);
            this.panel1.Controls.Add(this.a0800);
            this.panel1.Controls.Add(this.a0900);
            this.panel1.Controls.Add(this.a1000);
            this.panel1.Controls.Add(this.a1300);
            this.panel1.Controls.Add(this.a1100);
            this.panel1.Controls.Add(this.a1400);
            this.panel1.Controls.Add(this.a1500);
            this.panel1.Location = new System.Drawing.Point(163, 165);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(185, 597);
            this.panel1.TabIndex = 98;
            this.panel1.Click += new System.EventHandler(this.a0800_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(45, 24);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(112, 24);
            this.comboBox1.Sorted = true;
            this.comboBox1.TabIndex = 99;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(171, 27);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(39, 17);
            this.label12.TabIndex = 100;
            this.label12.Text = "מורה:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(240, 27);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(112, 22);
            this.textBox1.TabIndex = 101;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(168, 64);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(42, 17);
            this.label15.TabIndex = 102;
            this.label15.Text = "תאריך";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(359, 27);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(42, 17);
            this.label16.TabIndex = 103;
            this.label16.Text = "תלמיד";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(360, 64);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(41, 17);
            this.label17.TabIndex = 105;
            this.label17.Text = "רישיון";
            // 
            // txtLicence
            // 
            this.txtLicence.Location = new System.Drawing.Point(240, 59);
            this.txtLicence.Margin = new System.Windows.Forms.Padding(4);
            this.txtLicence.Name = "txtLicence";
            this.txtLicence.Size = new System.Drawing.Size(113, 22);
            this.txtLicence.TabIndex = 104;
            this.txtLicence.TextChanged += new System.EventHandler(this.txtLicence_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.txtLicence);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Location = new System.Drawing.Point(32, 30);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(420, 100);
            this.groupBox1.TabIndex = 106;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "פרטים";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DriveSchool.Properties.Resources.לוגו1;
            this.pictureBox1.Location = new System.Drawing.Point(1289, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(266, 138);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 107;
            this.pictureBox1.TabStop = false;
            // 
            // frmScedualeLesson
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1567, 910);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.b_date);
            this.Controls.Add(this.c_date);
            this.Controls.Add(this.b_name);
            this.Controls.Add(this.d_date);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.e_date);
            this.Controls.Add(this.f_date);
            this.Controls.Add(this.a_date);
            this.Controls.Add(this.c_name);
            this.Controls.Add(this.d_name);
            this.Controls.Add(this.e_name);
            this.Controls.Add(this.f_name);
            this.Controls.Add(this.a_name);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmScedualeLesson";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "מערכת שיעורים";
            this.Load += new System.EventHandler(this.frmScedualeLesson_Load);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label b_date;
        private System.Windows.Forms.Label c_date;
        private System.Windows.Forms.Label d_date;
        private System.Windows.Forms.Label e_date;
        private System.Windows.Forms.Label f_date;
        private System.Windows.Forms.Label a_date;
        private System.Windows.Forms.Label b_name;
        private System.Windows.Forms.Label c_name;
        private System.Windows.Forms.Label d_name;
        private System.Windows.Forms.Label e_name;
        private System.Windows.Forms.Label f_name;
        private System.Windows.Forms.Label a_name;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label a1700;
        private System.Windows.Forms.Label a2000;
        private System.Windows.Forms.Label a1000;
        private System.Windows.Forms.Label a1400;
        private System.Windows.Forms.Label a1500;
        private System.Windows.Forms.Label a0800;
        private System.Windows.Forms.Label a1100;
        private System.Windows.Forms.Label a1300;
        private System.Windows.Forms.Label a1900;
        private System.Windows.Forms.Label a0900;
        private System.Windows.Forms.Label a1200;
        private System.Windows.Forms.Label a1600;
        private System.Windows.Forms.Label a1800;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtLicence;
        private System.Windows.Forms.Label b1800;
        private System.Windows.Forms.Label b1600;
        private System.Windows.Forms.Label b2000;
        private System.Windows.Forms.Label b1500;
        private System.Windows.Forms.Label b1900;
        private System.Windows.Forms.Label b1000;
        private System.Windows.Forms.Label b1400;
        private System.Windows.Forms.Label b0800;
        private System.Windows.Forms.Label b1700;
        private System.Windows.Forms.Label b1100;
        private System.Windows.Forms.Label b0900;
        private System.Windows.Forms.Label b1300;
        private System.Windows.Forms.Label b1200;
        private System.Windows.Forms.Label c1000;
        private System.Windows.Forms.Label c1900;
        private System.Windows.Forms.Label c1200;
        private System.Windows.Forms.Label c1600;
        private System.Windows.Forms.Label c1300;
        private System.Windows.Forms.Label c1530;
        private System.Windows.Forms.Label c9000;
        private System.Windows.Forms.Label c1500;
        private System.Windows.Forms.Label c1100;
        private System.Windows.Forms.Label c2000;
        private System.Windows.Forms.Label c1800;
        private System.Windows.Forms.Label c1700;
        private System.Windows.Forms.Label c1400;
        private System.Windows.Forms.Label d1000;
        private System.Windows.Forms.Label d1900;
        private System.Windows.Forms.Label d1200;
        private System.Windows.Forms.Label d0900;
        private System.Windows.Forms.Label d1300;
        private System.Windows.Forms.Label d0800;
        private System.Windows.Forms.Label d1600;
        private System.Windows.Forms.Label d1500;
        private System.Windows.Forms.Label d1100;
        private System.Windows.Forms.Label d2000;
        private System.Windows.Forms.Label d1700;
        private System.Windows.Forms.Label d1800;
        private System.Windows.Forms.Label d1400;
        private System.Windows.Forms.Label e1000;
        private System.Windows.Forms.Label e1900;
        private System.Windows.Forms.Label e1400;
        private System.Windows.Forms.Label e1200;
        private System.Windows.Forms.Label e1700;
        private System.Windows.Forms.Label e1600;
        private System.Windows.Forms.Label e2000;
        private System.Windows.Forms.Label e1300;
        private System.Windows.Forms.Label e0900;
        private System.Windows.Forms.Label e1100;
        private System.Windows.Forms.Label e1800;
        private System.Windows.Forms.Label e1500;
        private System.Windows.Forms.Label f1200;
        private System.Windows.Forms.Label f0900;
        private System.Windows.Forms.Label f0800;
        private System.Windows.Forms.Label f1100;
        private System.Windows.Forms.Label f1300;
        private System.Windows.Forms.Label f1000;
        private System.Windows.Forms.Label c0800;
        private System.Windows.Forms.Label e0800;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}