﻿namespace DriveSchool.Gui
{
    partial class Frmcity
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn_clean = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvcity = new System.Windows.Forms.DataGridView();
            this.grbadd = new System.Windows.Forms.GroupBox();
            this.lblsaved = new System.Windows.Forms.Label();
            this.lblnamecity = new System.Windows.Forms.Label();
            this.txtnamecity = new System.Windows.Forms.TextBox();
            this.btnok = new System.Windows.Forms.Button();
            this.grbform = new System.Windows.Forms.GroupBox();
            this.rdbadd = new System.Windows.Forms.RadioButton();
            this.rdbupdate = new System.Windows.Forms.RadioButton();
            this.txtreserchcity = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvcity)).BeginInit();
            this.grbadd.SuspendLayout();
            this.grbform.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_clean
            // 
            this.btn_clean.BackColor = System.Drawing.Color.Navy;
            this.btn_clean.ForeColor = System.Drawing.Color.White;
            this.btn_clean.Location = new System.Drawing.Point(25, 95);
            this.btn_clean.Margin = new System.Windows.Forms.Padding(4);
            this.btn_clean.Name = "btn_clean";
            this.btn_clean.Size = new System.Drawing.Size(59, 23);
            this.btn_clean.TabIndex = 18;
            this.btn_clean.Text = "נקה";
            this.btn_clean.UseVisualStyleBackColor = false;
            this.btn_clean.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(993, 295);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 17);
            this.label1.TabIndex = 17;
            // 
            // dgvcity
            // 
            this.dgvcity.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvcity.Location = new System.Drawing.Point(30, 121);
            this.dgvcity.Margin = new System.Windows.Forms.Padding(5);
            this.dgvcity.MultiSelect = false;
            this.dgvcity.Name = "dgvcity";
            this.dgvcity.RowHeadersWidth = 51;
            this.dgvcity.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvcity.Size = new System.Drawing.Size(248, 297);
            this.dgvcity.TabIndex = 16;
            this.dgvcity.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvcity_RowHeaderMouseDoubleClick);
            // 
            // grbadd
            // 
            this.grbadd.Controls.Add(this.lblsaved);
            this.grbadd.Controls.Add(this.lblnamecity);
            this.grbadd.Controls.Add(this.txtnamecity);
            this.grbadd.Controls.Add(this.btnok);
            this.grbadd.Location = new System.Drawing.Point(288, 274);
            this.grbadd.Margin = new System.Windows.Forms.Padding(5);
            this.grbadd.Name = "grbadd";
            this.grbadd.Padding = new System.Windows.Forms.Padding(5);
            this.grbadd.Size = new System.Drawing.Size(218, 144);
            this.grbadd.TabIndex = 15;
            this.grbadd.TabStop = false;
            this.grbadd.Text = "הוספה";
            // 
            // lblsaved
            // 
            this.lblsaved.AutoSize = true;
            this.lblsaved.Location = new System.Drawing.Point(9, 93);
            this.lblsaved.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsaved.Name = "lblsaved";
            this.lblsaved.Size = new System.Drawing.Size(37, 17);
            this.lblsaved.TabIndex = 10;
            this.lblsaved.Text = "נשמר";
            this.lblsaved.Visible = false;
            // 
            // lblnamecity
            // 
            this.lblnamecity.AutoSize = true;
            this.lblnamecity.Location = new System.Drawing.Point(127, 49);
            this.lblnamecity.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblnamecity.Name = "lblnamecity";
            this.lblnamecity.Size = new System.Drawing.Size(48, 17);
            this.lblnamecity.TabIndex = 0;
            this.lblnamecity.Text = "שם עיר";
            // 
            // txtnamecity
            // 
            this.txtnamecity.Location = new System.Drawing.Point(29, 44);
            this.txtnamecity.Margin = new System.Windows.Forms.Padding(5);
            this.txtnamecity.Name = "txtnamecity";
            this.txtnamecity.Size = new System.Drawing.Size(88, 22);
            this.txtnamecity.TabIndex = 3;
            this.txtnamecity.TextChanged += new System.EventHandler(this.Txtnamecity_TextChanged);
            // 
            // btnok
            // 
            this.btnok.BackColor = System.Drawing.Color.Navy;
            this.btnok.ForeColor = System.Drawing.Color.White;
            this.btnok.Location = new System.Drawing.Point(55, 86);
            this.btnok.Margin = new System.Windows.Forms.Padding(5);
            this.btnok.Name = "btnok";
            this.btnok.Size = new System.Drawing.Size(104, 30);
            this.btnok.TabIndex = 2;
            this.btnok.Text = "אישור";
            this.btnok.UseVisualStyleBackColor = false;
            this.btnok.Click += new System.EventHandler(this.btnok_Click);
            // 
            // grbform
            // 
            this.grbform.Controls.Add(this.rdbadd);
            this.grbform.Controls.Add(this.rdbupdate);
            this.grbform.Location = new System.Drawing.Point(288, 123);
            this.grbform.Margin = new System.Windows.Forms.Padding(5);
            this.grbform.Name = "grbform";
            this.grbform.Padding = new System.Windows.Forms.Padding(5);
            this.grbform.Size = new System.Drawing.Size(105, 146);
            this.grbform.TabIndex = 14;
            this.grbform.TabStop = false;
            this.grbform.Text = "מצב טופס";
            // 
            // rdbadd
            // 
            this.rdbadd.AutoSize = true;
            this.rdbadd.Location = new System.Drawing.Point(19, 36);
            this.rdbadd.Margin = new System.Windows.Forms.Padding(5);
            this.rdbadd.Name = "rdbadd";
            this.rdbadd.Size = new System.Drawing.Size(65, 21);
            this.rdbadd.TabIndex = 5;
            this.rdbadd.TabStop = true;
            this.rdbadd.Text = "הוספה";
            this.rdbadd.UseVisualStyleBackColor = true;
            this.rdbadd.CheckedChanged += new System.EventHandler(this.rdbadd_CheckedChanged);
            // 
            // rdbupdate
            // 
            this.rdbupdate.AutoSize = true;
            this.rdbupdate.Location = new System.Drawing.Point(24, 75);
            this.rdbupdate.Margin = new System.Windows.Forms.Padding(5);
            this.rdbupdate.Name = "rdbupdate";
            this.rdbupdate.Size = new System.Drawing.Size(60, 21);
            this.rdbupdate.TabIndex = 6;
            this.rdbupdate.TabStop = true;
            this.rdbupdate.Text = "עדכון";
            this.rdbupdate.UseVisualStyleBackColor = true;
            this.rdbupdate.CheckedChanged += new System.EventHandler(this.rdbupdate_CheckedChanged);
            // 
            // txtreserchcity
            // 
            this.txtreserchcity.Location = new System.Drawing.Point(8, 51);
            this.txtreserchcity.Margin = new System.Windows.Forms.Padding(5);
            this.txtreserchcity.Name = "txtreserchcity";
            this.txtreserchcity.Size = new System.Drawing.Size(88, 22);
            this.txtreserchcity.TabIndex = 13;
            this.txtreserchcity.TextChanged += new System.EventHandler(this.txtreserchcity_TextChanged_1);
            this.txtreserchcity.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtreserchcity_KeyUp);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtreserchcity);
            this.groupBox1.Controls.Add(this.btn_clean);
            this.groupBox1.Location = new System.Drawing.Point(401, 121);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(105, 145);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "חיפוש";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DriveSchool.Properties.Resources.לוגו1;
            this.pictureBox1.Location = new System.Drawing.Point(30, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(476, 101);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // Frmcity
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(539, 441);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvcity);
            this.Controls.Add(this.grbadd);
            this.Controls.Add(this.grbform);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Frmcity";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "ערים";
            this.Load += new System.EventHandler(this.Frmcity_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.dgvcity)).EndInit();
            this.grbadd.ResumeLayout(false);
            this.grbadd.PerformLayout();
            this.grbform.ResumeLayout(false);
            this.grbform.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_clean;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvcity;
        private System.Windows.Forms.GroupBox grbadd;
        private System.Windows.Forms.Label lblsaved;
        private System.Windows.Forms.Label lblnamecity;
        private System.Windows.Forms.TextBox txtnamecity;
        private System.Windows.Forms.Button btnok;
        private System.Windows.Forms.GroupBox grbform;
        private System.Windows.Forms.RadioButton rdbadd;
        private System.Windows.Forms.RadioButton rdbupdate;
        private System.Windows.Forms.TextBox txtreserchcity;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}