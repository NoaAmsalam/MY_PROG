﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmTeacherCourse : DriveSchool.Form1
    {
        Bll.teacher teacher;
        Bll.teachertable teachertable;
        Bll.techerCourse techerCourse;
        Bll.techerCourseTable techerCourseTable;
        Bll.Course course;
        public frmTeacherCourse(Bll.teacher t)
        {
            InitializeComponent();
            txtLicenceStudent.Text = t.ToString();
            //הצגת הנתונים בפקד הרשימה    
            Bll.CourseTable ct = new Bll.CourseTable();
            comboBox1.DataSource = ct.GetList();
            techerCourseTable = new Bll.techerCourseTable();
            teacher = t;
        }
        public bool Check()
        {


            techerCourse = new Bll.techerCourse();

            try
            {
                techerCourse.CourseId = ((Bll.Course)comboBox1.SelectedItem).CourseId;

            }

            catch (Exception)
            {
                errorProvider1.SetError(comboBox1, "Kא עוב");
                return false;
            }
            try
            {
                techerCourse.TeacherId = teacher.TeacherId;
            }
            catch (Exception)
            {
                errorProvider1.SetError(txtLicenceStudent, "hKא עוב");
                return false;
            }
            return true;



        }
        public bool ifteacher()
        {
            //בדיקה האם קיים רישיון למורה כזה
            techerCourse = techerCourseTable.GetList().FirstOrDefault(x => x.TeacherId == teacher.TeacherId && x.CourseId == ((Bll.Course)comboBox1.SelectedItem).CourseId);
            if (techerCourse == null)
                return true;
            return false;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ifteacher())
            {
                if (Check())
                {
                    try
                    {
                        techerCourseTable.Add(techerCourse);
                        MessageBox.Show("המורה לקורס נוסף בהצלחה");
                    }
                    catch
                    {
                        MessageBox.Show("בעיה בהוספת המורה לקורס");
                    }
                    this.Close();
                }
            }
            else
                MessageBox.Show("רישיון זה קיים למורה הנוכחי"); 
        }

        private void frmTeacherCourse_Load(object sender, EventArgs e)
        {

        }
    }
}

