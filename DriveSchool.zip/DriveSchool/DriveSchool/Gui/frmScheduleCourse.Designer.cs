﻿
namespace DriveSchool.Gui
{
    partial class frmScheduleCourse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label15 = new System.Windows.Forms.Label();
            this.a1000 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.a1400 = new System.Windows.Forms.Label();
            this.a1200 = new System.Windows.Forms.Label();
            this.b_date = new System.Windows.Forms.Label();
            this.c_date = new System.Windows.Forms.Label();
            this.d_date = new System.Windows.Forms.Label();
            this.e_date = new System.Windows.Forms.Label();
            this.a_date = new System.Windows.Forms.Label();
            this.b_name = new System.Windows.Forms.Label();
            this.c_name = new System.Windows.Forms.Label();
            this.d_name = new System.Windows.Forms.Label();
            this.e_name = new System.Windows.Forms.Label();
            this.a_name = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.b1400 = new System.Windows.Forms.Label();
            this.b1200 = new System.Windows.Forms.Label();
            this.b1000 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.c1400 = new System.Windows.Forms.Label();
            this.c1200 = new System.Windows.Forms.Label();
            this.c1000 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.d1400 = new System.Windows.Forms.Label();
            this.d1200 = new System.Windows.Forms.Label();
            this.d1000 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.e1400 = new System.Windows.Forms.Label();
            this.e1200 = new System.Windows.Forms.Label();
            this.e1000 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.lblroom = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lblprice = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lblplace = new System.Windows.Forms.Label();
            this.lblteacher = new System.Windows.Forms.Label();
            this.lbltime = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(113, 53);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(42, 17);
            this.label15.TabIndex = 141;
            this.label15.Text = "תאריך";
            // 
            // a1000
            // 
            this.a1000.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.a1000.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.a1000.Location = new System.Drawing.Point(25, 61);
            this.a1000.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a1000.Name = "a1000";
            this.a1000.Size = new System.Drawing.Size(137, 74);
            this.a1000.TabIndex = 22;
            this.a1000.Text = " ";
            this.a1000.Click += new System.EventHandler(this.a0800_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(176, 52);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(112, 22);
            this.dateTimePicker1.TabIndex = 106;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged_1);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.a1400);
            this.panel1.Controls.Add(this.a1200);
            this.panel1.Controls.Add(this.a1000);
            this.panel1.Location = new System.Drawing.Point(103, 180);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(185, 375);
            this.panel1.TabIndex = 137;
            // 
            // a1400
            // 
            this.a1400.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.a1400.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.a1400.Location = new System.Drawing.Point(25, 274);
            this.a1400.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a1400.Name = "a1400";
            this.a1400.Size = new System.Drawing.Size(137, 74);
            this.a1400.TabIndex = 97;
            this.a1400.Text = " ";
            this.a1400.Click += new System.EventHandler(this.a0800_Click);
            // 
            // a1200
            // 
            this.a1200.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.a1200.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.a1200.Font = new System.Drawing.Font("Trebuchet MS", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a1200.Location = new System.Drawing.Point(25, 170);
            this.a1200.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a1200.Name = "a1200";
            this.a1200.Size = new System.Drawing.Size(137, 74);
            this.a1200.TabIndex = 96;
            this.a1200.Text = " ";
            this.a1200.Click += new System.EventHandler(this.a0800_Click);
            this.a1200.DoubleClick += new System.EventHandler(this.a1200_DoubleClick);
            // 
            // b_date
            // 
            this.b_date.AutoSize = true;
            this.b_date.Location = new System.Drawing.Point(459, 159);
            this.b_date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b_date.Name = "b_date";
            this.b_date.Size = new System.Drawing.Size(52, 17);
            this.b_date.TabIndex = 136;
            this.b_date.Text = "b_date";
            // 
            // c_date
            // 
            this.c_date.AutoSize = true;
            this.c_date.Location = new System.Drawing.Point(685, 159);
            this.c_date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.c_date.Name = "c_date";
            this.c_date.Size = new System.Drawing.Size(51, 17);
            this.c_date.TabIndex = 135;
            this.c_date.Text = "c_date";
            // 
            // d_date
            // 
            this.d_date.AutoSize = true;
            this.d_date.Location = new System.Drawing.Point(912, 159);
            this.d_date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d_date.Name = "d_date";
            this.d_date.Size = new System.Drawing.Size(52, 17);
            this.d_date.TabIndex = 134;
            this.d_date.Text = "d_date";
            // 
            // e_date
            // 
            this.e_date.AutoSize = true;
            this.e_date.Location = new System.Drawing.Point(1139, 159);
            this.e_date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e_date.Name = "e_date";
            this.e_date.Size = new System.Drawing.Size(52, 17);
            this.e_date.TabIndex = 133;
            this.e_date.Text = "e_date";
            // 
            // a_date
            // 
            this.a_date.AutoSize = true;
            this.a_date.Location = new System.Drawing.Point(232, 159);
            this.a_date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a_date.Name = "a_date";
            this.a_date.Size = new System.Drawing.Size(52, 17);
            this.a_date.TabIndex = 131;
            this.a_date.Text = "a_date";
            // 
            // b_name
            // 
            this.b_name.AutoSize = true;
            this.b_name.Font = new System.Drawing.Font("Snap ITC", 9.75F, System.Drawing.FontStyle.Bold);
            this.b_name.Location = new System.Drawing.Point(385, 154);
            this.b_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b_name.Name = "b_name";
            this.b_name.Size = new System.Drawing.Size(36, 23);
            this.b_name.TabIndex = 130;
            this.b_name.Text = "שני";
            // 
            // c_name
            // 
            this.c_name.AutoSize = true;
            this.c_name.Font = new System.Drawing.Font("Snap ITC", 9.75F, System.Drawing.FontStyle.Bold);
            this.c_name.Location = new System.Drawing.Point(612, 154);
            this.c_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.c_name.Name = "c_name";
            this.c_name.Size = new System.Drawing.Size(58, 23);
            this.c_name.TabIndex = 129;
            this.c_name.Text = "שלישי";
            // 
            // d_name
            // 
            this.d_name.AutoSize = true;
            this.d_name.Font = new System.Drawing.Font("Snap ITC", 9.75F, System.Drawing.FontStyle.Bold);
            this.d_name.Location = new System.Drawing.Point(839, 154);
            this.d_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d_name.Name = "d_name";
            this.d_name.Size = new System.Drawing.Size(51, 23);
            this.d_name.TabIndex = 128;
            this.d_name.Text = "רביעי";
            // 
            // e_name
            // 
            this.e_name.AutoSize = true;
            this.e_name.Font = new System.Drawing.Font("Snap ITC", 9.75F, System.Drawing.FontStyle.Bold);
            this.e_name.Location = new System.Drawing.Point(1065, 154);
            this.e_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e_name.Name = "e_name";
            this.e_name.Size = new System.Drawing.Size(58, 23);
            this.e_name.TabIndex = 127;
            this.e_name.Text = "חמישי";
            // 
            // a_name
            // 
            this.a_name.AutoSize = true;
            this.a_name.Font = new System.Drawing.Font("Snap ITC", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a_name.Location = new System.Drawing.Point(165, 154);
            this.a_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a_name.Name = "a_name";
            this.a_name.Size = new System.Drawing.Size(56, 23);
            this.a_name.TabIndex = 125;
            this.a_name.Text = "ראשון";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.b1400);
            this.panel2.Controls.Add(this.b1200);
            this.panel2.Controls.Add(this.b1000);
            this.panel2.Location = new System.Drawing.Point(323, 179);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(189, 376);
            this.panel2.TabIndex = 124;
            // 
            // b1400
            // 
            this.b1400.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.b1400.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b1400.Location = new System.Drawing.Point(26, 275);
            this.b1400.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b1400.Name = "b1400";
            this.b1400.Size = new System.Drawing.Size(137, 74);
            this.b1400.TabIndex = 100;
            this.b1400.Text = " ";
            this.b1400.Click += new System.EventHandler(this.a0800_Click);
            // 
            // b1200
            // 
            this.b1200.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.b1200.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b1200.Font = new System.Drawing.Font("Trebuchet MS", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b1200.Location = new System.Drawing.Point(26, 171);
            this.b1200.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b1200.Name = "b1200";
            this.b1200.Size = new System.Drawing.Size(137, 74);
            this.b1200.TabIndex = 99;
            this.b1200.Text = " ";
            this.b1200.Click += new System.EventHandler(this.a0800_Click);
            // 
            // b1000
            // 
            this.b1000.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.b1000.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b1000.Location = new System.Drawing.Point(26, 62);
            this.b1000.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b1000.Name = "b1000";
            this.b1000.Size = new System.Drawing.Size(137, 74);
            this.b1000.TabIndex = 98;
            this.b1000.Text = " ";
            this.b1000.Click += new System.EventHandler(this.a0800_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.c1400);
            this.panel3.Controls.Add(this.c1200);
            this.panel3.Controls.Add(this.c1000);
            this.panel3.Location = new System.Drawing.Point(549, 179);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(189, 376);
            this.panel3.TabIndex = 122;
            this.panel3.Click += new System.EventHandler(this.a0800_Click);
            // 
            // c1400
            // 
            this.c1400.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.c1400.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c1400.Location = new System.Drawing.Point(31, 275);
            this.c1400.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.c1400.Name = "c1400";
            this.c1400.Size = new System.Drawing.Size(137, 74);
            this.c1400.TabIndex = 103;
            this.c1400.Text = " ";
            this.c1400.Click += new System.EventHandler(this.a0800_Click);
            // 
            // c1200
            // 
            this.c1200.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.c1200.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c1200.Font = new System.Drawing.Font("Trebuchet MS", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c1200.Location = new System.Drawing.Point(31, 171);
            this.c1200.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.c1200.Name = "c1200";
            this.c1200.Size = new System.Drawing.Size(137, 74);
            this.c1200.TabIndex = 102;
            this.c1200.Text = " ";
            this.c1200.Click += new System.EventHandler(this.a0800_Click);
            // 
            // c1000
            // 
            this.c1000.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.c1000.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c1000.Location = new System.Drawing.Point(31, 62);
            this.c1000.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.c1000.Name = "c1000";
            this.c1000.Size = new System.Drawing.Size(137, 74);
            this.c1000.TabIndex = 101;
            this.c1000.Text = " ";
            this.c1000.Click += new System.EventHandler(this.a0800_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.d1400);
            this.panel4.Controls.Add(this.d1200);
            this.panel4.Controls.Add(this.d1000);
            this.panel4.Location = new System.Drawing.Point(776, 179);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(189, 376);
            this.panel4.TabIndex = 121;
            this.panel4.Click += new System.EventHandler(this.a0800_Click);
            // 
            // d1400
            // 
            this.d1400.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.d1400.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.d1400.Location = new System.Drawing.Point(26, 275);
            this.d1400.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d1400.Name = "d1400";
            this.d1400.Size = new System.Drawing.Size(137, 74);
            this.d1400.TabIndex = 100;
            this.d1400.Text = " ";
            this.d1400.Click += new System.EventHandler(this.a0800_Click);
            // 
            // d1200
            // 
            this.d1200.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.d1200.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.d1200.Font = new System.Drawing.Font("Trebuchet MS", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d1200.Location = new System.Drawing.Point(26, 171);
            this.d1200.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d1200.Name = "d1200";
            this.d1200.Size = new System.Drawing.Size(137, 74);
            this.d1200.TabIndex = 99;
            this.d1200.Text = " ";
            this.d1200.Click += new System.EventHandler(this.a0800_Click);
            // 
            // d1000
            // 
            this.d1000.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.d1000.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.d1000.Location = new System.Drawing.Point(26, 62);
            this.d1000.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d1000.Name = "d1000";
            this.d1000.Size = new System.Drawing.Size(137, 74);
            this.d1000.TabIndex = 98;
            this.d1000.Text = " ";
            this.d1000.Click += new System.EventHandler(this.a0800_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.e1400);
            this.panel5.Controls.Add(this.e1200);
            this.panel5.Controls.Add(this.e1000);
            this.panel5.Location = new System.Drawing.Point(1003, 179);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(189, 376);
            this.panel5.TabIndex = 120;
            this.panel5.Click += new System.EventHandler(this.a0800_Click);
            // 
            // e1400
            // 
            this.e1400.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.e1400.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.e1400.Location = new System.Drawing.Point(31, 275);
            this.e1400.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e1400.Name = "e1400";
            this.e1400.Size = new System.Drawing.Size(137, 74);
            this.e1400.TabIndex = 145;
            this.e1400.Text = " ";
            this.e1400.Click += new System.EventHandler(this.a0800_Click);
            // 
            // e1200
            // 
            this.e1200.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.e1200.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.e1200.Font = new System.Drawing.Font("Trebuchet MS", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e1200.Location = new System.Drawing.Point(31, 171);
            this.e1200.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e1200.Name = "e1200";
            this.e1200.Size = new System.Drawing.Size(137, 74);
            this.e1200.TabIndex = 144;
            this.e1200.Text = " ";
            this.e1200.Click += new System.EventHandler(this.a0800_Click);
            // 
            // e1000
            // 
            this.e1000.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.e1000.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.e1000.Location = new System.Drawing.Point(31, 62);
            this.e1000.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e1000.Name = "e1000";
            this.e1000.Size = new System.Drawing.Size(137, 74);
            this.e1000.TabIndex = 143;
            this.e1000.Text = " ";
            this.e1000.Click += new System.EventHandler(this.a0800_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Showcard Gothic", 9.75F);
            this.label10.Location = new System.Drawing.Point(27, 533);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 21);
            this.label10.TabIndex = 116;
            this.label10.Text = "16:00";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Showcard Gothic", 9.75F);
            this.label8.Location = new System.Drawing.Point(27, 426);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 21);
            this.label8.TabIndex = 114;
            this.label8.Text = "14:00";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Showcard Gothic", 9.75F);
            this.label6.Location = new System.Drawing.Point(29, 319);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 21);
            this.label6.TabIndex = 112;
            this.label6.Text = "12:00";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Showcard Gothic", 9.75F);
            this.label4.Location = new System.Drawing.Point(27, 212);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 21);
            this.label4.TabIndex = 110;
            this.label4.Text = "10:00";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.lblroom);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.lblprice);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.lblplace);
            this.groupBox1.Controls.Add(this.lblteacher);
            this.groupBox1.Controls.Add(this.lbltime);
            this.groupBox1.Controls.Add(this.lblname);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(169, 573);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(963, 100);
            this.groupBox1.TabIndex = 142;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "פרטים:";
            this.groupBox1.Visible = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(656, 66);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 17);
            this.label7.TabIndex = 144;
            this.label7.Text = "label7";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(19, 30);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(76, 62);
            this.button2.TabIndex = 143;
            this.button2.Text = "התלמידים לקורס";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lblroom
            // 
            this.lblroom.AutoSize = true;
            this.lblroom.Location = new System.Drawing.Point(320, 66);
            this.lblroom.Name = "lblroom";
            this.lblroom.Size = new System.Drawing.Size(54, 17);
            this.lblroom.TabIndex = 16;
            this.lblroom.Text = "lblroom";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(320, 30);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(55, 17);
            this.label21.TabIndex = 15;
            this.label21.Text = "שם חדר:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(19, 29);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(76, 59);
            this.button1.TabIndex = 14;
            this.button1.Text = "להרשמה";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblprice
            // 
            this.lblprice.AutoSize = true;
            this.lblprice.Location = new System.Drawing.Point(425, 66);
            this.lblprice.Name = "lblprice";
            this.lblprice.Size = new System.Drawing.Size(53, 17);
            this.lblprice.TabIndex = 13;
            this.lblprice.Text = "lblprice";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(429, 31);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(39, 17);
            this.label19.TabIndex = 12;
            this.label19.Text = "מחיר:";
            // 
            // lblplace
            // 
            this.lblplace.AutoSize = true;
            this.lblplace.Location = new System.Drawing.Point(180, 65);
            this.lblplace.Name = "lblplace";
            this.lblplace.Size = new System.Drawing.Size(56, 17);
            this.lblplace.TabIndex = 11;
            this.lblplace.Text = "lblplace";
            // 
            // lblteacher
            // 
            this.lblteacher.AutoSize = true;
            this.lblteacher.Location = new System.Drawing.Point(754, 65);
            this.lblteacher.Name = "lblteacher";
            this.lblteacher.Size = new System.Drawing.Size(70, 17);
            this.lblteacher.TabIndex = 9;
            this.lblteacher.Text = "lblteacher";
            // 
            // lbltime
            // 
            this.lbltime.AutoSize = true;
            this.lbltime.Location = new System.Drawing.Point(527, 65);
            this.lbltime.Name = "lbltime";
            this.lbltime.Size = new System.Drawing.Size(48, 17);
            this.lbltime.TabIndex = 8;
            this.lbltime.Text = "lbltime";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(864, 65);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(57, 17);
            this.lblname.TabIndex = 6;
            this.lblname.Text = "lblname";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(146, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(124, 17);
            this.label9.TabIndex = 5;
            this.label9.Text = "מספר מקומות פנויים:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(764, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 17);
            this.label5.TabIndex = 3;
            this.label5.Text = "שם מורה:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(514, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "שעת התחלה:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(634, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "תאריך התחלה:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(861, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "שם קורס:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DriveSchool.Properties.Resources.לוגו1;
            this.pictureBox1.Location = new System.Drawing.Point(549, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(643, 139);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 143;
            this.pictureBox1.TabStop = false;
            // 
            // frmScheduleCourse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1234, 699);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.b_date);
            this.Controls.Add(this.c_date);
            this.Controls.Add(this.d_date);
            this.Controls.Add(this.e_date);
            this.Controls.Add(this.a_date);
            this.Controls.Add(this.b_name);
            this.Controls.Add(this.c_name);
            this.Controls.Add(this.d_name);
            this.Controls.Add(this.e_name);
            this.Controls.Add(this.a_name);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Name = "frmScheduleCourse";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "מערכת קבוצות";
            this.Load += new System.EventHandler(this.frmScheduleCourse_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label a1000;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label a1400;
        private System.Windows.Forms.Label a1200;
        private System.Windows.Forms.Label b_date;
        private System.Windows.Forms.Label c_date;
        private System.Windows.Forms.Label d_date;
        private System.Windows.Forms.Label e_date;
        private System.Windows.Forms.Label a_date;
        private System.Windows.Forms.Label b_name;
        private System.Windows.Forms.Label c_name;
        private System.Windows.Forms.Label d_name;
        private System.Windows.Forms.Label e_name;
        private System.Windows.Forms.Label a_name;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblplace;
        private System.Windows.Forms.Label lblteacher;
        private System.Windows.Forms.Label lbltime;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblroom;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblprice;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label b1400;
        private System.Windows.Forms.Label b1200;
        private System.Windows.Forms.Label b1000;
        private System.Windows.Forms.Label c1400;
        private System.Windows.Forms.Label c1200;
        private System.Windows.Forms.Label c1000;
        private System.Windows.Forms.Label d1400;
        private System.Windows.Forms.Label d1200;
        private System.Windows.Forms.Label d1000;
        private System.Windows.Forms.Label e1400;
        private System.Windows.Forms.Label e1200;
        private System.Windows.Forms.Label e1000;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label7;
    }
}
