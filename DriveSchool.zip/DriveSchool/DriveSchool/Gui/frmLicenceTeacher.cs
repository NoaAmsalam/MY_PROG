﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmLicenceTeacher : DriveSchool.Form1
    {
        Bll.teacher teacher;
        Bll.teachertable teachertable;
        Bll.licencesTeacher licencesTeacher;
        Bll.licencesTeacherTable licencesTeacherTable;
        Bll.licences licences;
        public frmLicenceTeacher(Bll.teacher t)
        {
            InitializeComponent();
            txtLicenceStudent.Text = t.ToString();
            //הצגת הנתונים בפקד הרשימה    
            Bll.licencesTable ct = new Bll.licencesTable();
            comboBox1.DataSource = ct.GetList();
            licencesTeacherTable = new Bll.licencesTeacherTable();
            teacher = t;
        }
        public bool Check()
        {
            //בדיקה האם קיים רישיון למורה כזה
            licencesTeacher = licencesTeacherTable.GetList().FirstOrDefault(x => x.TecherId == teacher.TeacherId && x.LicenceId == ((Bll.licences)comboBox1.SelectedItem).LicenceId);
            if (licencesTeacher == null)
            {
                licencesTeacher = new Bll.licencesTeacher();
                licencesTeacher.LicenceId = ((Bll.licences)comboBox1.SelectedItem).LicenceId;
                licencesTeacher.TecherId = teacher.TeacherId;
                return true;
            }
            return false;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Check())
            {
                try
                {
                    licencesTeacherTable.Add(licencesTeacher);
                    MessageBox.Show("הרישיון נוסף בהצלחה");

                }
                catch
                {
                    MessageBox.Show("בעיה בהוספת רישיון");
                }
                this.Close();
            }
            else
                MessageBox.Show("רישיון זה קיים למורה הנוכחי");
        }

        private void frmLicenceTeacher_Load(object sender, EventArgs e)
        {

        }
    }
}
