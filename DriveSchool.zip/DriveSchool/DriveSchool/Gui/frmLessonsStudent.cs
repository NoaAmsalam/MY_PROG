﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using DriveSchool.Bll;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmLessonsStudent : Form
    {
        Bll.lessonActuallyTable lessonActuallyTable;
        Bll.lessonActually lessonActually;
        Bll.licencesStudentTable licencesStudentTable;
        Bll.licencesStudent licencesStudent;
        Bll.licences licences;
        licencesTable licencesTable;
        teacher teacher;
        student student;
        teachertable teachertable;


        public frmLessonsStudent(student s)
        {
            InitializeComponent();
            licencesStudentTable = new licencesStudentTable();
            lessonActually = new lessonActually();
            lessonActuallyTable = new lessonActuallyTable();
            //licencesStudent = new licencesStudent();
            student = s;
            teachertable = new teachertable();
            comboBox1.DataSource = teachertable.GetList();
            licencesTable = new licencesTable();
          
            licences = licencesStudentTable.GetList().FirstOrDefault(x => x.StudentId == s.StudentId && x.Test == false).GetLicences();
            licencesStudent = licencesStudentTable.GetList().FirstOrDefault(x => x.StudentId == s.StudentId && x.Test == false);
          //הצבת מספר שיעורים מנימלי ומספר שיעורים בפועל
            lblNumlessons.Text = licences.LessonMin.ToString();
            int count = 0;
            count = lessonActuallyTable.GetList().Where(x => x.StudentId == s.StudentId).Count();
            lblNumlesson.Text = count.ToString();
         
           
           //השמת שם תלמיד שם רישיון ומחיר תשלום
            txtNameStudent.Text = s.ToString();
            txtLicenceId.Text = licencesStudent.GetLicences().LicenceName;
      
            if(licencesStudent.PayPackage)
            {
                txtSum.Text =  licences.GlobalPrice.ToString();
            }
            else
            {
                txtSum.Text = (licences.PriceLesson * Convert.ToInt32(lblNumlesson.Text)).ToString();
            }
            //עד כאן
           
            dgvLessonActually.DataSource = lessonActuallyTable.GetList().Where(x => x.StudentId == s.StudentId).Select(x => new { x.LessonActuallyId, v = x.getTeacher().ToString(), x.DateLesson, x.TimeLesson ,x.Drow}).ToList();
            ChangeHeaders();

        }
        public void ChangeHeaders()
        {
            dgvLessonActually.Columns["lessonActuallyId"].HeaderText = "מספר שיעור";
            dgvLessonActually.Columns["v"].HeaderText = "שם מורה";
            dgvLessonActually.Columns["dateLesson"].HeaderText = "תאריך שיעור";
            dgvLessonActually.Columns["timeLesson"].HeaderText = "שעת שיעור";
        //    dgvLessonActually.Columns["isglobal"].HeaderText = "שולם גלובלי";
          // dgvLessonActually.Columns["studentId"].HeaderText = "קוד תלמיד";
          // dgvLessonActually.Columns["licenseTostudentid"].HeaderText = "קוד רישיון לתלמיד";
            
         
            dgvLessonActually.Columns["drow"].Visible = false;

        }

        private void DgvLessonActually_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FrmLessonsStudent_Load(object sender, EventArgs e)
        {

        }


        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void lblNumlessons_Click(object sender, EventArgs e)
        {

        }

        private void txtSum_TextChanged(object sender, EventArgs e)
        {

        }

        private void DateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime d = dateTimePicker1.Value;
            dgvLessonActually.DataSource = lessonActuallyTable.GetList().Where(x => x.StudentId == student.StudentId && x.DateLesson.Date == d.Date).Select(x => new { x.LessonActuallyId, v = x.getTeacher().ToString(), x.DateLesson, x.TimeLesson, x.Drow }).ToList();
            ChangeHeaders();
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dgvLessonActually.DataSource = lessonActuallyTable.GetList().Where(x => x.TecherId == ((Bll.teacher)comboBox1.SelectedItem).TeacherId).ToList();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            dgvLessonActually.DataSource = lessonActuallyTable.GetList().Where(x => x.StudentId == student.StudentId).Select(x => new { x.LessonActuallyId, v = x.getTeacher().ToString(), x.DateLesson, x.TimeLesson, x.Drow }).ToList();
            ChangeHeaders();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string d = comboBox2.Text;
            dgvLessonActually.DataSource = lessonActuallyTable.GetList().Where(x => x.StudentId == student.StudentId && x.TimeLesson == d).Select(x => new { x.LessonActuallyId, v = x.getTeacher().ToString(), x.DateLesson, x.TimeLesson,x.Drow }).ToList();
            ChangeHeaders();

        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            
            lessonActuallyTable = new lessonActuallyTable();
            teacher = new Bll.teacher();
            teacher = (Bll.teacher)comboBox1.SelectedItem;
            dgvLessonActually.DataSource = lessonActuallyTable.GetList().Where(x => x.StudentId == student.StudentId && x.TecherId == teacher.TeacherId).Select(x => new { x.LessonActuallyId, v = x.getTeacher().ToString(), x.DateLesson, x.TimeLesson, x.Drow }).ToList();
            ChangeHeaders();

        }
    }
}
