﻿using System;
using DriveSchool.Bll;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmCourse : Form
    {
         Bll.Course course;
        Bll.CourseTable courseTable;
        string state;
        public frmCourse()
        {
            InitializeComponent();
            state = "Add";
            course = new Course();
            courseTable = new CourseTable();
            course.CourseId = courseTable.getnewkey();
            lblKod.Text = course.CourseId.ToString();

           
        }
        public frmCourse(Course t)
        {
            InitializeComponent();
            state = "Update";

            course = t;
            courseTable = new CourseTable();

            FillTextBox();
        }
        public void FillTextBox()
        {
            lblKod.Text = course.CourseId.ToString();
            txtName.Text = course.CourseName.ToString();
            txtPrice.Text =(course.CoursePrice).ToString();
            nmcMax.Value = course.StudentMax;
            nmcMin.Value = course.StudentMin;
           
           
        }
        public bool Check()
        {
            bool ok = true;
            errorProvider1.Clear();
          
            try
            {
                course.CourseName = txtName.Text;
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtName, ex.Message);
                ok = false;
            }
            try
            {
                course.CoursePrice = Convert.ToInt32(txtPrice.Text);
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtPrice, ex.Message);
                ok = false;
            }
            try
            {
                course.StudentMin =Convert.ToInt32( nmcMin.Value);
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(nmcMin, ex.Message);
                ok = false;
            }
            try
            {
                course.StudentMax = Convert.ToInt32(nmcMax.Value);
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(nmcMax, ex.Message);
                ok = false;
            }
           
            return ok;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (Check())
            {
                if (state == "Add")
                {
                    try
                    {
                        courseTable.Add(course);
                        MessageBox.Show("הקורס נשמר בהצלחה");
                    }
                    catch
                    {
                        MessageBox.Show("בעיה בשמירת הקורס");
                    }
                    this.Close();
                }


                if (state == "Update")
                {
                    try
                    {
                        courseTable.Update(course);
                        MessageBox.Show("קורס עודכן בהצלחה");
                    }
                    catch
                    {
                        MessageBox.Show("בעיה בעידכון קורס");
                    }
                    this.Close();
                }
            }
        }

        private void nmcMin_ValueChanged(object sender, EventArgs e)
        {
           
        }

        private void nmcMax_ValueChanged(object sender, EventArgs e)
        {
            if (nmcMax.Value < nmcMin.Value)
            {
                nmcMax.Value = nmcMin.Value;
            }
        }

        private void frmCourse_Load(object sender, EventArgs e)
        {

        }
    }
}
