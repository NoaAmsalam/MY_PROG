﻿using DriveSchool.Bll;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmStudents : Form
    {
        studentTable studentTable;
        student student;
        string state;

        public frmStudents()
        {
            InitializeComponent();
            studentTable = new studentTable();
            student = new student();
            dgvStudents.DataSource = studentTable.GetList().Select(x => new { x.StudentId, x.StudentFirstName,x.StudentLastName, x.GetCity().CityName, x.Street, x.Num, x.Phone,x.Notes,x.BirthDate, x.GreenForm , x.Drow}).ToList();
            ChangeHeaders();
            
        }

        public void ChangeHeaders()
        {
            dgvStudents.Columns["studentId"].HeaderText = "תעודת זהות תלמיד";
            dgvStudents.Columns["studentFirstName"].HeaderText = "שם פרטי";
            dgvStudents.Columns["studentLastName"].HeaderText = "שם משפחה ";
            dgvStudents.Columns["cityname"].HeaderText = "עיר";
            dgvStudents.Columns["street"].HeaderText = "רחוב";
            dgvStudents.Columns["num"].HeaderText = "מספר בית ";
            dgvStudents.Columns["phone"].HeaderText = "פלאפון ";
            dgvStudents.Columns["notes"].HeaderText = "הערות";
            dgvStudents.Columns["greenForm"].HeaderText = "טופס ירוק";
            dgvStudents.Columns["birthDate"].HeaderText = "תאריך לידה";
            dgvStudents.Columns["drow"].Visible = false;

        }
        private void button2_Click(object sender, EventArgs e)
        {
            frmStudent f = new frmStudent();
            f.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            student = (student)dgvStudents.SelectedRows[0].Cells[0].Value;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmStudent f = new frmStudent(student);
            f.Show();
        }

        private void dgvStudents_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            string id = (dgvStudents.SelectedRows[0].Cells[0].Value).ToString();
            student = studentTable.GetList().FirstOrDefault(X => X.StudentId == id);
        }

        private void frmStudents_Load(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

       

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            dgvStudents.DataSource = new Bll.studentTable().GetList().FindAll(x => x.StudentId.StartsWith(txtsearch.Text) || x.StudentLastName.StartsWith(txtsearch.Text) || x.StudentFirstName.StartsWith(txtsearch.Text) || x.Street.StartsWith(txtsearch.Text) || x.Phone.StartsWith(txtsearch.Text) || x.GetCity().CityName.StartsWith(txtsearch.Text));

        }
    }
}
