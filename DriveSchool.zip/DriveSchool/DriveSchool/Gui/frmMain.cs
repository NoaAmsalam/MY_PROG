﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Frmcity  f = new Frmcity();
            f.Show();
        }

        private void btnRoom_Click(object sender, EventArgs e)
        {
            frmRoom f = new frmRoom();
            f.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            frmStudents f = new frmStudents();
            f.Show();
        }

        private void btnTeacher_Click(object sender, EventArgs e)
        {
            frmTeachers f = new frmTeachers();
            f.Show();

        }
    }
}
