﻿namespace DriveSchool.Gui
{
    partial class frmRoom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn_clean = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvRoom = new System.Windows.Forms.DataGridView();
            this.grbadd = new System.Windows.Forms.GroupBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.lblAmount = new System.Windows.Forms.Label();
            this.lblsaved = new System.Windows.Forms.Label();
            this.lblnameRoom = new System.Windows.Forms.Label();
            this.txtnameRoom = new System.Windows.Forms.TextBox();
            this.btnok = new System.Windows.Forms.Button();
            this.grbform = new System.Windows.Forms.GroupBox();
            this.rdbadd = new System.Windows.Forms.RadioButton();
            this.rdbupdate = new System.Windows.Forms.RadioButton();
            this.txtreserchRoom = new System.Windows.Forms.TextBox();
            this.lblreserchRoom = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRoom)).BeginInit();
            this.grbadd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.grbform.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_clean
            // 
            this.btn_clean.BackColor = System.Drawing.Color.Navy;
            this.btn_clean.Font = new System.Drawing.Font("Times New Roman", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clean.ForeColor = System.Drawing.Color.White;
            this.btn_clean.Location = new System.Drawing.Point(25, 110);
            this.btn_clean.Margin = new System.Windows.Forms.Padding(4);
            this.btn_clean.Name = "btn_clean";
            this.btn_clean.Size = new System.Drawing.Size(71, 29);
            this.btn_clean.TabIndex = 18;
            this.btn_clean.Text = "נקה";
            this.btn_clean.UseVisualStyleBackColor = false;
            this.btn_clean.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(105, 195);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 17);
            this.label1.TabIndex = 17;
            // 
            // dgvRoom
            // 
            this.dgvRoom.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRoom.Location = new System.Drawing.Point(16, 140);
            this.dgvRoom.Margin = new System.Windows.Forms.Padding(5);
            this.dgvRoom.MultiSelect = false;
            this.dgvRoom.Name = "dgvRoom";
            this.dgvRoom.RowHeadersWidth = 51;
            this.dgvRoom.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRoom.Size = new System.Drawing.Size(248, 297);
            this.dgvRoom.TabIndex = 16;
            this.dgvRoom.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRoom_CellContentClick);
            this.dgvRoom.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRoom_CellDoubleClick);
            // 
            // grbadd
            // 
            this.grbadd.Controls.Add(this.numericUpDown1);
            this.grbadd.Controls.Add(this.lblAmount);
            this.grbadd.Controls.Add(this.lblsaved);
            this.grbadd.Controls.Add(this.lblnameRoom);
            this.grbadd.Controls.Add(this.txtnameRoom);
            this.grbadd.Controls.Add(this.btnok);
            this.grbadd.Location = new System.Drawing.Point(271, 140);
            this.grbadd.Margin = new System.Windows.Forms.Padding(5);
            this.grbadd.Name = "grbadd";
            this.grbadd.Padding = new System.Windows.Forms.Padding(5);
            this.grbadd.Size = new System.Drawing.Size(221, 151);
            this.grbadd.TabIndex = 15;
            this.grbadd.TabStop = false;
            this.grbadd.Text = "הוספה";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(66, 67);
            this.numericUpDown1.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(73, 22);
            this.numericUpDown1.TabIndex = 12;
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Location = new System.Drawing.Point(163, 67);
            this.lblAmount.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(35, 17);
            this.lblAmount.TabIndex = 11;
            this.lblAmount.Text = "כמות";
            // 
            // lblsaved
            // 
            this.lblsaved.AutoSize = true;
            this.lblsaved.Location = new System.Drawing.Point(20, 107);
            this.lblsaved.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsaved.Name = "lblsaved";
            this.lblsaved.Size = new System.Drawing.Size(37, 17);
            this.lblsaved.TabIndex = 10;
            this.lblsaved.Text = "נשמר";
            this.lblsaved.Visible = false;
            // 
            // lblnameRoom
            // 
            this.lblnameRoom.AutoSize = true;
            this.lblnameRoom.Location = new System.Drawing.Point(147, 30);
            this.lblnameRoom.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblnameRoom.Name = "lblnameRoom";
            this.lblnameRoom.Size = new System.Drawing.Size(51, 17);
            this.lblnameRoom.TabIndex = 0;
            this.lblnameRoom.Text = "שם חדר";
            // 
            // txtnameRoom
            // 
            this.txtnameRoom.Location = new System.Drawing.Point(66, 30);
            this.txtnameRoom.Margin = new System.Windows.Forms.Padding(5);
            this.txtnameRoom.Name = "txtnameRoom";
            this.txtnameRoom.Size = new System.Drawing.Size(71, 22);
            this.txtnameRoom.TabIndex = 3;
            // 
            // btnok
            // 
            this.btnok.BackColor = System.Drawing.Color.Navy;
            this.btnok.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnok.ForeColor = System.Drawing.Color.White;
            this.btnok.Location = new System.Drawing.Point(66, 98);
            this.btnok.Margin = new System.Windows.Forms.Padding(5);
            this.btnok.Name = "btnok";
            this.btnok.Size = new System.Drawing.Size(129, 34);
            this.btnok.TabIndex = 2;
            this.btnok.Text = "אישור";
            this.btnok.UseVisualStyleBackColor = false;
            this.btnok.Click += new System.EventHandler(this.btnok_Click);
            // 
            // grbform
            // 
            this.grbform.Controls.Add(this.rdbadd);
            this.grbform.Controls.Add(this.rdbupdate);
            this.grbform.Location = new System.Drawing.Point(271, 291);
            this.grbform.Margin = new System.Windows.Forms.Padding(5);
            this.grbform.Name = "grbform";
            this.grbform.Padding = new System.Windows.Forms.Padding(5);
            this.grbform.Size = new System.Drawing.Size(105, 146);
            this.grbform.TabIndex = 14;
            this.grbform.TabStop = false;
            this.grbform.Text = "מצב טופס";
            // 
            // rdbadd
            // 
            this.rdbadd.AutoSize = true;
            this.rdbadd.Checked = true;
            this.rdbadd.Location = new System.Drawing.Point(30, 44);
            this.rdbadd.Margin = new System.Windows.Forms.Padding(5);
            this.rdbadd.Name = "rdbadd";
            this.rdbadd.Size = new System.Drawing.Size(65, 21);
            this.rdbadd.TabIndex = 5;
            this.rdbadd.TabStop = true;
            this.rdbadd.Text = "הוספה";
            this.rdbadd.UseVisualStyleBackColor = true;
            this.rdbadd.CheckedChanged += new System.EventHandler(this.rdbadd_CheckedChanged);
            // 
            // rdbupdate
            // 
            this.rdbupdate.AutoSize = true;
            this.rdbupdate.Location = new System.Drawing.Point(35, 88);
            this.rdbupdate.Margin = new System.Windows.Forms.Padding(5);
            this.rdbupdate.Name = "rdbupdate";
            this.rdbupdate.Size = new System.Drawing.Size(60, 21);
            this.rdbupdate.TabIndex = 6;
            this.rdbupdate.TabStop = true;
            this.rdbupdate.Text = "עדכון";
            this.rdbupdate.UseVisualStyleBackColor = true;
            this.rdbupdate.CheckedChanged += new System.EventHandler(this.rdbupdate_CheckedChanged);
            // 
            // txtreserchRoom
            // 
            this.txtreserchRoom.Location = new System.Drawing.Point(25, 76);
            this.txtreserchRoom.Margin = new System.Windows.Forms.Padding(5);
            this.txtreserchRoom.Name = "txtreserchRoom";
            this.txtreserchRoom.Size = new System.Drawing.Size(69, 22);
            this.txtreserchRoom.TabIndex = 13;
            this.txtreserchRoom.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtreserchRoom_KeyUp);
            // 
            // lblreserchRoom
            // 
            this.lblreserchRoom.AutoSize = true;
            this.lblreserchRoom.Location = new System.Drawing.Point(30, 45);
            this.lblreserchRoom.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblreserchRoom.Name = "lblreserchRoom";
            this.lblreserchRoom.Size = new System.Drawing.Size(67, 17);
            this.lblreserchRoom.TabIndex = 12;
            this.lblreserchRoom.Text = "חיפוש חדר";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblreserchRoom);
            this.groupBox1.Controls.Add(this.btn_clean);
            this.groupBox1.Controls.Add(this.txtreserchRoom);
            this.groupBox1.Location = new System.Drawing.Point(387, 291);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(105, 146);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "חיפוש";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DriveSchool.Properties.Resources.לוגו1;
            this.pictureBox1.Location = new System.Drawing.Point(16, 31);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(476, 101);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            // 
            // frmRoom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(539, 457);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvRoom);
            this.Controls.Add(this.grbadd);
            this.Controls.Add(this.grbform);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmRoom";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "חדרים";
            this.Load += new System.EventHandler(this.frmRoom_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRoom)).EndInit();
            this.grbadd.ResumeLayout(false);
            this.grbadd.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.grbform.ResumeLayout(false);
            this.grbform.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_clean;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvRoom;
        private System.Windows.Forms.GroupBox grbadd;
        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.Label lblsaved;
        private System.Windows.Forms.Label lblnameRoom;
        private System.Windows.Forms.TextBox txtnameRoom;
        private System.Windows.Forms.Button btnok;
        private System.Windows.Forms.GroupBox grbform;
        private System.Windows.Forms.RadioButton rdbadd;
        private System.Windows.Forms.RadioButton rdbupdate;
        private System.Windows.Forms.TextBox txtreserchRoom;
        private System.Windows.Forms.Label lblreserchRoom;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}