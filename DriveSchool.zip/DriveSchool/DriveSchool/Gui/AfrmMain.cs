﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class AfrmMain : Form
    {
        public AfrmMain()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Frmcity  f = new Frmcity();
            f.Show();
        }

        private void btnRoom_Click(object sender, EventArgs e)
        {
            frmRoom f = new frmRoom();
            f.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            frmStudents f = new frmStudents();
            f.Show();
        }

        private void btnTeacher_Click(object sender, EventArgs e)
        {
            frmTeachers f = new frmTeachers();
            f.Show();

        }

        private void btnCourse_Click(object sender, EventArgs e)
        {
            frmCourses f = new frmCourses();
            f.Show();

        }

        private void btnLicences_Click(object sender, EventArgs e)
        {
            frmLicences f = new frmLicences(true);
            f.Show();
        }

        private void btnLesson_Click(object sender, EventArgs e)
        {
            frmLessons f = new frmLessons();
            f.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmSS f = new frmSS();
            f.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmKod m = new frmKod();
            m.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmMazcira f = new frmMazcira();
            f.Show();
        }

        private void AfrmMain_Load(object sender, EventArgs e)
        {

        }
    }
}
