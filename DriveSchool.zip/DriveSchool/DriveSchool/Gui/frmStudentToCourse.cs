﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmStudentToCourse : DriveSchool.Form1
    {
        Bll.courseActually courseActually;
        Bll.student student;
        public frmStudentToCourse(Bll.student s, Bll.courseActually c)
        {
            InitializeComponent();
            student = s;
            courseActually = c;
            label4.Text = courseActually.GetCourse().CourseName;
            label2.Text = student.ToString();
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            Bll.StudentCourse studentCourse = new Bll.StudentCourse();
            Bll.StudentCourseTable studentCourseTable = new Bll.StudentCourseTable();
            studentCourse.CourseActuallyId = courseActually.CourseActuallyaId;
            studentCourse.StudentId = student.StudentId;
            try
            {
                studentCourseTable.Add(studentCourse);
                MessageBox.Show("התלמיד נרשם בהצלחה");
            }
            catch
            {
                MessageBox.Show("בעיה ברישום התלמיד");
            }
            this.Close();
            
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            frmPay f = new frmPay(courseActually.GetCourse().CoursePrice.ToString());
            f.Show();
        }

        private void frmStudentToCourse_Load(object sender, EventArgs e)
        {

        }
    }

}

