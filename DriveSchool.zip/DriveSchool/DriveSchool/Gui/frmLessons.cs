﻿using System;
using DriveSchool.Bll;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmLessons : Form
    {
        lessonTable lessonTable;
        lesson lesson;
        string state;
        public frmLessons()
        {
            InitializeComponent();
            lessonTable = new lessonTable();
            lesson = new lesson();
            dgvLessons.DataSource = lessonTable.GetList().Select (x =>new  {x.Lessonid,x.LessonName,x.GetLicences().LicenceName,x.StudentMin,x.StudentMax, x.LessonLength  }).ToList ();
            ChangeHeaders();
        }
        public void ChangeHeaders()
        {
            dgvLessons.Columns["Lessonid"].HeaderText = "קוד שיעור";
            dgvLessons.Columns["lessonName"].HeaderText = "שם שיעור";
            dgvLessons.Columns["LicenceName"].HeaderText = "סוג רישיון";
            dgvLessons.Columns["studentMin"].HeaderText = "מספר תלמידים מינמלי";
            dgvLessons.Columns["studentMax"].HeaderText = "מספר תלמידים מקסימלי";
            dgvLessons.Columns["lessonLength"].HeaderText = "אורך שיעור";
            //dgvLessons.Columns["drow"].Visible = false;

        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmLesson f = new frmLesson();
            f.Show();
        }


        private void btnUpdate_Click(object sender, EventArgs e)
        {
            frmLesson f = new frmLesson(lesson);
            f.Show();
        }

        //private void dgvCourse_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        //{
        //    int id = Convert.ToInt32((lesson)dgvLessons.SelectedRows[0].Cells[0].Value);
        //    lesson = lessonTable.GetList().FirstOrDefault(x => x.Lessonid == id);
        //}

        private void frmLessons_Load(object sender, EventArgs e)
        {

        }

        private void dgvLessons_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int id = Convert.ToInt32((dgvLessons.SelectedRows[0].Cells[0].Value).ToString());
            lesson = lessonTable.GetList().FirstOrDefault(X => X.Lessonid==id);
        }

        private void dgvLessons_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int id = Convert.ToInt32((dgvLessons.SelectedRows[0].Cells[0].Value).ToString());
            lesson = lessonTable.GetList().FirstOrDefault(X => X.Lessonid == id);
        }
    }
    }

