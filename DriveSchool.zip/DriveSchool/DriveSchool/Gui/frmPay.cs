﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmPay : DriveSchool.Form1
    {
        public frmPay(string s)
        {
            InitializeComponent();
            label10.Text = s;
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "")
            {
                errorProvider1.SetError(btnPay, "תשלום לא תקין");

            }
            else
                MessageBox.Show("התשלום התקבל בהצלחה");
                this.Close();
        }

        private void frmPay_Load(object sender, EventArgs e)
        {

        }
    }
}
