﻿using DriveSchool.Bll;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmScedualeLesson : Form
    {
        Bll.lessonActuallyTable lessonActuallytable;
        Bll.lessonActually lessonActually;
        Bll.teacher teacher;
        Bll.licencesTeacherTable licencesTeacherTable;
        Bll.teachertable teachertable;
        Bll.student student;
        Bll.licencesStudentTable licencesStudentTable;
        Bll.licencesStudent licencesStudent;
        public frmScedualeLesson(student s, licencesStudent l)
        {
            InitializeComponent();
            lessonActuallytable = new Bll.lessonActuallyTable();
            // סינון רשימת המורים לפי רישיון רצוי
            licencesStudentTable = new Bll.licencesStudentTable();
            licencesTeacherTable = new Bll.licencesTeacherTable();
            licencesStudent = new Bll.licencesStudent();
            teachertable = new teachertable();
            //מציאת הרשיון הפעיל
            licencesStudent lst = licencesStudentTable.GetList().FirstOrDefault<licencesStudent>(x => x.StudentId == s.StudentId && x.Test == false);
            licencesStudent = l;

            // סינון רשימת קשר מורה-רשיון
            var ll = licencesTeacherTable.GetList().Where<licencesTeacher>(x => x.LicenceId == lst.LicenceId);
            // מילוי רשימת המורים הרלוונטיים לרשיון(לרשימה במסך)
            List<teacher> cc = new List<teacher>();
            foreach (var llitem in ll)
            {
                cc.Add(teachertable.GetList().FirstOrDefault<teacher>(x => x.TeacherId == llitem.TecherId));
            }
            comboBox1.DataSource = cc;
            //עד כאן

            dateTimePicker1.Value = DateTime.Today;

            student = s;
            //השמת שם התלמיד המתקבל בטקסט-בוקס המיועד לכך
            textBox1.Text = s.ToString();
            txtLicence.Text = lst.GetLicences().ToString();

        }
        public frmScedualeLesson()
        {
            InitializeComponent();
            lessonActuallytable = new Bll.lessonActuallyTable();
            teachertable ct = new teachertable();
            comboBox1.DataSource = ct.GetList();
            dateTimePicker1.Value = DateTime.Today;
            enable();
            textBox1.Enabled = false;
            txtLicence.Enabled = false;
            label16.Enabled = false;
            label17.Enabled = false;
        }
        public void enable()
        {
            foreach (var item in panel6.Controls)
            {
                if (item is Label)
                {
                    Label l = (Label)item;
                    l.Enabled = false;     
                }
            }
            foreach (var item in panel1.Controls)
            {
                if (item is Label)
                {
                    Label l = (Label)item;
                    l.Enabled = false;
                }
            }
            foreach (var item in panel2.Controls)
            {
                if (item is Label)
                {
                    Label l = (Label)item;
                    l.Enabled = false;
                }
            }
            foreach (var item in panel3.Controls)
            {
                if (item is Label)
                {
                    Label l = (Label)item;
                    l.Enabled = false;
                }
            }
            foreach (var item in panel4.Controls)
            {
                if (item is Label)
                {
                    Label l = (Label)item;
                    l.Enabled = false;
                }
            }
            foreach (var item in panel5.Controls)
            {
                if (item is Label)
                {
                    Label l = (Label)item;
                    l.Enabled = false;
                }
            }
        }
    
          
        public void setDate()
        {
            DateTime date = dateTimePicker1.Value;
            //ראשון
            if (date.DayOfWeek.ToString() == "Sunday")
            {
                a_date.Text = date.ToShortDateString();
                b_date.Text = date.AddDays(1).ToShortDateString();
                c_date.Text = date.AddDays(2).ToShortDateString();
                d_date.Text = date.AddDays(3).ToShortDateString();
                e_date.Text = date.AddDays(4).ToShortDateString();
                f_date.Text = date.AddDays(5).ToShortDateString();
            }

            //שני
            if (date.DayOfWeek.ToString() == "Monday")
            {
                a_date.Text = date.AddDays(-1).ToShortDateString();
                b_date.Text = date.ToShortDateString();
                c_date.Text = date.AddDays(1).ToShortDateString();
                d_date.Text = date.AddDays(2).ToShortDateString();
                e_date.Text = date.AddDays(3).ToShortDateString();
                f_date.Text = date.AddDays(4).ToShortDateString();

            }
            //שלישי
            if (date.DayOfWeek.ToString() == "Tuesday")
            {
                a_date.Text = date.AddDays(-2).ToShortDateString();
                b_date.Text = date.AddDays(-1).ToShortDateString();
                c_date.Text = date.ToShortDateString();
                d_date.Text = date.AddDays(1).ToShortDateString();
                e_date.Text = date.AddDays(2).ToShortDateString();
                f_date.Text = date.AddDays(3).ToShortDateString();

            }
            //רביעי
            if (date.DayOfWeek.ToString() == "Wednesday")
            {
                a_date.Text = date.AddDays(-3).ToShortDateString();
                b_date.Text = date.AddDays(-2).ToShortDateString();
                c_date.Text = date.AddDays(-1).ToShortDateString();
                d_date.Text = date.ToShortDateString();
                e_date.Text = date.AddDays(1).ToShortDateString();
                f_date.Text = date.AddDays(2).ToShortDateString();

            }
            //חמישי
            if (date.DayOfWeek.ToString() == "Thursday")
            {
                a_date.Text = date.AddDays(-4).ToShortDateString();
                b_date.Text = date.AddDays(-3).ToShortDateString();
                c_date.Text = date.AddDays(-2).ToShortDateString();
                d_date.Text = date.AddDays(-1).ToShortDateString();
                e_date.Text = date.ToShortDateString();
                f_date.Text = date.AddDays(1).ToShortDateString();

            }
            //שישי
            if (date.DayOfWeek.ToString() == "Friday")
            {
                a_date.Text = date.AddDays(-5).ToShortDateString();
                b_date.Text = date.AddDays(-4).ToShortDateString();
                c_date.Text = date.AddDays(-3).ToShortDateString();
                d_date.Text = date.AddDays(-2).ToShortDateString();
                e_date.Text = date.AddDays(-1).ToShortDateString();
                f_date.Text = date.ToShortDateString();

            }
            var lst = lessonActuallytable.GetList();

            //רשימת השיעורים המסוננת עפ התאריך הנוכחי -ראשון ומורה הנבחר
            for (int i = 0; i < 6; i++)
            {

                //lst = lessonActuallytable.GetList().Where(x => x.DateLesson == Convert.ToDateTime(dit) && x.TecherId == ((Bll.teacher)comboBox1.SelectedItem).TeacherId).ToList();
                switch (i)
                {
                    case 0:
                        lst = lessonActuallytable.GetList().Where(x => x.DateLesson == Convert.ToDateTime(a_date.Text) && x.TecherId == ((Bll.teacher)comboBox1.SelectedItem).TeacherId).ToList();
                        foreach (var item in panel1.Controls)
                        {
                            if (item is Label)
                            {
                                Label l = (Label)item;
                                string ezer = l.Name;
                                string time = ezer[1].ToString() + ezer[2].ToString() + ":" + ezer[3].ToString() + ezer[4].ToString();
                                //חיפוש האם כבר משובצת השעה במורה ביום בנוכחי   `          
                                foreach (var lesson in lst)
                                {
                                    if (lesson.TimeLesson == time)
                                    {

                                        l.BackColor = Color.Red;
                                        l.Text = lesson.GetStudent().ToString();
                                        l.Tag = lesson.LessonActuallyId;
                                    }
                                }
                            }
                        }
                        break;
                    case 1:
                        lst = lessonActuallytable.GetList().Where(x => x.DateLesson == Convert.ToDateTime(b_date.Text) && x.TecherId == ((Bll.teacher)comboBox1.SelectedItem).TeacherId).ToList();
                        foreach (var item in panel2.Controls)
                        {
                            if (item is Label)
                            {
                                Label l = (Label)item;
                                string ezer = l.Name;
                                string time = ezer[1].ToString() + ezer[2].ToString() + ":" + ezer[3].ToString() + ezer[4].ToString();
                                //חיפוש האם כבר משובצת השעה במורה ביום בנוכחי   `          
                                foreach (var lesson in lst)
                                {
                                    if (lesson.TimeLesson == time)
                                    {

                                        l.BackColor = Color.Red;
                                        l.Text = lesson.GetStudent().ToString();
                                        l.Tag = lesson.LessonActuallyId;
                                    }
                                }
                            }
                        }
                        break;
                    case 2:
                        lst = lessonActuallytable.GetList().Where(x => x.DateLesson == Convert.ToDateTime(c_date.Text) && x.TecherId == ((Bll.teacher)comboBox1.SelectedItem).TeacherId).ToList();
                        foreach (var item in panel3.Controls)
                        {
                            if (item is Label)
                            {
                                Label l = (Label)item;
                                string ezer = l.Name;
                                string time = ezer[1].ToString() + ezer[2].ToString() + ":" + ezer[3].ToString() + ezer[4].ToString();
                                //חיפוש האם כבר משובצת השעה במורה ביום בנוכחי   `          
                                foreach (var lesson in lst)
                                {
                                    if (lesson.TimeLesson == time)
                                    {

                                        l.BackColor = Color.Red;
                                        l.Text = lesson.GetStudent().ToString();
                                        l.Tag = lesson.LessonActuallyId;
                                    }
                                }
                            }
                        }
                        break;
                    case 3:
                        lst = lessonActuallytable.GetList().Where(x => x.DateLesson == Convert.ToDateTime(d_date.Text) && x.TecherId == ((Bll.teacher)comboBox1.SelectedItem).TeacherId).ToList();
                        foreach (var item in panel4.Controls)
                        {
                            if (item is Label)
                            {
                                Label l = (Label)item;
                                string ezer = l.Name;
                                string time = ezer[1].ToString() + ezer[2].ToString() + ":" + ezer[3].ToString() + ezer[4].ToString();
                                //חיפוש האם כבר משובצת השעה במורה ביום בנוכחי   `          
                                foreach (var lesson in lst)
                                {
                                    if (lesson.TimeLesson == time)
                                    {

                                        l.BackColor = Color.Red;
                                        l.Text = lesson.GetStudent().ToString();
                                        l.Tag = lesson.LessonActuallyId;
                                    }
                                }
                            }
                        }
                        break;
                    case 4:
                        lst = lessonActuallytable.GetList().Where(x => x.DateLesson == Convert.ToDateTime(e_date.Text) && x.TecherId == ((Bll.teacher)comboBox1.SelectedItem).TeacherId).ToList();
                        foreach (var item in panel5.Controls)
                        {
                            if (item is Label)
                            {
                                Label l = (Label)item;
                                string ezer = l.Name;
                                string time = ezer[1].ToString() + ezer[2].ToString() + ":" + ezer[3].ToString() + ezer[4].ToString();
                                //חיפוש האם כבר משובצת השעה במורה ביום בנוכחי   `          
                                foreach (var lesson in lst)
                                {
                                    if (lesson.TimeLesson == time)
                                    {

                                        l.BackColor = Color.Red;
                                        l.Text = lesson.GetStudent().ToString();
                                        l.Tag = lesson.LessonActuallyId;
                                    }
                                }
                            }
                        }
                        break;
                    case 5:
                        lst = lessonActuallytable.GetList().Where(x => x.DateLesson == Convert.ToDateTime(f_date.Text) && x.TecherId == ((Bll.teacher)comboBox1.SelectedItem).TeacherId).ToList();
                        foreach (var item in panel6.Controls)
                        {
                            if (item is Label)
                            {
                                Label l = (Label)item;
                                string ezer = l.Name;
                                string time = ezer[1].ToString() + ezer[2].ToString() + ":" + ezer[3].ToString() + ezer[4].ToString();
                                //חיפוש האם כבר משובצת השעה במורה ביום בנוכחי   `          
                                foreach (var lesson in lst)
                                {
                                    if (lesson.TimeLesson == time)
                                    {

                                        l.BackColor = Color.Red;
                                        l.Text = lesson.GetStudent().ToString();
                                        l.Tag = lesson.LessonActuallyId;
                                    }
                                }
                            }
                        }
                        break;



                }
            }
        }


        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            cl();
            setDate();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            teacher = (Bll.teacher)comboBox1.SelectedItem;
            cl();
            setDate();

        }
        public void cl()
        {
            foreach (var item in panel1.Controls)
            {
                if (item is Label)
                {
                    Label l = (Label)item;
                    l.BackColor = Color.LightGreen;
                    l.Text = "";
                }
            }
            foreach (var item in panel2.Controls)
            {
                if (item is Label)
                {
                    Label l = (Label)item;
                    l.BackColor = Color.LightGreen;
                    l.Text = "";
                }
            }
            foreach (var item in panel3.Controls)
            {
                if (item is Label)
                {
                    Label l = (Label)item;
                    l.BackColor = Color.LightGreen;
                    l.Text = "";
                }
            }
            foreach (var item in panel4.Controls)
            {
                if (item is Label)
                {
                    Label l = (Label)item;
                    l.BackColor = Color.LightGreen;
                    l.Text = "";
                }
            }
            foreach (var item in panel5.Controls)
            {
                if (item is Label)
                {
                    Label l = (Label)item;
                    l.BackColor = Color.LightGreen;
                    l.Text = "";
                }
            }
            foreach (var item in panel6.Controls)
            {
                if (item is Label)
                {
                    Label l = (Label)item;
                    l.BackColor = Color.LightGreen;
                    l.Text = "";
                }
            }
        }

        private void a0800_Click(object sender, EventArgs e)
        {

            //התוית שנבחרה
            Label l = (Label)sender;
            string ezer = l.Name;
            string time = ezer[1].ToString() + ezer[2].ToString() + ":" + ezer[3].ToString() + ezer[4].ToString();
            DateTime currentdate = new DateTime();
            switch (ezer[0])
            {
                case 'a':
                    currentdate = Convert.ToDateTime(a_date.Text);
                    break;
                case 'b':
                    currentdate = Convert.ToDateTime(b_date.Text);
                    break;
                case 'c':
                    currentdate = Convert.ToDateTime(c_date.Text);
                    break;
                case 'd':
                    currentdate = Convert.ToDateTime(d_date.Text);
                    break;
                case 'e':
                    currentdate = Convert.ToDateTime(e_date.Text);
                    break;
                case 'f':
                    currentdate = Convert.ToDateTime(f_date.Text);
                    break;
            }
            if (l.BackColor == Color.Red)
            {
                Bll.lessonActually lessonActually = new lessonActually(Convert.ToInt32(l.Tag));

                frmLessonActually f = new frmLessonActually(lessonActually, licencesStudent);
                f.Show();
            }
            else
            {
                lessonActually = lessonActuallytable.GetList().FirstOrDefault(x => x.DateLesson == currentdate && x.TimeLesson == time && x.StudentId == student.StudentId);
                if (lessonActually == null)
                {
                    frmLessonActually f = new frmLessonActually(teacher, currentdate, time, student, licencesStudent);
                    f.Show();
                }
                else
                {
                    MessageBox.Show("נקבע לך שיעור בזמן זה עם המורה:" + lessonActually.getTeacher().ToString());
                }
            }




        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.Text = student.ToString();
        }

        private void txtLicence_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmScedualeLesson_Load(object sender, EventArgs e)
        {

        }
    }
}

        
        



    









       


      

       
    
