﻿namespace DriveSchool.Gui
{
    partial class frmLesson
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblKod = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lbLebgth = new System.Windows.Forms.Label();
            this.lblMax = new System.Windows.Forms.Label();
            this.lblMin = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblLessonId = new System.Windows.Forms.Label();
            this.nmcMin = new System.Windows.Forms.NumericUpDown();
            this.nmcMax = new System.Windows.Forms.NumericUpDown();
            this.nmcLength = new System.Windows.Forms.NumericUpDown();
            this.txtName = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nmcMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmcMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmcLength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblKod
            // 
            this.lblKod.AutoSize = true;
            this.lblKod.Location = new System.Drawing.Point(61, 103);
            this.lblKod.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblKod.Name = "lblKod";
            this.lblKod.Size = new System.Drawing.Size(0, 17);
            this.lblKod.TabIndex = 26;
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(61, 218);
            this.lblPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(63, 17);
            this.lblPrice.TabIndex = 24;
            this.lblPrice.Text = "סוג רישיון";
            // 
            // lbLebgth
            // 
            this.lbLebgth.AutoSize = true;
            this.lbLebgth.Location = new System.Drawing.Point(61, 441);
            this.lbLebgth.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbLebgth.Name = "lbLebgth";
            this.lbLebgth.Size = new System.Drawing.Size(126, 17);
            this.lbLebgth.TabIndex = 23;
            this.lbLebgth.Text = "אורך השיעור - בדקות";
            // 
            // lblMax
            // 
            this.lblMax.AutoSize = true;
            this.lblMax.Location = new System.Drawing.Point(61, 363);
            this.lblMax.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMax.Name = "lblMax";
            this.lblMax.Size = new System.Drawing.Size(140, 17);
            this.lblMax.TabIndex = 22;
            this.lblMax.Text = "מספר תלמידים מקסימלי";
            // 
            // lblMin
            // 
            this.lblMin.AutoSize = true;
            this.lblMin.Location = new System.Drawing.Point(61, 293);
            this.lblMin.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMin.Name = "lblMin";
            this.lblMin.Size = new System.Drawing.Size(129, 17);
            this.lblMin.TabIndex = 21;
            this.lblMin.Text = "מספר תלמידים מינמלי";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(61, 144);
            this.lblName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(61, 17);
            this.lblName.TabIndex = 20;
            this.lblName.Text = "שם שיעור";
            // 
            // lblLessonId
            // 
            this.lblLessonId.AutoSize = true;
            this.lblLessonId.Location = new System.Drawing.Point(61, 64);
            this.lblLessonId.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLessonId.Name = "lblLessonId";
            this.lblLessonId.Size = new System.Drawing.Size(63, 17);
            this.lblLessonId.TabIndex = 19;
            this.lblLessonId.Text = "קוד שיעור";
            // 
            // nmcMin
            // 
            this.nmcMin.Location = new System.Drawing.Point(65, 324);
            this.nmcMin.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.nmcMin.Name = "nmcMin";
            this.nmcMin.Size = new System.Drawing.Size(135, 22);
            this.nmcMin.TabIndex = 18;
            // 
            // nmcMax
            // 
            this.nmcMax.Location = new System.Drawing.Point(65, 399);
            this.nmcMax.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.nmcMax.Name = "nmcMax";
            this.nmcMax.Size = new System.Drawing.Size(135, 22);
            this.nmcMax.TabIndex = 17;
            // 
            // nmcLength
            // 
            this.nmcLength.Location = new System.Drawing.Point(65, 474);
            this.nmcLength.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.nmcLength.Name = "nmcLength";
            this.nmcLength.Size = new System.Drawing.Size(135, 22);
            this.nmcLength.TabIndex = 16;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(65, 174);
            this.txtName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(133, 22);
            this.txtName.TabIndex = 15;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(61, 249);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(133, 24);
            this.comboBox1.TabIndex = 27;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DriveSchool.Properties.Resources.לוגו1;
            this.pictureBox1.Location = new System.Drawing.Point(200, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(255, 216);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 28;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Navy;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(61, 521);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 114);
            this.button1.TabIndex = 29;
            this.button1.Text = "אישור";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // frmLesson
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(454, 668);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.lblKod);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lbLebgth);
            this.Controls.Add(this.lblMax);
            this.Controls.Add(this.lblMin);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblLessonId);
            this.Controls.Add(this.nmcMin);
            this.Controls.Add(this.nmcMax);
            this.Controls.Add(this.nmcLength);
            this.Controls.Add(this.txtName);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmLesson";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "שיעור";
            ((System.ComponentModel.ISupportInitialize)(this.nmcMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmcMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmcLength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label lblKod;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lbLebgth;
        private System.Windows.Forms.Label lblMax;
        private System.Windows.Forms.Label lblMin;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblLessonId;
        private System.Windows.Forms.NumericUpDown nmcMin;
        private System.Windows.Forms.NumericUpDown nmcMax;
        private System.Windows.Forms.NumericUpDown nmcLength;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
    }
}