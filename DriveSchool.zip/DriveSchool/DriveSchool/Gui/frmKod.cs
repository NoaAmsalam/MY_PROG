﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmKod : DriveSchool.Form1
    {
        public frmKod()
        {
            InitializeComponent();
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "1256")
            {
                frmManameje f = new frmManameje();
                f.Show();
            }
            else
                errorProvider1.SetError(textBox3, "קוד לא תקין");
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmKod_Load(object sender, EventArgs e)
        {

        }
    }
}
