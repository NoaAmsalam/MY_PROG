﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmCoursesActually : DriveSchool.Form1
    {
        Bll.courseActually courseActually;
        Bll.courseActuallyTable courseActuallyTable;
        Bll.room room;
        Bll.roomTable roomTable;
        Bll.teachertable teachertable;
        Bll.teacher teacher;
        Bll.Course course;
        Bll.CourseTable courseTable;
        public frmCoursesActually()
        {
            InitializeComponent();
            courseActuallyTable = new Bll.courseActuallyTable();
            roomTable = new Bll.roomTable();
            courseTable = new Bll.CourseTable();
            teachertable = new Bll.teachertable();
            dataGridView1.DataSource = courseActuallyTable.GetList().Select(x => new { x.CourseActuallyaId, k = x.GetCourse().CourseName, v = x.GetTeacher().ToString(), x.BeginningDate, x.TimeCourse, h = x.GetRoom().RoomName }).ToList();
            ChangeHeaders();
            comboBox1.DataSource = courseTable.GetList();
            comboBox2.DataSource = roomTable.GetList();
            comboBox3.DataSource = teachertable.GetList();
            Clear();
            
        }
        public void ChangeHeaders()
        {
            dataGridView1.Columns["courseActuallyaId"].HeaderText = "קוד קורס";
            dataGridView1.Columns["k"].HeaderText = "שם קורס";
            dataGridView1.Columns["v"].HeaderText = "שם מורה";
            dataGridView1.Columns["beginningDate"].HeaderText = "תאריך קורס";
            dataGridView1.Columns["timeCourse"].HeaderText = "שעת קורס";
            dataGridView1.Columns["h"].HeaderText = "שם חדר";
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            courseActually = courseActuallyTable.GetList().FirstOrDefault(X => X.CourseActuallyaId == id);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmCourseActually f = new frmCourseActually(courseActually);
            f.Show();
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void frmCoursesActually_Load(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime d = dateTimePicker1.Value;
            dataGridView1.DataSource = courseActuallyTable.GetList().Where(x => x.BeginningDate.Date == d.Date).Select(x => new { x.CourseActuallyaId, k = x.GetCourse().CourseName, v = x.GetTeacher().ToString(), x.BeginningDate, x.TimeCourse, h = x.GetRoom().RoomName }).ToList();
            ChangeHeaders();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            teacher = new Bll.teacher();
            teacher = (Bll.teacher)comboBox3.SelectedItem;
            dataGridView1.DataSource = courseActuallyTable.GetList().Where(x => x.TecherId == teacher.TeacherId).Select(x => new { x.CourseActuallyaId, k = x.GetCourse().CourseName, v = x.GetTeacher().ToString(), x.BeginningDate, x.TimeCourse, h = x.GetRoom().RoomName }).ToList();
            ChangeHeaders();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            room = new Bll.room();
            room = (Bll.room)comboBox2.SelectedItem;
            dataGridView1.DataSource = courseActuallyTable.GetList().Where(x => x.Roomid == room.RoomId).Select(x => new { x.CourseActuallyaId, k = x.GetCourse().CourseName, v = x.GetTeacher().ToString(), x.BeginningDate, x.TimeCourse, h = x.GetRoom().RoomName }).ToList();
            ChangeHeaders();
         
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            course = new Bll.Course();
            course = (Bll.Course)comboBox1.SelectedItem;
            dataGridView1.DataSource = courseActuallyTable.GetList().Where(x => x.CourseId == course.CourseId).Select(x => new { x.CourseActuallyaId, k = x.GetCourse().CourseName, v = x.GetTeacher().ToString(), x.BeginningDate, x.TimeCourse, h = x.GetRoom().RoomName }).ToList();
            ChangeHeaders();
        }

        public void button2_Click(object sender, EventArgs e)
        {
            Clear();
        }
        public void Clear()
        {
            dataGridView1.DataSource = courseActuallyTable.GetList().Select(x => new { x.CourseActuallyaId, k = x.GetCourse().CourseName, v = x.GetTeacher().ToString(), x.BeginningDate, x.TimeCourse, h = x.GetRoom().RoomName }).ToList();
            ChangeHeaders();
        }
    }
}
