﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmAdd : DriveSchool.Form1
    {
        int i = 0;
        Bll.teachertable teachertable;
        Bll.teacher teacher;
        Bll.student student;
        Bll.studentTable studentTable;
        public frmAdd(int c)
        {
            InitializeComponent();
            i = c;
            
        }

        private void frmAdd_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            teacher = new Bll.teacher();
            student = new Bll.student();
            studentTable = new Bll.studentTable();
            teachertable = new Bll.teachertable();

            if (i == 0)
            {
                errorProvider1.Clear();
                if (teachertable.GetList().FirstOrDefault(x => x.TeacherId == textBox1.Text) != null)
                {
                    teacher = teachertable.GetList().FirstOrDefault(x => x.TeacherId == textBox1.Text);
                    frmTeacherCourse f = new frmTeacherCourse(teacher);
                    f.Show();
                }

                else
                {
                  //  errorProvider1.SetError(textBox1, "מורה לא קיים");
                    DialogResult diar = MessageBox.Show("האם ברצונך להוסיף מורה חדש? ", "מורה לא קיים", MessageBoxButtons.YesNo);
                    if (diar == DialogResult.No)
                        this.Close();
                    else
                    {
                        frmTeacher f = new frmTeacher(textBox1.Text);
                        f.Show();
                    }    
                }
            }
            if (i == 1)
            {
                errorProvider1.Clear();
                if (teachertable.GetList().FirstOrDefault(x => x.TeacherId == textBox1.Text) != null)
                {
                    teacher = teachertable.GetList().FirstOrDefault(x => x.TeacherId == textBox1.Text);
                    frmLicenceTeacher f = new frmLicenceTeacher(teacher);
                    f.Show();
                }

                else
                { 
                    DialogResult diar = MessageBox.Show("האם ברצונך להוסיף מורה חדש? ", "מורה לא קיים", MessageBoxButtons.YesNo);
                if (diar == DialogResult.No)
                    this.Close();
                else
                {
                    frmTeacher f = new frmTeacher(textBox1.Text);
                    f.Show();
                }
                    }
            }

            if (i == 2)
            {
                if (studentTable.GetList().FirstOrDefault(x => x.StudentId == textBox1.Text) != null)
                {
                    student = studentTable.GetList().FirstOrDefault(x => x.StudentId == textBox1.Text);
                    frmlicenceStudent f = new frmlicenceStudent(student);
                    f.Show();
                }
                else
                {
                    DialogResult diar = MessageBox.Show("האם ברצונך להוסיף תלמיד חדש? ", "תלמיד לא קיים", MessageBoxButtons.YesNo);
                    if (diar == DialogResult.No)
                        this.Close();
                    else
                    {
                        frmStudent f = new frmStudent(textBox1.Text);
                        f.Show();
                    }
                }

            }
        }
    }
}
