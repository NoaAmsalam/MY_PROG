﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmCourseActually : DriveSchool.Form1
    {
        Bll.Course course;
        Bll.room room;
        Bll.roomTable roomTable;
        Bll.CourseTable courseTable;
        Bll.courseActually courseActually;
        Bll.courseActuallyTable courseActuallyTable;
        Bll.teacher teacher;
        Bll.teachertable teachertable;
        Bll.techerCourseTable techerCourseTable;
        Bll.techerCourse techerCourse;
        Bll.StudentCourseTable StudentCourseTable;
        bool k = true;
        public frmCourseActually(DateTime d, string s)
        {
           
            InitializeComponent();
            courseTable = new Bll.CourseTable();
            comboBox1.DataSource = courseTable.GetList();
            roomTable = new Bll.roomTable();
            courseActually = new Bll.courseActually();
            txtTime.Text = s;
            //dataGridView1.Visible = false;
            button1.Visible = true;
            button2.Visible = false;
            panel1.Enabled = true;
            groupBox1.Enabled = true;
            dateTimePicker1.Value = d;
            courseActuallyTable = new Bll.courseActuallyTable();
            courseActually.CourseId = courseActuallyTable.getnewkey();
            lblkod.Text = courseActually.CourseId.ToString();
           
        }
        public frmCourseActually(Bll.courseActually c)
        {
            InitializeComponent();
            courseActually = c;
            StudentCourseTable = new Bll.StudentCourseTable();
            fillData();
           // .DataSource = StudentCourseTable.GetList().Where(x => x.CourseActuallyId == c.CourseActuallyaId).Select(x=> new { x.GetStudent().StudentFirstName}).ToList();
        } 
        public void fillData()
        {
            dateTimePicker1.Value =  courseActually.BeginningDate;
            lblkod.Text = courseActually.CourseActuallyaId.ToString();
            txtTime.Text = courseActually.TimeCourse;
            comboBox3.Text = courseActually.TecherId;
            comboBox2.Text = courseActually.Roomid.ToString();
            comboBox1.Text = courseActually.CourseId.ToString();
        }
        //פעולה ששמה ברישמה רק מורים לקורס זה
        public void TeacherCourse()
        {
            
            comboBox3.DataSource = ((Bll.Course)comboBox1.SelectedItem).GetTecherCourses();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            groupBox1.Visible = true;
            course = new Bll.Course();
            courseTable = new Bll.CourseTable();
            teachertable = new Bll.teachertable();
            techerCourseTable = new Bll.techerCourseTable();
            roomTable = new Bll.roomTable();
            course = courseTable.GetList().FirstOrDefault(x => x.CourseId == ((Bll.Course)comboBox1.SelectedItem).CourseId);
            textBox1.Text = course.StudentMin.ToString();
            textBox2.Text = course.StudentMax.ToString();
            roomTable = new Bll.roomTable();
            txtPrice.Text = course.CoursePrice.ToString();
            //מציאת קוד קורס נבחר והשמה במשתנה
            //int n = ((Bll.Course)comboBox1.SelectedItem).CourseId;
            course = (Bll.Course)comboBox1.SelectedItem;
            //חדר לפי כמות
            //comboBox2.DataSource = roomTable.GetList().Where(x => x.Amount > courseActually.GetCourse().StudentMax).ToList();
          //  comboBox2.DataSource = roomTable.GetList();
            comboBox2.DataSource = roomTable.GetList().Where(x => x.Amount >= course.StudentMax).ToList();
            //מורה לפי קורס
            //   comboBox3.DataSource = techerCourseTable.GetList().Where(x => x.CourseId == course.CourseId).ToList();
            TeacherCourse();
        }



        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        


        private void button1_Click(object sender, EventArgs e)
        {
            SaveCourse(dateTimePicker1.Value,  ((Bll.techerCourse)comboBox3.SelectedItem).TeacherId, Convert.ToInt32(lblkod.Text), ((Bll.Course)comboBox1.SelectedItem).CourseId, ((Bll.room)comboBox2.SelectedItem).RoomId, txtTime.Text);
           if(k = true)
             this.Close();
           
                
        }
      
        public void SaveCourse(DateTime d, string teacherId, int coUrseActuallyId, int courseId, int roomId, string time)
        {
            Bll.lessonActually l = new Bll.lessonActually();
            Bll.lessonActuallyTable j = new Bll.lessonActuallyTable();
            courseActually.BeginningDate = d;
            courseActually.TecherId = teacherId;
            courseActually.Roomid = roomId;
            courseActually.TimeCourse = time;
            courseActually.CourseActuallyaId = coUrseActuallyId;
            courseActually.CourseId = courseId;

            int s = Convert.ToInt32(time[0].ToString() + time[1].ToString())+1;
            string f = s + ":00";
            l = j.GetList().FirstOrDefault(x => (x.TecherId == teacherId && x.TimeLesson == time && x.DateLesson == d) || (x.TecherId == teacherId && x.TimeLesson == f && x.DateLesson == d));
            if (l == null)
                try
                {
                    courseActuallyTable.Add(courseActually);
                    MessageBox.Show("השיעור נקבע בהצלחה");
                }
                catch
                {
                    MessageBox.Show("בעיה בקביעת השיעור");
                }
            else
            {
                DialogResult diar = MessageBox.Show("האם ברצונך להחליף מורה ? ", "מורה לא פנוי בשעה זו", MessageBoxButtons.YesNo);
                if (diar == DialogResult.No)
                    this.Close();
                else
                {
                    k = false;
                }
               // MessageBox.Show("המורה לא פנוי בשעה זו");
               
            }
            }

        private void frmCourseActually_Load(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Bll.teachertable tc = new Bll.teachertable();
            //Bll.teacher t = null;
            //if (comboBox3.Text != "בחר מורה")
            //    t = new Bll.teacher(comboBox3.Text);
            //if (t != null)
            //    textBox4.Text = t.ToString();
            //else
            //    textBox4.Text = "nbb";
            textBox4.Text = ((Bll.techerCourse)comboBox3.SelectedItem).GetTeacher().ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

    }



