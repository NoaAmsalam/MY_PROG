﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace DriveSchool.Gui
{
    public partial class frmLicencesTeacher : DriveSchool.Form1
    {
        Bll.teacher teacher;
        Bll.licencesTeacherTable licencesTeacherTable;
        Bll.licencesTeacher licencesTeacher;
        //List <Bll.licencesTeacher> var;
        public frmLicencesTeacher(Bll.teacher t)
        {
            InitializeComponent();
            teacher = t;
            textBox1.Text = t.ToString();
            licencesTeacher = new Bll.licencesTeacher();
            licencesTeacherTable = new Bll.licencesTeacherTable();
            dataGridView1.DataSource = licencesTeacherTable.GetList().Where(x => x.TecherId == teacher.TeacherId).Select(x => new { x.TecherId, x.GetLicences().LicenceName, x.Drow }).ToList();
            ChangeHeaders();
        }
        public void ChangeHeaders()
        {
            dataGridView1.Columns["licenceName"].HeaderText = "שם רישיון";
            dataGridView1.Columns["techerId"].Visible = false;
            dataGridView1.Columns["drow"].Visible = false;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            frmLicenceTeacher f = new frmLicenceTeacher(teacher);
            f.Show();
        }

        private void frmLicencesTeacher_Load(object sender, EventArgs e)
        {

        }
    }
}
