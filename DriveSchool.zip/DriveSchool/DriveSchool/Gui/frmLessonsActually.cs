﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmLessonsActually : DriveSchool.Form1
    {
        Bll.lessonActually lessonActually;
        Bll.lessonActuallyTable lessonActuallyTable;
        Bll.teachertable teachertable;
        Bll.teacher teacher;
        public frmLessonsActually()
        {
            InitializeComponent();
            lessonActuallyTable = new Bll.lessonActuallyTable();
            dataGridView1.DataSource = lessonActuallyTable.GetList().Select(x => new { x.LessonActuallyId, k =x.GetLicences().GetLicences().LicenceName, v= x.GetTeacher().ToString(), h = x.GetStudent().ToString(), x.DateLesson, x.TimeLesson }).ToList();
            ChangeHeaders();
            teachertable = new Bll.teachertable();
            comboBox1.DataSource = teachertable.GetList();
            dataGridView1.DataSource = lessonActuallyTable.GetList().Select(x => new { x.LessonActuallyId, k = x.GetLicences().GetLicences().LicenceName, v = x.GetTeacher().ToString(), h = x.GetStudent().ToString(), x.DateLesson, x.TimeLesson }).ToList();
            ChangeHeaders();
        }

        public void ChangeHeaders()
        {
            dataGridView1.Columns["lessonActuallyId"].HeaderText = "קוד שיעור";
            dataGridView1.Columns["k"].HeaderText = "שם רישיון";
            dataGridView1.Columns["v"].HeaderText = "שם מורה";
            dataGridView1.Columns["dateLesson"].HeaderText = "תאריך שיעור";
            dataGridView1.Columns["timeLesson"].HeaderText = "שעת שיעור";
            dataGridView1.Columns["h"].HeaderText = "שם תלמיד";
           

        }
        //public void ChangeHeaders()
        //{
        //    dataGridView1.Columns["lessonActuallyId"].HeaderText = "קוד שיעור";
        //    dataGridView1.Columns["licenseTostudentid"].HeaderText = "שם רישיון";
        //    dataGridView1.Columns["techerId"].HeaderText = "שם מורה";
        //    dataGridView1.Columns["dateLesson"].HeaderText = "תאריך שיעור";
        //    dataGridView1.Columns["timeLesson"].HeaderText = "שעת שיעור";
        //    dataGridView1.Columns["studentId"].HeaderText = "שם תלמיד";
        //    dataGridView1.Columns["isglobal"].HeaderText = "האם שולמה חבילה";

        //}
        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            lessonActually = lessonActuallyTable.GetList().FirstOrDefault(X => X.LessonActuallyId == id);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmLessonActually f = new frmLessonActually(lessonActually);
            f.Show();


        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            frmLessonActually f = new frmLessonActually(lessonActually);
            f.Show();
        }

        private void dataGridView1_CellMouseClick_1(object sender, DataGridViewCellMouseEventArgs e)
        {
            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            lessonActually = lessonActuallyTable.GetList().FirstOrDefault(X => X.LessonActuallyId == id);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

      //  private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
      //  {
       //     teacher = new Bll.teacher();
        //    teacher = (Bll.teacher)comboBox1.SelectedItem;
         //   dataGridView1.DataSource = lessonActuallyTable.GetList().Where(x => x.TecherId == teacher.TeacherId).ToList();
     //   }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = lessonActuallyTable.GetList().Select(x => new { x.LessonActuallyId, k = x.GetLicences().GetLicences().LicenceName, v = x.GetTeacher().ToString(), h = x.GetStudent().ToString(), x.DateLesson, x.TimeLesson }).ToList();
            ChangeHeaders();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime d = dateTimePicker1.Value;
           // d = d.Date;
            dataGridView1.DataSource = lessonActuallyTable.GetList().Where(x => x.DateLesson.Date == d.Date).Select(x => new { x.LessonActuallyId, k = x.GetLicences().GetLicences().LicenceName, v = x.GetTeacher().ToString(), h = x.GetStudent().ToString(), x.DateLesson, x.TimeLesson }).ToList();
            ChangeHeaders();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            teacher = new Bll.teacher();
            teacher = (Bll.teacher)comboBox1.SelectedItem;
            dataGridView1.DataSource = lessonActuallyTable.GetList().Where(x => x.TecherId == teacher.TeacherId).Select(x => new { x.LessonActuallyId, k = x.GetLicences().GetLicences().LicenceName, v = x.GetTeacher().ToString(), h = x.GetStudent().ToString(), x.DateLesson, x.TimeLesson }).ToList();
            ChangeHeaders();
        }

        private void frmLessonsActually_Load(object sender, EventArgs e)
        {

        }
    }
}
