﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmRoom : Form
    {
        Bll.room room;
        Bll.roomTable roomTable;
        IEnumerable<Bll.room> filter;

        public frmRoom()
        {
            InitializeComponent();
            room = new Bll.room();
            roomTable = new Bll.roomTable();
            rdbadd.Checked = true;
            refresh();
            ChangeHeaders();
            filter = roomTable.GetList();
        }
        public void ChangeHeaders()
        {
            dgvRoom.Columns["roomid"].HeaderText = "קוד חדר";
            dgvRoom.Columns["roomname"].HeaderText = "שם חדר";
            dgvRoom.Columns["amount"].HeaderText = "תפוסה מרבית";
        }
        public bool check()
        {
            errorProvider1.Clear();
            bool ok = true;
            try
            {
                room.RoomName = txtnameRoom.Text;
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtnameRoom, ex.Message);
                ok = false;
            }
            try
            {
                room.Amount = Convert.ToInt32(numericUpDown1.Value);
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(numericUpDown1, ex.Message);
                ok = false;
            }
            return ok;
        }
        private void rdbadd_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbadd.Checked)
                grbadd.Text = "הוספה";
            else
                grbadd.Text = "עידכון";
        }
        private void btnok_Click(object sender, EventArgs e)
        {
            //bool add_state = true;
            //if (rdbupdate.Checked)
            //    add_state = false;

            if (grbadd.Text == "הוספה") //במצב הוספה
            {
                if (roomTable.GetList().Any(x => x.RoomName == txtnameRoom.Text) == true)
                    errorProvider1.SetError(txtnameRoom, "room exists");
                else
                {
                    if (check() == true)
                    {
                        room.RoomId = roomTable.getnewkey();
                        roomTable.Add(room);
                        refresh();
                        txtnameRoom.Text = "";
                        numericUpDown1.Value = 0;
                        lblsaved.Visible = true;
                        timer1.Enabled = true;
                    }
                }
            }
            else //במצב עדכון
            {
                if (check() == true)
                {
                    roomTable.Update(room);
                    refresh();
                    txtnameRoom.Text = "";
                    numericUpDown1.Value = 0;
                    lblsaved.Visible = true;
                    timer1.Enabled = true;
                }
            }
          
        }
        public void refresh()
        {
            dgvRoom.DataSource = roomTable.GetList().Select(x => new { x.RoomId, x.RoomName, x.Amount }).ToList();
        }
        private void rdbupdate_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbupdate.Checked)
                grbadd.Text = "עידכון";
            else
                grbadd.Text = "הוספה";
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            int i = 0;//מונה למספר שניות
            i++;
            if (i == 7)
            {
                timer1.Enabled = false;
                lblsaved.Visible = false;
                i = 0;

            }
        }
        public void filldgvfilter()
        {
            dgvRoom.DataSource = filter.ToList().Select(x => new { x.RoomId, x.RoomName, x.Amount }).ToList();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            txtreserchRoom.Text = "";
            refresh();
        }
        private void txtreserchRoom_KeyUp(object sender, KeyEventArgs e)
        {
            filter = filter.Where(x => (x.RoomName.Contains(txtreserchRoom.Text)));
            filldgvfilter();
        }
        private void dgvRoom_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (rdbupdate.Checked)
            {
                int id = Convert.ToInt32(dgvRoom.SelectedRows[0].Cells[0].Value);
                room = new Bll.room();
                room = roomTable.GetList().FirstOrDefault(x => x.RoomId == id);
                txtnameRoom.Text = room.RoomName;
                numericUpDown1.Value = room.Amount;
            }
        }

        private void dgvRoom_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
            int i = 0;//מונה למספר שניות

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            i++;
            if (i == 4)
            {
                timer1.Enabled = false;
                lblsaved.Visible = false;
                i = 0;

            }
        }

        private void frmRoom_Load(object sender, EventArgs e)
        {

        }
    }
}
