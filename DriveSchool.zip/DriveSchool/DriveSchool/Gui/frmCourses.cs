﻿using DriveSchool.Bll;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmCourses : Form
    {
        Bll.Course course;
        Bll.CourseTable courseTable;
        string state;
        public frmCourses()
        {
            InitializeComponent();
            course = new Course();
            courseTable = new CourseTable();
            dgvCourse.DataSource = courseTable.GetList();
            ChangeHeaders();
        }
        public void ChangeHeaders()
        {
            dgvCourse.Columns["CourseId"].HeaderText = "קוד קורס";
            dgvCourse.Columns["courseName"].HeaderText = "שם קורס";
            dgvCourse.Columns["studentMin"].HeaderText = "מספר תלמידים מינמלי";
            dgvCourse.Columns["studentMax"].HeaderText = "מספר תלמידים מקסימלי";
            dgvCourse.Columns["coursePrice"].HeaderText = "מחיר קורס";
            
           
            dgvCourse.Columns["drow"].Visible = false;

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmCourse f = new frmCourse();
            f.Show();
        }
       

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            frmCourse f = new frmCourse(course);
            f.Show();
        }

        private void dgvCourse_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int id = Convert.ToInt32((dgvCourse.SelectedRows[0].Cells[0].Value).ToString());
            course = courseTable.GetList().FirstOrDefault(X => X.CourseId == id);
        }

        private void DgvCourse_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void frmCourses_Load(object sender, EventArgs e)
        {

        }
    }
}
