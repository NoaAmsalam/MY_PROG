﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmManameje : DriveSchool.Form1
    {
        public frmManameje()
        {
            InitializeComponent();
        }

        private void btnTeacher_Click(object sender, EventArgs e)
        {
            frmTeachers f = new frmTeachers();
            f.Show();
        }

        private void btnLicences_Click(object sender, EventArgs e)
        {
            frmLicences f = new frmLicences(true);
            f.Show();
        }

        private void btnCourse_Click(object sender, EventArgs e)
        {
            frmCourses f = new frmCourses();
            f.Show();
        }

        private void btnRoom_Click(object sender, EventArgs e)
        {
            frmRoom f = new frmRoom();
            f.Show();
        }

        private void btnCity_Click(object sender, EventArgs e)
        {
            Frmcity f = new Frmcity();
            f.Show();
        }

        private void frmManameje_Load(object sender, EventArgs e)
        {

        }
    }
}
