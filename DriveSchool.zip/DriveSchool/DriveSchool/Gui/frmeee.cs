﻿using DriveSchool.Bll;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmeee : Form
    {
        Bll.student s;
        public frmeee()
        {
            InitializeComponent();
            studentTable ct = new studentTable();
            comboBox1.DataSource = ct.GetList();
           // s = new student();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (s != null)
            {
              //  s = new student();
                frmSceduale f = new frmSceduale(s);
                f.Show();
            }
           
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            s = (Bll.student)comboBox1.SelectedItem;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmSceduale f = new frmSceduale();
            f.Show();
        }
    }
}
