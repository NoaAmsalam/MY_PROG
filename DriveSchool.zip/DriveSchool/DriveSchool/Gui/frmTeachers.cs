﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using DriveSchool.Bll;

using System.Windows.Forms;
using System.Linq;

namespace DriveSchool.Gui
{
    public partial class frmTeachers : DriveSchool.Form1
    {
       Bll. teachertable teachertable;
       Bll. teacher teacher;
        string state;

        public frmTeachers()
        {
            InitializeComponent();
             teacher = new teacher();
            teachertable = new teachertable();
            dgvTeachers.DataSource = teachertable.GetList().Select(x => new { x.TeacherId, x.TeacherFirstName, x.TeacherLasttName, x.GetCity().CityName, x.Street, x.Num, x.Phone, x.StartWorking, x.Drow }).ToList();

            ChangeHeaders();
            
        }
        public void ChangeHeaders()
        {
            dgvTeachers.Columns["teacherId"].HeaderText = "תעודת זהות מורה";
            dgvTeachers.Columns["teacherFirstName"].HeaderText = "שם פרטי";
            dgvTeachers.Columns["teacherLasttName"].HeaderText = "שם משפחה";
            dgvTeachers.Columns["street"].HeaderText = "רחוב";
            dgvTeachers.Columns["cityname"].HeaderText = "עיר";
            dgvTeachers.Columns["num"].HeaderText = "מספר בית";
            dgvTeachers.Columns["phone"].HeaderText = "טלפון";
            dgvTeachers.Columns["StartWorking"].HeaderText = "תחילת עבודה";
            dgvTeachers.Columns["drow"].Visible = false;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmTeacher f = new frmTeacher();
            f.Show();
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            frmTeacher f = new frmTeacher(teacher);
            f.Show();
        }

        private void dgvTeachers_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
           string id = (dgvTeachers.SelectedRows[0].Cells[0].Value).ToString();
           teacher = teachertable.GetList().FirstOrDefault(X => X.TeacherId == id);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            dgvTeachers.DataSource = new Bll.teachertable().GetList().FindAll(x => x.TeacherId.StartsWith(txtSearch.Text) || x.TeacherFirstName.StartsWith(txtSearch.Text) || x.TeacherLasttName.StartsWith(txtSearch.Text) || x.Street.StartsWith(txtSearch.Text) || x.Phone.StartsWith(txtSearch.Text) || x.GetCity().CityName.StartsWith(txtSearch.Text));

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void frmTeachers_Load(object sender, EventArgs e)
        {

        }
    }
    }

