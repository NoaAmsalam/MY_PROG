﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui

{
    public partial class frmLessonActually : Form
    {
       // Bll.lessonActually ;
        Bll.lessonActuallyTable le;
        Bll.lessonActually la;
        Bll.teacher teacher;
        Bll.student student;
        Bll.licences licences;
        Bll.licencesTable licencesTable;
        Bll.licencesStudentTable licencesStudentTable;
        Bll.licencesStudent licencesStudent;
        int lt;
        int count = 0;
        public frmLessonActually(Bll.lessonActually l,Bll.licencesStudent ls)
        {
            InitializeComponent();
            button3.Visible = true;
            button1.Visible = false;
          //  btnCencel.Visible = true;
            la = l;
            le = new Bll.lessonActuallyTable();
            count = le.GetList().Where(x => x.StudentId == la.StudentId).Count();
            textBox4.Text = count.ToString();
            fillTexeBox();
            lt = ls.LicenceStudentId;
          



        }
        public frmLessonActually(Bll.lessonActually ca)
        {
           
            
                InitializeComponent();
                button1.Visible = false;
                la = ca;
                le = new Bll.lessonActuallyTable();
                fillData();
                // .DataSource = StudentCourseTable.GetList().Where(x => x.CourseActuallyId == c.CourseActuallyaId).Select(x=> new { x.GetStudent().StudentFirstName}).ToList();
            
            
        }
        public void fillData()
        {
            dateTimePicker1.Value = la.DateLesson;
            lblKod.Text = la.LessonActuallyId.ToString();
            txtTime.Text = la.TimeLesson;
            txtTeacherId.Text = la.GetTeacher().ToString();
            txtStusentId.Text = la.GetStudent().ToString();
            checkBox1.Checked = la.Isglobal;
            count = le.GetList().Where(x => x.StudentId == la.StudentId).Count();
            textBox4.Text = count.ToString();
        }
        public void fillTexeBox()
        {
            lblKod.Text =la.LessonActuallyId.ToString();
            txtTeacherId.Text = la.TecherId;
            txtStusentId.Text = la.StudentId;
            txtTime.Text = la.TimeLesson;
            dateTimePicker1.Value = la.DateLesson;
            checkBox1.Checked = la.Isglobal;
        }
        public frmLessonActually(Bll.teacher t, DateTime ldate, string time, Bll.student s, Bll.licencesStudent li)
        {
            InitializeComponent();
            la = new Bll.lessonActually();
            le = new Bll.lessonActuallyTable();
            la.LessonActuallyId = le.getnewkey();
            lblKod.Text = la.LessonActuallyId.ToString();
            teacher = t;
            student = s;
            button1.Visible = true;
            button3.Visible = false;
            lt = li.LicenceStudentId;
            txtTeacherId.Text = teacher.ToString();
            txtTime.Text = time;
            dateTimePicker1.Value = ldate;
            txtStusentId.Text = student.ToString();
            licencesStudentTable = new Bll.licencesStudentTable();
            licencesStudent = li;
            var lst = licencesStudentTable.GetList().Where(x => x.StudentId == s.StudentId);
            foreach (var licencesStudent in lst)
            {
                if (licencesStudent.Test == false)
                {
                    checkBox1.Checked = licencesStudent.PayPackage;
                }
            }
            count = le.GetList().Where(x => x.StudentId == s.StudentId).Count();
            textBox4.Text = count.ToString();
        }

        private void button1_Click(object sender, EventArgs e)

        {
            
            Bll.courseActually courseActually = new Bll.courseActually();
            Bll.courseActuallyTable courseActuallyTable = new Bll.courseActuallyTable();
            if (txtTime.Text == "10:00" || txtTime.Text == "11:00" || txtTime.Text == "12:00" || txtTime.Text == "13:00" || txtTime.Text == "14:00" || txtTime.Text == "15:00")
                if (txtTime.Text == "10:00" || txtTime.Text == "12:00" || txtTime.Text == "14:00")
                {
                    courseActually = courseActuallyTable.GetList().FirstOrDefault(x => x.TecherId == teacher.TeacherId && x.TimeCourse == txtTime.Text && x.BeginningDate == dateTimePicker1.Value);
                    if (courseActually != null)
                        MessageBox.Show("מורה לא פנוי בשעה זו");
                    else
                        saves();
                }
                else
                {
                    //לעשות חיפוש האם המורה מלמד בשעה של השיעור בקורס
                    int s = Convert.ToInt32(txtTime.Text[0].ToString() + txtTime.Text[1].ToString()) - 1;
                    string f = s + ":00";
                    courseActually = courseActuallyTable.GetList().FirstOrDefault(x => x.TecherId == teacher.TeacherId && x.TimeCourse == f && x.BeginningDate == dateTimePicker1.Value);
                    if (courseActually != null)
                        MessageBox.Show("מורה לא פנוי בשעה זו");
                    else
                        saves();
                }
            else
                saves();
        }

         public void saves()

        {
            if (Minlesson())
            {
                IfTheory();


                if (checkBox1.Checked == true)
                {
                    saveDetails();
                    try
                    {
                        le.Add(la);
                        le.save();
                        MessageBox.Show("השיעור נקבע בהצלחה");
                    }
                    catch
                    {
                        MessageBox.Show("בעיה בקביעת השיעור");
                    }
                    this.Close();
                }
                else
                {
                    errorProvider1.SetError(checkBox1, "חייב בתשלום");
                    groupBox1.Visible = true;
                    //השמת מחיר שיעור בודד לסוג הרישיון
                    licencesTable = new Bll.licencesTable();
                    licences = licencesTable.GetList().FirstOrDefault(x => x.LicenceId == licencesStudent.LicenceId);
                    label10.Text = licences.PriceLesson.ToString();
                }
            }
            else
                this.Close();

        }
            public bool isEmpyt(string s)
            {
                return s.Equals("");
            }
            public void IfTheory()
            {
                if (licencesStudent.Theory == false)
                {
                if (Convert.ToInt32(textBox4.Text) < 8)
                {
                    DialogResult diar = MessageBox.Show(" אנא גש לתאוריה במהירות נשארו לך רק " + (8 - Convert.ToInt32(textBox4.Text)) + " שיעורים עד שלא תוכל להמשיך בלימוד הרישיון " + "האם ברצונך לקבוע את השיעור?", "שים לב", MessageBoxButtons.YesNo);
                    if (diar == DialogResult.No)
                        this.Close();
                }
                else
                {
                    MessageBox.Show("אין לך אפשרות לקבוע עוד שיעורים עד שתשלים את התאוריה");
                    this.Close();
                }
                }

            }
       


        public void saveDetails()
        {
            la.DateLesson = dateTimePicker1.Value;
            la.StudentId = student.StudentId;
            la.TecherId = teacher.TeacherId;
            la.Isglobal = checkBox1.Checked;
            la.TimeLesson = txtTime.Text;
            la.LicenseTostudentid = lt;
            
        }

        private void btnCencel_Click(object sender, EventArgs e)
        {
            le = new Bll.lessonActuallyTable();
            MessageBox.Show("שים לב השיעור יתבטל");
            le.Delete(la);
            MessageBox.Show("השיעור נחמק בהצלחה");
            this.Close();


        }
        private bool Minlesson()
        {
            int i =Convert.ToInt32( textBox4.Text);
            int f = licencesStudent.GetLicences().LessonMin;
            if(i>f)
            {
                DialogResult diar = MessageBox.Show("התלמיד עשה את מספר השיעורים המינמלי האם ברצונך להעבירו לטסט?", "הודעה", MessageBoxButtons.YesNo);
                if (diar == DialogResult.Yes)
                {
                    licencesStudent.Test = true;
                    new Bll.licencesStudentTable().Update(licencesStudent);
                    MessageBox.Show("התלמיד הוגש לטסט וגמר את לימודיו בהצלחה");
                    return false;
                }
            }
            return true;    
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            if (textBox1.Text=="" && textBox2.Text == "" && textBox3.Text == "")
            {
                errorProvider1.SetError(btnPay, "תשלום לא תקין");

            }
            else
            {
                saveDetails();
                try
                {
                    le.Add(la);
                    MessageBox.Show("השיעור נקבע בהצלחה");
                }
                catch
                {
                    MessageBox.Show("בעיה בקביעת השיעור");
                }
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmLessonActually_Load(object sender, EventArgs e)
        {

        }
    }
}

