﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmDD : DriveSchool.Form1
    {
        public frmDD()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmScedualeLesson f = new frmScedualeLesson();
            f.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmScheduleCourse f = new frmScheduleCourse();
            f.Show();
        }

        private void frmDD_Load(object sender, EventArgs e)
        {

        }
    }
}
