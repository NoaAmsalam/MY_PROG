﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmScheduleCourse : DriveSchool.Form1
    {
        Bll.courseActually courseActually;
        Bll.courseActuallyTable courseActuallyTable;
        Bll.teacher teacher;
        Bll.teachertable teachertable;
        Bll.student student;
        Bll.Course course;
        Bll.CourseTable courseTable;
        Bll.StudentCourseTable studentCourse;
        Bll.StudentCourseTable StudentCourseTable;

        public frmScheduleCourse()
        {
            InitializeComponent();
            dateTimePicker1.Value = DateTime.Today;
            button1.Visible = false;
            button2.Visible = true;
        }
        public frmScheduleCourse(Bll.student s)
        {
            InitializeComponent();
            dateTimePicker1.Value = DateTime.Today;
            student = s;
            button1.Visible = true;
            button2.Visible = false;

        }

        private void a0800_Click(object sender, EventArgs e)
        {

            //התוית שנבחרה
            Label l = (Label)sender;
            //פירוק השעה והשמה אותה בםקד מסוג סטרינג
            string ezer = l.Name;
            string time = ezer[1].ToString() + ezer[2].ToString() + ":" + ezer[3].ToString() + ezer[4].ToString();
            DateTime currentdate = new DateTime();
            switch (ezer[0])
            {
                case 'a':
                    currentdate = Convert.ToDateTime(a_date.Text);
                    break;
                case 'b':
                    currentdate = Convert.ToDateTime(b_date.Text);
                    break;
                case 'c':
                    currentdate = Convert.ToDateTime(c_date.Text);
                    break;
                case 'd':
                    currentdate = Convert.ToDateTime(d_date.Text);
                    break;
                case 'e':
                    currentdate = Convert.ToDateTime(c_date.Text);
                    break;

            }
            if (l.BackColor == Color.Transparent)
            {
                frmCourseActually f = new frmCourseActually(currentdate, time);
                f.Show();
            }

            else
            {
                groupBox1.Visible = true;
                courseActually = courseActuallyTable.GetList().FirstOrDefault(x => x.BeginningDate == Convert.ToDateTime(currentdate) && x.TimeCourse == time);
                fillGroupBox(courseActually);
            }

        }

        public void setDate()
        {
            DateTime date = dateTimePicker1.Value;
            //ראשון
            if (date.DayOfWeek.ToString() == "Sunday")
            {
                a_date.Text = date.ToShortDateString();
                b_date.Text = date.AddDays(1).ToShortDateString();
                c_date.Text = date.AddDays(2).ToShortDateString();
                d_date.Text = date.AddDays(3).ToShortDateString();
                e_date.Text = date.AddDays(4).ToShortDateString();

            }

            //שני
            if (date.DayOfWeek.ToString() == "Monday")
            {
                a_date.Text = date.AddDays(-1).ToShortDateString();
                b_date.Text = date.ToShortDateString();
                c_date.Text = date.AddDays(1).ToShortDateString();
                d_date.Text = date.AddDays(2).ToShortDateString();
                e_date.Text = date.AddDays(3).ToShortDateString();

            }
            //שלישי
            if (date.DayOfWeek.ToString() == "Tuesday")
            {
                a_date.Text = date.AddDays(-2).ToShortDateString();
                b_date.Text = date.AddDays(-1).ToShortDateString();
                c_date.Text = date.ToShortDateString();
                d_date.Text = date.AddDays(1).ToShortDateString();
                e_date.Text = date.AddDays(2).ToShortDateString();

            }
            //רביעי
            if (date.DayOfWeek.ToString() == "Wednesday")
            {
                a_date.Text = date.AddDays(-3).ToShortDateString();
                b_date.Text = date.AddDays(-2).ToShortDateString();
                c_date.Text = date.AddDays(-1).ToShortDateString();
                d_date.Text = date.ToShortDateString();
                e_date.Text = date.AddDays(1).ToShortDateString();


            }
            //חמישי
            if (date.DayOfWeek.ToString() == "Thursday")
            {
                a_date.Text = date.AddDays(-4).ToShortDateString();
                b_date.Text = date.AddDays(-3).ToShortDateString();
                c_date.Text = date.AddDays(-2).ToShortDateString();
                d_date.Text = date.AddDays(-1).ToShortDateString();
                e_date.Text = date.ToShortDateString();


            }
            //שישי
            if (date.DayOfWeek.ToString() == "Friday")
            {
                a_date.Text = date.AddDays(-5).ToShortDateString();
                b_date.Text = date.AddDays(-4).ToShortDateString();
                c_date.Text = date.AddDays(-3).ToShortDateString();
                d_date.Text = date.AddDays(-2).ToShortDateString();
                e_date.Text = date.AddDays(-1).ToShortDateString();
            }
            courseActuallyTable = new Bll.courseActuallyTable();
            var liy = courseActuallyTable.GetList();

            for (int i = 0; i < 5; i++)
            {
                switch (i)
                {
                    case 0:
                        liy = courseActuallyTable.GetList().Where(x => x.BeginningDate == Convert.ToDateTime(a_date.Text)).ToList();
                        foreach (var item in panel1.Controls)
                        {
                            if (item is Label)
                            {
                                Label l = (Label)item;
                                string ezer = l.Name;
                                string time = ezer[1].ToString() + ezer[2].ToString() + ":" + ezer[3].ToString() + ezer[4].ToString();
                                //חיפוש האם כבר משובצת השעה במורה ביום בנוכחי   `          
                                foreach (var course in liy)
                                {
                                    if (course.TimeCourse == time)
                                    {

                                        l.BackColor = Color.Red;
                                        l.Text = course.GetCourse().CourseName;
                                        l.Tag = course.CourseActuallyaId;
                                    }
                                }
                            }
                        }
                        break;
                    case 1:
                        liy = courseActuallyTable.GetList().Where(x => x.BeginningDate == Convert.ToDateTime(c_date.Text)).ToList();
                        foreach (var item in panel3.Controls)
                        {
                            if (item is Label)
                            {
                                Label l = (Label)item;
                                string ezer = l.Name;
                                string time = ezer[1].ToString() + ezer[2].ToString() + ":" + ezer[3].ToString() + ezer[4].ToString();
                                //חיפוש האם כבר משובצת השעה במורה ביום בנוכחי   `          
                                foreach (var course in liy)
                                {
                                    if (course.TimeCourse == time)
                                    {

                                        l.BackColor = Color.Red;
                                        l.Text = course.GetCourse().CourseName;
                                        l.Tag = course.CourseActuallyaId;
                                    }
                                }
                            }
                        }
                        break;
                    case 2:
                        liy = courseActuallyTable.GetList().Where(x => x.BeginningDate == Convert.ToDateTime(d_date.Text)).ToList();
                        foreach (var item in panel4.Controls)
                        {
                            if (item is Label)
                            {
                                Label l = (Label)item;
                                string ezer = l.Name;
                                string time = ezer[1].ToString() + ezer[2].ToString() + ":" + ezer[3].ToString() + ezer[4].ToString();
                                //חיפוש האם כבר משובצת השעה במורה ביום בנוכחי   `          
                                foreach (var course in liy)
                                {
                                    if (course.TimeCourse == time)
                                    {

                                        l.BackColor = Color.Red;
                                        l.Text = course.GetCourse().CourseName;
                                        l.Tag = course.CourseActuallyaId;
                                    }
                                }
                            }
                        }
                        break;
                    case 3:
                        liy = courseActuallyTable.GetList().Where(x => x.BeginningDate == Convert.ToDateTime(e_date.Text)).ToList();
                        foreach (var item in panel5.Controls)
                        {
                            if (item is Label)
                            {
                                Label l = (Label)item;
                                string ezer = l.Name;
                                string time = ezer[1].ToString() + ezer[2].ToString() + ":" + ezer[3].ToString() + ezer[4].ToString();
                                //חיפוש האם כבר משובצת השעה במורה ביום בנוכחי   `          
                                foreach (var course in liy)
                                {
                                    if (course.TimeCourse == time)
                                    {

                                        l.BackColor = Color.Red;
                                        l.Text = course.GetCourse().CourseName;
                                        l.Tag = course.CourseActuallyaId;
                                    }
                                }
                            }
                        }
                        break;
                    case 4:
                        liy = courseActuallyTable.GetList().Where(x => x.BeginningDate == Convert.ToDateTime(b_date.Text)).ToList();
                        foreach (var item in panel2.Controls)
                        {
                            if (item is Label)
                            {
                                Label l = (Label)item;
                                string ezer = l.Name;
                                string time = ezer[1].ToString() + ezer[2].ToString() + ":" + ezer[3].ToString() + ezer[4].ToString();
                                //חיפוש האם כבר משובצת השעה במורה ביום בנוכחי   `          
                                foreach (var course in liy)
                                {
                                    if (course.TimeCourse == time)
                                    {

                                        l.BackColor = Color.Red;
                                        l.Text = course.GetCourse().CourseName;
                                        l.Tag = course.CourseActuallyaId;
                                    }
                                }
                            }
                        }
                        break;
                }
            }
        }





            public void cl()
            {
                foreach (var item in panel1.Controls)
                {
                    if (item is Label)
                    {
                        Label l = (Label)item;
                        // if (l.BackColor != Color.Red)
                        {
                            l.BackColor = Color.Transparent;
                            l.BorderStyle = BorderStyle.None;
                            l.Text = "";
                        }
                    }
                }
            foreach (var item in panel3.Controls)
            {
                if (item is Label)
                {
                    Label l = (Label)item;
                    // if (l.BackColor != Color.Red)
                    {
                        l.BackColor = Color.Transparent;
                        l.BorderStyle = BorderStyle.None;
                        l.Text = "";
                    }
                }
            }
            foreach (var item in panel4.Controls)
            {
                if (item is Label)
                {
                    Label l = (Label)item;
                    // if (l.BackColor != Color.Red)
                    {
                        l.BackColor = Color.Transparent;
                        l.BorderStyle = BorderStyle.None;
                        l.Text = "";
                    }
                }
            }
            foreach (var item in panel5.Controls)
            {
                if (item is Label)
                {
                    Label l = (Label)item;
                    // if (l.BackColor != Color.Red)
                    {
                        l.BackColor = Color.Transparent;
                        l.BorderStyle = BorderStyle.None;
                        l.Text = "";
                    }
                }
            }
            foreach (var item in panel2.Controls)
            {
                if (item is Label)
                {
                    Label l = (Label)item;
                    // if (l.BackColor != Color.Red)
                    {
                        l.BackColor = Color.Transparent;
                        l.BorderStyle = BorderStyle.None;
                        l.Text = "";
                    }
                }
            }
        }

            private void dateTimePicker1_ValueChanged_1(object sender, EventArgs e)
            {
                groupBox1.Visible = false;
                cl();
                setDate();

            }
            private void a1200_DoubleClick(object sender, EventArgs e)
            {

            }
            public void fillGroupBox(Bll.courseActually ca)
            {
                StudentCourseTable = new Bll.StudentCourseTable();
                course = new Bll.Course();
                courseActually = ca;
                course = ca.GetCourse();
            //course = courseTable.GetList().FirstOrDefault(x => x.CourseId == courseActually.CourseId);
            label7.Text = courseActually.BeginningDate.ToShortDateString();//.ToString();
                lblname.Text = course.CourseName;
                int i = StudentCourseTable.GetList().Where(x => x.CourseActuallyId == courseActually.CourseActuallyaId).Count();

                lblroom.Text = courseActually.GetRoom().RoomName;
                lblprice.Text = course.CoursePrice.ToString();
                lblteacher.Text = courseActually.GetTeacher().ToString();
                lbltime.Text = courseActually.TimeCourse;
                lblplace.Text = ((course.StudentMax) - i).ToString();
                //lblplace.Text = (course.StudentMax - Count(ca)).ToString();

            }
            //פעולה שמחזירה את מספר התלמידים שנרשמו לקורס
            public int Count(Bll.courseActually c)
            {
                StudentCourseTable = new Bll.StudentCourseTable();
                return StudentCourseTable.GetList().Where(x => x.CourseActuallyId == c.CourseActuallyaId).Count();
            }

            private void frmScheduleCourse_Load(object sender, EventArgs e)
            {

            }

            private void button1_Click(object sender, EventArgs e)
            {
                frmStudentToCourse s = new frmStudentToCourse(student, courseActually);
                s.Show();
            }

            private void groupBox1_Enter(object sender, EventArgs e)
            {

            }

            private void button2_Click(object sender, EventArgs e)
            {
                frmStudentsCourse s = new frmStudentsCourse(courseActually);
                s.Show();

            }


        }
    }
