﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{

    public partial class frmlicenceStudent : Form
    {
        Bll.student student;
        Bll.studentTable studentTable;
        Bll.licencesStudent licencesStudent;
        Bll.licencesStudentTable licencesStudentTable;
        Bll.licences license;
         string state;


        public frmlicenceStudent(Bll.student s)
        {
            InitializeComponent();
            studentTable = new Bll.studentTable();
            student = s;
            state = "add";
            licencesStudent = new Bll.licencesStudent();
            licencesStudentTable = new Bll.licencesStudentTable();
            license = new Bll.licences();
            txtLicenceStudent.Text = student.ToString();
            //הצגת הנתונים בפקד הרשימה    
            Bll.licencesTable ct = new Bll.licencesTable();
            //הבאת גיל התלמיד כדי לסנן את הרשימה
            int i = Bll.Tkinut.GetAge(s.BirthDate);
            comboBox1.DataSource = ct.GetList().Where(x=> x.AgeMin < i).ToList();
            //הבאת מספור אוטומטי חדש
            licencesStudent.LicenceStudentId = licencesStudentTable.getnewkey();
            
        }
        public frmlicenceStudent(Bll.licencesStudent c)
        {
                InitializeComponent();
                state = "update";
                licencesStudent = c;
                licencesStudentTable = new Bll.licencesStudentTable();
                Bll.licencesTable ct = new Bll.licencesTable();
                int i = Bll.Tkinut.GetAge(c.GetStudent().BirthDate);
                comboBox1.DataSource = ct.GetList().Where(x => x.AgeMin < i).ToList();
                FillTextBox();
        }
            public void FillTextBox()
          {
            
            checkBox1.Checked = licencesStudent.Theory;
            txtLicenceStudent.Text = licencesStudent.GetStudent().ToString();
            if (licencesStudent.PayPackage == true)
                rdbglobal.Checked = true;
            else
                rdbLesson.Checked = true;
            //checkBox1.Visible = false;
            // textBox2.Visible = true;
            // textBox2.Text = licencesStudent.GetLicences().LicenceName; ;
            comboBox1.Enabled = false;
            comboBox1.Text = licencesStudent.GetLicences().LicenceName;
            Bll.licences l = (Bll.licences)comboBox1.SelectedItem;
            txtGlobal.Text = l.GlobalPrice.ToString();
            textBox1.Text = l.PriceLesson.ToString();
            label3.Text = l.LicenceName;
        }
        

        private void Button1_Click(object sender, EventArgs e)
        {
             if (state == "add")
                {
                 if (Check())
                {
                    try
                    {
                        licencesStudentTable.Add(licencesStudent);
                        MessageBox.Show("הרישיון נוסף בהצלחה");
                    }
                    catch
                    {
                        MessageBox.Show("בעיה בהוספת רישיון");
                    }
                    this.Close();
                }
                }
             if( state == "update")
                {
                updates();
                    try
                    {
                        licencesStudentTable.Update(licencesStudent);
                        MessageBox.Show("הרישיון עודכן בהצלחה");
                    }
                    catch
                    {
                        MessageBox.Show("בעיה בעדכון רישיון");
                    }
                this.Close();
                 }
        }
        public bool Check()
        {
             if (checkBox1.Checked == false)
                MessageBox.Show("שים לב שבלי תאוריה לא תוכל להשלים את תהליך קבלת הרישיון אנא השלם תאוריה במהירות והודע למערכת");
        
             // licencesStudent = new Bll.licencesStudent();
             licencesStudentTable = new Bll.licencesStudentTable();
             if (licencesStudentTable.GetList().FirstOrDefault(x => x.StudentId == student.StudentId && x.Test == false) == null)

                {

                licencesStudent.LicenceId = ((Bll.licences)comboBox1.SelectedItem).LicenceId;
                licencesStudent.Test = false;
                licencesStudent.StudentId = student.StudentId;
                licencesStudent.PayPackage = rdbglobal.Checked;
                licencesStudent.Theory = checkBox1.Checked;
                return true;

                }

            else
            {
                MessageBox.Show("לתלמיד יש רישיון פעיל");
                return false;
            }
        }
        public void updates()
        {
            licencesStudent.Theory = checkBox1.Checked;
            licencesStudent.PayPackage = rdbglobal.Checked;
        }
       
           

        private void FrmlicenceStudent_Load(object sender, EventArgs e)
        {

        }

        private void CheckBox2_CheckedChanged(object sender, EventArgs e)
        {
            
            
        }

        private void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
           

        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Bll.licences l = (Bll.licences)comboBox1.SelectedItem;
            txtGlobal.Text = l.GlobalPrice.ToString();
            textBox1.Text = l.PriceLesson.ToString();
            label3.Text = l.LicenceName;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmPay f = new frmPay(txtGlobal.Text);
            f.Show();
        }

        private void rdbLesson_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmLicences f = new frmLicences(false);
            f.Show();
        }

        private void frmlicenceStudent_Load_1(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        //private void Rdbglobal_CheckedChanged(object sender, EventArgs e)
        //{
        //    if (rdbLesson.Checked)
        //    {
        //        rdbglobal.Visible = false;
        //        txtGlobal.Visible = false;
        //        button2.Visible = false;
        //    }
        //    else
        //    {
        //        rdbLesson.Visible = true;
        //        txtGlobal.Visible = true;
        //        button2.Visible = true;
        //    }
        //}

        //private void RdbLesson_CheckedChanged(object sender, EventArgs e)
        //{
        //    if (rdbglobal.Checked)
        //    {
        //        rdbLesson.Visible = false;
        //        // txtGlobal.Text = ((License)comboBox1.SelectedItem).ToString();
        //    }
        //    else
        //        rdbLesson.Visible = true;
        //}
    }
}
