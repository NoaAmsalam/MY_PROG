﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmTeacherCourses : DriveSchool.Form1
    {
        Bll.teacher teacher;
        Bll.techerCourse techerCourse;
        Bll.techerCourseTable techerCourseTable;

        public frmTeacherCourses(Bll.teacher t)
        {
            InitializeComponent();
            teacher = t;
            textBox1.Text = t.ToString();
            techerCourse = new Bll.techerCourse();
            techerCourseTable = new Bll.techerCourseTable();
            dataGridView1.DataSource = techerCourseTable.GetList().Where(x => x.TeacherId == teacher.TeacherId).Select(x => new { x.TeacherId, x.GetCourse().CourseName, x.Drow }).ToList();
            ChangeHeaders();
        }
        public void ChangeHeaders()
        {
            dataGridView1.Columns["courseName"].HeaderText = "שם קורס";
            dataGridView1.Columns["teacherId"].Visible = false;
            dataGridView1.Columns["drow"].Visible = false;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            frmTeacherCourse f = new frmTeacherCourse(teacher);
            f.Show();
        }

        private void frmTeacherCourses_Load(object sender, EventArgs e)
        {

        }
    }
}




    

