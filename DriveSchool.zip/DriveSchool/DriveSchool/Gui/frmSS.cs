﻿using DriveSchool.Bll;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmSS : Form

    {
        Bll.studentTable studentTable;
        Bll.student s;
        public frmSS()
        {
            InitializeComponent();
            studentTable = new studentTable();
            s = new student();

        }
        licencesStudent l;
        private void button1_Click(object sender, EventArgs e)
        {
            if (s != null)
            {
                //  s = new student();
                if (ifLicence())
                {
                    frmScedualeLesson f = new frmScedualeLesson(s,l);
                    f.Show();
                }
                else
                    errorProvider1.SetError(label3, "לתלמיד אין רישיון פעיל");
            }

        }
        //פעולה שמחפשת רישיון פעיל לתלמיד שהוקש
    public bool ifLicence()
        {
           
            licencesStudentTable  c= new licencesStudentTable();
            if ((l=c.GetList().FirstOrDefault(x => x.StudentId == s.StudentId && x.Test == false)) != null)
                return true;
            return false;
        }

        

        private void button2_Click(object sender, EventArgs e)
        {
            frmScedualeLesson f = new frmScedualeLesson();
            f.Show();
        }

        private void Button2_Click_1(object sender, EventArgs e)
        {
            errorProvider1.Clear();
            s = studentTable.GetList().FirstOrDefault(x => x.StudentId == textBox1.Text);
            if (s != null)
            {
                label3.Text = s.ToString();
                label3.Visible = true;
            }
            else
                errorProvider1.SetError(textBox1 ,"תלמיד לא קיים");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (s != null)
            {
                
                    frmScheduleCourse f = new frmScheduleCourse(s);
                    f.Show();
                }
                
            }

        private void frmSS_Load(object sender, EventArgs e)
        {

        }
    }
    }

