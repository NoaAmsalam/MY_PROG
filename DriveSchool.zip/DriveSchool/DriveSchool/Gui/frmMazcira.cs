﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DriveSchool.Gui
{
    public partial class frmMazcira : DriveSchool.Form1
    {
        public frmMazcira()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmStudents s = new frmStudents();
            s.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmbeetwinSchedule s = new frmbeetwinSchedule();
            s.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmScheduleCourse f = new frmScheduleCourse();
            f.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmCoursesActually f = new frmCoursesActually();
            f.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            frmAdd f = new frmAdd(0);
            f.Show();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            frmAdd f = new frmAdd(1);
            f.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmAdd f = new frmAdd(2);
            f.Show();
        }

        private void frmMazcira_Load(object sender, EventArgs e)
        {

        }
    }
}
