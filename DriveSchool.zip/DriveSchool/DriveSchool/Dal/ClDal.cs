﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace DriveSchool.Dal
{
 public class ClsDal
    {
        private static OleDbConnection con;// כביש
        private static DataSet ds;// מחסן

        public ClsDal()// פעולה בונה-בניית הכביש והמחסן
        {
            //הגדרת היעד:1. התוכנה שאליה מתחבר הכביש 2.נתיב מסד הנתונים- תיקיית הפרויקט
            string path = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Application.StartupPath + @"\DriveSchool.mdb";

            con = new OleDbConnection(path);// בניית הכביש
            ds = new DataSet();//בניית המחסן
        }

        public static void AddTable(string tableName, string Keyname)
        {
            if (!ds.Tables.Contains(tableName))
            {
                OleDbDataAdapter adapter = new OleDbDataAdapter("select * from " + tableName + " order by " + Keyname, con);
                adapter.Fill(ds, tableName);
            }
        }
        public static DataTable GetTable(string tableName)
        {
            if (ds.Tables.Contains(tableName))
                return ds.Tables[tableName];
            else
                return null;
        }
        public static DataTable GetDisplayTable(string sqlstring)
        {
            DataTable dt = new DataTable();
            OleDbDataAdapter adapter = new OleDbDataAdapter(sqlstring, con);
            adapter.Fill(dt);
            return dt;

        }

        public static void Update(string tableName)
        {
            OleDbDataAdapter adapter = new OleDbDataAdapter("select * from " + tableName, con);
            OleDbCommandBuilder builder = new OleDbCommandBuilder(adapter);
            adapter.InsertCommand = builder.GetInsertCommand();
            adapter.UpdateCommand = builder.GetUpdateCommand();
            adapter.DeleteCommand = builder.GetDeleteCommand();
            adapter.Update(ds, tableName);
        }

        public static object ExecuteScalarQuery(string sqlStr)
        {
            OleDbCommand command = con.CreateCommand();
            command.CommandText = sqlStr;
            con.Open();
            object obj = command.ExecuteScalar();
            con.Close();
            return obj;
        }
    }
}
