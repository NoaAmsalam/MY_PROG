﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
   public class techerCourseTable : GeneralTable
    {
        public techerCourseTable() : base("techerCourse", "teacherId")
        {
            foreach (DataRow item in table.Rows)
            {
                list.Add(new techerCourse(item));
            }
        }
        public List<techerCourse> GetList()
        {
            return base.list.Cast<techerCourse>().ToList();
        }
    }
}
