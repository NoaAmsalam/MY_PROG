﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DriveSchool.Bll
{
    public class student : GeneralRow
    {

        //ת.ז. תלמיד
        private string studentId;

        public string StudentId
        {
            get { return studentId; }
            set {

                if (Tkinut.LegalId(value) == false)
                {
                    throw new Exception("תעודה הזהות אינה תקינה");
                }
                studentId = value; }
        }
        //שם פרטי של התלמיד
        private string studentFirstName;

        public string StudentFirstName
        {
            get { return studentFirstName; }
            set {
                if (value == " ")
                {
                    throw new Exception("לא הוזן ערך");
                }
                studentFirstName = value; }
        }
        //שם משפחה של התלמיד
        private string studentLastName;

        public string StudentLastName
        {
            get { return studentLastName; }
            set {
                if (value == "")
                {
                    throw new Exception("לא הוזן ערך");
                }
                studentLastName = value; }
        }

        private string street;
        //רחוב
        public string Street
        {
            get { return street; }
            set { street = value; }
        }
        //מספר בית
        private int num;

        public int Num
        {
            get { return num; }
            set
            {
                if (value <= 0)
                {
                    throw new Exception("מספר בית לא תקין");
                }
                num = value; }
        }
        //קוד עיר
        private int cityId;

        public int CityId
        {
            get { return cityId; }
            set { cityId = value; }
        }
        //טלפון
        private string phone;

        public string Phone
        {
            get { return phone; }
            set {
                if (Tkinut.IsCellPhone(value) == false)
                    throw new Exception("טלפון לא תקין"); phone = value; }
        }

        //הערות
        private string notes;

        public string Notes
        {
            get { return notes; }
            set { notes = value; }
        }
        //טופס ירוק - משתנה בוליאני
        private bool greenForm;

        public bool GreenForm
        {
            get { return greenForm; }
            set { greenForm = value; }
        }
        private DateTime birthDate;

        public DateTime BirthDate
        {
            get { return birthDate; }
            set { if (DateTime.Now.Year - value.Date.Year < 14)
                    throw new Exception("תלמיד קטן מידי");
                birthDate = value; }
        }

        // תאוריה - משתנה בוליאני
       




        public City GetCity()
        {
            CityTable ct = new CityTable();
            return ct.GetList().FirstOrDefault(x => x.CityId == cityId);
        }
        
        
        
        
        
        //בונה למופע חדש 
        public student ()
        {

        }
        //בניה מופע למלקה ע"פ שורה קיימת
        public student(DataRow dr)
        {
            drow = dr;
            FillFields();
        }
        public student(int studentId)
        {
            studentTable c = new studentTable();
            drow = c.Find(studentId);
            FillFields();
        }
        //פעולה מילוי התכונות /השדות מתוך הdrow 
        public override void FillFields()
        {
            studentId = drow["studentId"].ToString();
            studentFirstName = drow["studentFirstName"].ToString();
            studentLastName = drow["studentLastName"].ToString();
            street = drow["street"].ToString();
            Num = Convert.ToInt32(drow["Num"]);
            CityId =Convert.ToInt32(drow["CityId"]);
            Phone =drow["Phone"].ToString();
            Notes =drow["Notes"].ToString();
            birthDate = Convert.ToDateTime(drow["birthDate"]);
          
            greenForm = Convert.ToBoolean(drow["greenForm"]);


        }
        public override void FillDataRow()
        {
            drow["studentId"] = this.studentId;
            drow["studentFirstName"] = this.studentFirstName;
            drow["studentLastName"] = this.studentLastName;
            drow["street"] = this.street;
            drow["Num"] = this.Num;
            drow["CityId"] = this.CityId;
            drow["Phone"] = this.Phone;
            drow["Notes"] = this.Notes;
            drow["greenForm"] = this.greenForm;
           
            drow["birthDate"] = this.birthDate;
            
        }
        public override string ToString()
        {
            return this.studentFirstName + " " + this.studentLastName;
        }



    }
}
    
