﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace DriveSchool.Bll
{
   public class CityTable:GeneralTable
    {
        public CityTable():base("City","CityId")
        {
            foreach (DataRow item in table.Rows)
            {
                list.Add(new City(item));
            }
        }
        public List<City> GetList()
        {
            return base.list.Cast<City>().ToList();
        }

    }
}
