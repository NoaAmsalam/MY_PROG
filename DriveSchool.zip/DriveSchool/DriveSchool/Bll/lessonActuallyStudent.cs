﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
   public class lessonActuallyStudent : GeneralRow
    {
        //קוד שיעור אקטואלי
        private int lessonActuallyId;

        public int LessonActuallyId
        {
            get { return lessonActuallyId; }
            set { lessonActuallyId = value; }
        }

        //ת.ז. תלמיד
        private string studentId;

        public string StudentId
        {
            get { return studentId; }
            set { studentId = value; }
        }
        //האם מחיר גלובלי
        private bool isGlobalPayment;

        public bool IsGlobalPayment
        {
            get { return isGlobalPayment; }
            set { isGlobalPayment = value; }
        }
        //בונה למופע חדש 
        public lessonActuallyStudent()
        {

        }
        //בניה מופע למלקה ע"פ שורה קיימת
        public lessonActuallyStudent(DataRow dr)
        {
            drow = dr;
            FillFields();
        }
        public lessonActuallyStudent(int lessonActuallyId)
        {
            lessonActuallyStudentTable c = new lessonActuallyStudentTable();
            drow = c.Find(lessonActuallyId);
            FillFields();
        }
        //פעולה מילוי התכונות /השדות מתוך הdrow 
        public override void FillFields()
        {
            lessonActuallyId = Convert.ToInt32(drow["lessonActuallyId"]);
            studentId = drow["studentId"].ToString();
            isGlobalPayment = Convert.ToBoolean(drow["isGlobalPayment"]);
        }
        public override void FillDataRow()
        {
            drow["lessonActuallyId"] = this.lessonActuallyId;
            drow["studentId"] = this.studentId;
            drow["isGlobalPayment"] = this.isGlobalPayment;
        }
       
    }
}
