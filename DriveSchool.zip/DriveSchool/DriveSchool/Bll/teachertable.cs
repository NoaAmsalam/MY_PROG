﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
   public class teachertable : GeneralTable
    {
        public teachertable() : base("teachers", "teacherId")
        {
            foreach (DataRow item in table.Rows)
            {
                list.Add(new teacher(item));
            }
        }
        public List<teacher> GetList()
        {
            return base.list.Cast<teacher>().ToList();
        }

    }
}
