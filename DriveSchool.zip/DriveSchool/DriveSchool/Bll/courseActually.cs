﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
   public class courseActually : GeneralRow
    {
        //קוד קורס אקטואלי
        private int courseActuallyaId;

        public int CourseActuallyaId
        {
            get { return courseActuallyaId; }
            set { courseActuallyaId = value; }
        }
        //קוד סוג קורס
        private int courseId;

        public int CourseId
        {
            get { return courseId; }
            set { courseId = value; }
        }
        //ת.ז. מורה
        private string techerId;

        public string TecherId
        {
            get { return techerId; }
            set { techerId = value; }
        }

        //תאריך התחלה
        private DateTime beginningDate;

        public DateTime BeginningDate
        {
            get { return beginningDate; }
            set {
                beginningDate = value; }
        }

        //שעה
        private string timeCourse;

        public string TimeCourse
        {
            get { return timeCourse; }
            set { timeCourse = value; }
        }

        //חדר
        private int roomId;

        public int Roomid
        {
            get { return roomId; }
            set { roomId = value; }
        }

        //בונה למופע חדש 
        public courseActually()
        {

        }
        //בניה מופע למלקה ע"פ שורה קיימת
        public courseActually(DataRow dr)
        {
            drow = dr;
            FillFields();
        }
        public courseActually(DateTime d,  string tId, int coUrseAId, int cId, int rId, string time)
        {
            courseActuallyaId = coUrseAId;
            courseId = cId;
            roomId = rId;
            beginningDate = d;
            timeCourse = time;
            techerId = tId;
        }
        public courseActually(int courseActuallyaId)
        {
            courseActuallyTable c = new courseActuallyTable();
            drow = c.Find(courseActuallyaId);
            FillFields();
        }
        //פעולה מילוי התכונות /השדות מתוך הdrow 
        public override void FillFields()
        {
            courseActuallyaId = Convert.ToInt32(drow["courseActuallyaId"]);
            courseId = Convert.ToInt32(drow["courseId"]);
            roomId = Convert.ToInt32(drow["roomId"]);
            beginningDate = Convert.ToDateTime(drow["beginningDate"]);
            timeCourse = (drow["timeCourse"]).ToString();
            techerId = drow["techerId"].ToString();
        }
        public override void FillDataRow()
        {
            drow["courseActuallyaId"] = this.courseActuallyaId;
            drow["courseId"] = this.courseId;
            drow["techerId"] = this.techerId;
            drow["beginningDate"] = this.beginningDate;
            drow["timeCourse"] = this.timeCourse;
            drow["roomId"] = this.roomId;
        }
        public Course GetCourse()
        {
            CourseTable c = new CourseTable();
            return c.GetList().FirstOrDefault(x => x.CourseId == this.CourseId);
        }
        public teacher GetTeacher()
        {
            teachertable c = new teachertable();
            return c.GetList().FirstOrDefault(x => x.TeacherId == this.techerId);
        }
        public room GetRoom()
        {
            roomTable c = new roomTable();
            return c.GetList().FirstOrDefault(x => x.RoomId == this.roomId);
        }

    }
}
