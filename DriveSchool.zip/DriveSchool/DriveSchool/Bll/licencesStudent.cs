﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
   public class licencesStudent : GeneralRow
    {
        //קוד רישיון
        private int licenceId;

        public int LicenceId
        {
            get { return licenceId; }
            set { licenceId = value; }
        }
        //קוד תלמיד
        private string studentId;

        public string StudentId
        {
            get { return studentId; }
            set { studentId = value; }
        }
        //שילם חבילה?
        private bool payPackage;

        public bool PayPackage
        {
            get { return payPackage; }
            set { payPackage = value; }
        }

        //קיים תאוריה?
        private bool theory;

        public bool Theory
        {
            get { return theory; }
            set { theory = value;}
        }
        //קוד רישיוןלתלמיד
        private int licenceStudentId;

        public int LicenceStudentId
        {
            get { return licenceStudentId; }
            set { licenceStudentId = value; }
        }
        private bool test;

        public bool Test
        {
            get { return test; }
            set { test = value; }
        }


        public licencesStudent()
        {

        }
        //בניה מופע למלקה ע"פ שורה קיימת
        public licencesStudent(DataRow dr)
        {
            drow = dr;
            FillFields();
        }
        public licencesStudent(int studentId)
        {
            licencesStudentTable c = new licencesStudentTable();
            drow = c.Find(studentId);
            FillFields();
        }
        //פעולה מילוי התכונות /השדות מתוך הdrow 
        public override void FillFields()
        {
            licenceStudentId = Convert.ToInt32(drow["licenceStudentId"]);
            licenceId = Convert.ToInt32(drow["licenceId"]);
            studentId = drow["studentId"].ToString();
            payPackage = Convert.ToBoolean(drow["payPackage"]);
            test = Convert.ToBoolean(drow["test"]);
            theory = Convert.ToBoolean(drow["theory"]);

        }
        public override void FillDataRow()
        {
            drow["licenceStudentId"] = this.licenceStudentId;
            drow["studentId"] = this.studentId;
            drow["licenceId"] = this.licenceId;
            drow["theory"] = this.theory;
            drow["payPackage"] = this.payPackage;
            drow["test"] = this.test;
          
           
        }
        public List< licencesTeacher> GetLicencesTeacher()
        {
            licencesTeacherTable tt = new licencesTeacherTable();
            return tt.GetList().Where(x => x.LicenceId == this.licenceId).ToList ();
        }
        public student GetStudent()
        {
            studentTable ct = new studentTable();
            return ct.GetList().FirstOrDefault(x => x.StudentId == StudentId);
        }
        public licences GetLicences()
        {
            licencesTable c = new licencesTable();
            return c.GetList().FirstOrDefault(x => x.LicenceId == LicenceId);
        }
        public override string ToString()
        {
            return this.licenceId + studentId;
        }
    }
}

