﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace DriveSchool.Bll
{
  public abstract  class GeneralTable
    {
        //בניית משתנה מסוג clsDal
        protected static Dal.ClsDal add = new Dal.ClsDal();
        //הגדרת משתנה מסוג טבלה
        protected DataTable table;
        protected string tableName;
        protected string key;
        protected List<GeneralRow> list;

        public GeneralTable(string tableName, string key)
        {
            Dal.ClsDal.AddTable(tableName, key);
            this.table = Dal.ClsDal.GetTable(tableName);
            this.tableName = tableName;
            this.key = key;
            list = new List<GeneralRow>();
        }
        public DataTable GetDataTable()
        {
            return this.table;
        }

        public string getprimarrykey()
        {
            return this.key;
        }
        public bool isempty()
        {
            if (table.Rows.Count == 0)
            {
                return true;
            }
            return false;
        }
        public DataRow Find(string fieldname, object value)
        {
            foreach (DataRow row in table.Rows)
            {
                if (row[fieldname].Equals(value)||row[fieldname].ToString()==value.ToString())
                {
                    return row;
                }

            }
            return null;
        }
        public DataRow Find(object value)
        {
            return Find(this.key, value);
        }
        public void save()
        {
            try
            {
                Dal.ClsDal.Update(table.TableName);
            }

            catch (Exception)
            {

            }
        }
        public DataRow getnewrow()
        {
            return table.NewRow();
        }
        public void addrow(DataRow dr)
        {
            table.Rows.Add(dr);
            save();
        }
        public int getnewkey()
        {
            if (table.Rows.Count == 0)
                return 1;
            return Convert.ToInt32(table.Rows[table.Rows.Count - 1][key]) + 1;
        }
        public void Add(GeneralRow item)
        {
            list.Add(item);
            item.Drow = table.NewRow();
            item.FillDataRow();
            table.Rows.Add(item.Drow);
            save();

        }

        public void Update(GeneralRow item)
        {
            item.FillDataRow();
            save();
        }

        public void Delete(GeneralRow item)
        {
            list.Remove(item);
            item.Drow.Delete();
        }
    }
}
