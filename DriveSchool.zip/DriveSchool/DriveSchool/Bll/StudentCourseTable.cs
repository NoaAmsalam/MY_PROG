﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
    class StudentCourseTable : GeneralTable
    {
        public StudentCourseTable() : base("studentcourse", "studentId")
        {
            foreach (DataRow item in table.Rows)
            {
                list.Add(new StudentCourse(item));
            }
        }
        public List<StudentCourse> GetList()
        {
            return base.list.Cast<StudentCourse>().ToList();
        }
    }
}
