﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
  public  class licencesTeacher : GeneralRow
    {
        //קוד רישיון
        private int licenceId;

        public int LicenceId
        {
            get { return licenceId; }
            set { licenceId = value; }
        }
        //קוד מורה
        private string techerId;

        public string TecherId
        {
            get { return techerId; }
            set { techerId = value; }
        }
        public licencesTeacher()
        {

        }
        //בניה מופע למלקה ע"פ שורה קיימת
        public licencesTeacher(DataRow dr)
        {
            drow = dr;
            FillFields();
        }
        public licencesTeacher(int licenceId)
        {
            licencesTeacherTable c = new licencesTeacherTable();
            drow = c.Find(licenceId);
            FillFields();
        }
        //פעולה מילוי התכונות /השדות מתוך הdrow 
        public override void FillFields()
        {
            licenceId = Convert.ToInt32(drow["licenceId"]);
            techerId = drow["techerId"].ToString();
        }
        public override void FillDataRow()
        {
            drow["licenceId"] = this.licenceId;
            drow["techerId"] = this.techerId;
        }
        public teacher  getTeacher()
        {
            teachertable tt = new teachertable();
          return   tt.GetList().FirstOrDefault(x => x.TeacherId == this.techerId);
        }
        public licences GetLicences()
        {
            licencesTable lc = new licencesTable();
            return lc.GetList().FirstOrDefault(x => x.LicenceId == this.LicenceId);
        }

        public override string ToString()
        {
            return this.techerId + licenceId;
        }
    }
}
