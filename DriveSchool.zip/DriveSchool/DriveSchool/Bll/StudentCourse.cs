﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
    class StudentCourse : GeneralRow
    {
        //קוד קורס
        private int courseActuallyId;

        public int CourseActuallyId
        {
            get { return courseActuallyId; }
            set { courseActuallyId = value; }
        }
        //ת.ז. מורה
        private string studentId;

        public string StudentId
        {
            get { return studentId; }
            set { studentId = value; }
        }
        public StudentCourse()
        {

        }
        //בניה מופע למלקה ע"פ שורה קיימת
        public StudentCourse(DataRow dr)
        {
            drow = dr;
            FillFields();
        }
        public StudentCourse(int courseActuallyId)
        {
            StudentCourseTable c = new StudentCourseTable();
            drow = c.Find(courseActuallyId);
            FillFields();
        }
        //פעולה מילוי התכונות /השדות מתוך הdrow 
        public override void FillFields()
        {
            courseActuallyId = Convert.ToInt32(drow["courseActuallyId"]);
            studentId = drow["studentId"].ToString();
        }
        public override void FillDataRow()
        {
            drow["courseActuallyId"] = this.courseActuallyId;
            drow["studentId"] = this.studentId;
        }
        public student GetStudent()
        {
            studentTable s = new studentTable();
            return s.GetList().FirstOrDefault(x => x.StudentId == this.studentId);
        }

        public courseActually GetCourse()
        {
            courseActuallyTable s = new courseActuallyTable();
            return s.GetList().FirstOrDefault(x => x.CourseActuallyaId == this.courseActuallyId);
        }

        
        public override string ToString()
        {
            return this.studentId;
        }
    }
}

