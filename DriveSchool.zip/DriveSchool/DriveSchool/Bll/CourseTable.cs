﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
    public class CourseTable : GeneralTable
    {
        public CourseTable() : base("Course", "CourseId")
        {
            foreach (DataRow item in table.Rows)
            {
                list.Add(new Course(item));
            }
        }
        public List<Course> GetList()
        {
            return base.list.Cast<Course>().ToList();
        }
    }
}
