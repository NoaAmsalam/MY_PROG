﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
   public class teacher : GeneralRow
    {
        //ת.ז. מורה
        private string teacherId;

        public string TeacherId
        {
            get { return teacherId; }
            set {
                if (Tkinut.LegalId (value)==false)
                {throw new Exception("תעודה הזהות אינה תקינה"); }
                teacherId = value; }
        }
        //שם פרטי של המורה
        private string teacherFirstName;
        private string teacherlastname;

        public string TeacherFirstName
        {
            get { return teacherFirstName; }
            set
            {
                if (value == " ")
                {
                    throw new Exception("לא הוזן ערך");
                }
                teacherFirstName = value;
            }
        }
        //שם משפחה של המורה
        private string teacherLasttName;

        public string TeacherLasttName
        {
            get { return teacherLasttName; }
            set
            {
                if (value == "")
                {
                    throw new Exception("לא הוזן ערך");
                }
                teacherLasttName = value;
            }
        }

        private string street;
        //רחוב
        public string Street
        {
            get { return street; }
            set { street = value; }
        }
        //מספר בית
        private int num;

        public int Num
        {
            get { return num; }
            set
            {
                if (value <= 0)
                {
                    throw new Exception("מספר בית לא תקין");
                }
                num = value;
            }
        }
        //קוד עיר
        private int cityId;

        public int CityId
        {
            get { return cityId; }
            set { cityId = value; }
        }
        //טלפון
        private string phone;

        public string Phone
        {
            get { return phone; }
            set { if (Tkinut.IsCellPhone(value) == false)
                    throw new Exception("טלפון לא תקין");
                phone = value; }
        }

        //תאריך תחילת עבודה
        private DateTime startWorking;
     

        public DateTime StartWorking
        {
            get { return startWorking; }
            set { startWorking = value; }
        }
  
        public City GetCity()
        {
            CityTable ct = new CityTable();
            return ct.GetList().FirstOrDefault(x => x.CityId == cityId);
        }
        public List<licencesTeacher> GetLicencesTeachers()
        {
            licencesTeacherTable  tt= new licencesTeacherTable();
            return tt.GetList().Where<licencesTeacher>(x => x.TecherId == this.TeacherId).ToList();
        }
        public teacher()
        {

        }
        //בניה מופע למלקה ע"פ שורה קיימת
        public teacher(DataRow dr)
        {
            drow = dr;
            FillFields();
        }
        public teacher(string teacherId)
        {
            teachertable c = new teachertable();
            drow = c.Find(teacherId);
            FillFields();
        }
        //פעולה מילוי התכונות /השדות מתוך הdrow 
        public override void FillFields()
        {
            teacherId = drow["teacherId"].ToString();
            teacherFirstName = drow["teacherFirstName"].ToString();
            teacherLasttName = drow["teacherLastName"].ToString();
            street = drow["street"].ToString();
            Num = Convert.ToInt32(drow["Num"]);
            CityId = Convert.ToInt32(drow["CityId"]);
            Phone = drow["Phone"].ToString();
            startWorking = Convert.ToDateTime(drow["startWorking"]);

        }
        public override void FillDataRow()
        {
            drow["teacherId"] = this.teacherId;
            drow["teacherFirstName"] = this.teacherFirstName;
            drow["teacherLastName"] = this.teacherLasttName;
            drow["street"] = this.street;
            drow["Num"] = this.Num;
            drow["CityId"] = this.CityId;
            drow["Phone"] = this.Phone;
            drow["startWorking"] = this.startWorking;

        }
        public override string ToString()
        {
            return this.teacherFirstName + " " + this.teacherLasttName;
        }



    }
}
    





    
