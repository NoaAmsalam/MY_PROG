﻿using System.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
  public  class courseActuallyStudent : GeneralRow
    { //קוד קורס אקטואלי
        private int courseActuallyaId;

        public int CourseNcourseActuallyaId
        {
            get { return courseActuallyaId; }
            set { courseActuallyaId = value; }
        }
        //ת.ז. תלמיד
        private string studentId;

        public string StudentId
        {
            get { return studentId; }
            set { studentId = value; }
        }
        //תשלום איכשהוא
        //private bool payPackage;

        //public bool PayPackage
        //{
        //    get { return payPackage; }
        //    set { payPackage = value; }
        //}

        public courseActuallyStudent()
        {

        }
        //בניה מופע למלקה ע"פ שורה קיימת
        public courseActuallyStudent(DataRow dr)
        {
            drow = dr;
            FillFields();
        }
        public courseActuallyStudent(int courseActuallyaId)
        {
            courseActuallyStudentTable c = new courseActuallyStudentTable();
            drow = c.Find(courseActuallyaId);
            FillFields();
        }
        //פעולה מילוי התכונות /השדות מתוך הdrow 
        public override void FillFields()
        {
            courseActuallyaId = Convert.ToInt32(drow["courseActuallyaId"]);
            studentId = drow["studentId"].ToString();
           // payPackage = Convert.ToBoolean(drow["payPackage"]);
        }
        public override void FillDataRow()
        {
            drow["courseActuallyaId"] = this.courseActuallyaId;
            drow["studentId"] = this.studentId;
           // drow["payPackage"] = this.payPackage;
        }
        public override string ToString()
        {
            return this.courseActuallyaId + studentId;
        }
    }
}
