﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DriveSchool.Bll
{
    public class studentTable : GeneralTable
    {
        public studentTable() : base("students", "studentId")
        {
            foreach (DataRow item in table.Rows)
            {
                list.Add(new student(item));
            }
        }
        public List<student> GetList()
        {
             return base.list.Cast<student>().ToList();
        }
    }
}
