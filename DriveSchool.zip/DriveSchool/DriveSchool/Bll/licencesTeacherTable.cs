﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
  public  class licencesTeacherTable : GeneralTable
    {
        public licencesTeacherTable() : base("licencesTeacher", "licenceId")
        {
            foreach (DataRow item in table.Rows)
            {
                list.Add(new licencesTeacher(item));
            }
        }
        public List<licencesTeacher> GetList()
        {
            return base.list.Cast<licencesTeacher>().ToList();
        }
    }
}
