﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
    public class courseActuallyStudentTable : GeneralTable
    {
        public courseActuallyStudentTable() : base("courseActuallyStudent", "courseActuallyaId")
        {
            foreach (DataRow item in table.Rows)
            {
                list.Add(new courseActuallyStudent(item));
            }
        }
        public List<courseActuallyStudent> GetList()
        {
            return base.list.Cast<courseActuallyStudent>().ToList();
        }
    }
}

