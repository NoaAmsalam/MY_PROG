﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace DriveSchool.Bll
{
 public class City:GeneralRow
    {
        //הגדרת משתנים- ע"פ הטבלה באקסס
        private int cityId;

        public int CityId
        {
            get { return cityId; }
            set { cityId = value; }
        }
        private string cityName;

        public string CityName
        {
            get { return cityName; }
            set { if (value == "")
                    throw new Exception("שדה חובה");
                cityName = value; }
        }
        //בונה למופע חדש 
        public City()
        {

        }
        //בניה מופע למלקה ע"פ שורה קיימת
        public City(DataRow dr)
        {
            drow = dr;
            FillFields();
        }
        public City GetCity()
        {
            CityTable ct = new CityTable();
            return ct.GetList().FirstOrDefault(x => x.cityId == this.cityId); 
        }
        public City(int kodcity)
        {
            CityTable c = new CityTable();
            drow = c.Find(kodcity);
            FillFields();
        }
        //פעולה מילוי התכונות /השדות מתוך הdrow 
        public override void FillFields()
        {
            cityId =Convert.ToInt32(drow["CityId"]);
            cityName = drow["CityName"].ToString();
        }
        public override void FillDataRow()
        {
            drow["CityId"] = this.cityId;
            drow["CityName"] = this.cityName;
        }
        public override string ToString()
        {
            return  this.CityName;
        }



    }
}
