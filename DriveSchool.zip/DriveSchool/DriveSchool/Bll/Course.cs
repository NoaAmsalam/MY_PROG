﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
   public class Course : GeneralRow
    {
        //קוד קורס
        private int courseId;

        public int CourseId
        {
            get { return courseId; }
            set { courseId = value; }
        }
        //שם קורס
        private string courseName;

        public string CourseName
        {
            get { return courseName; }
            set
            {
                if (value == "")
                {
                    throw new Exception("ערך חובה");
                }
                courseName = value; }
        }
        //מספר שיעורים
        private int numLesson;


        //מספר תלמידים מינמלי
        private int studentMin;

        public int StudentMin
        {
            get { return studentMin; }
            set
            {
                if (value<=0)
                {
                    throw new Exception("מספר תלמידים מינמלי נמוך מהמותר");
                }
                studentMin = value; }
        }
        //מספר תלמידים מקסימלי
        private int studentMax;

        public int StudentMax
        {
            get { return studentMax; }
            set {
                if (value <= 0 || value < studentMin)

                    throw new Exception("מספר תלמידים מקסימלי נמוך מהמותר");
                
                studentMax = value; 
                }
        }
        //מחיר קורס
        private int coursePrice;

        public int CoursePrice
        {
            get { return coursePrice; }
            set {
                if (value <= 0)
                {
                    throw new Exception("מחיר נמוך מידי מהמותר");
                }
                coursePrice = value; }
        }




        //בונה למופע חדש 
        public Course()
        {

        }
        //בניה מופע למלקה ע"פ שורה קיימת
        public Course(DataRow dr)
        {
            drow = dr;
            FillFields();
        }
        public Course(int courseId)
        {
            CourseTable c = new CourseTable();
            drow = c.Find(courseId);
            FillFields();
        }
        //פעולה מילוי התכונות /השדות מתוך הdrow 
        public override void FillFields()
        {
            CourseId = Convert.ToInt32(drow["CourseId"]);
            courseName = drow["courseName"].ToString();
            studentMin = Convert.ToInt32(drow["studentMin"]);
            studentMax = Convert.ToInt32(drow["studentMax"]);
         
            coursePrice = Convert.ToInt32(drow["coursePrice"]);

        }
        public List<techerCourse> GetTecherCourses()
        {
            techerCourseTable tt = new techerCourseTable();
            return tt.GetList().Where(x => x.CourseId == this.courseId).ToList();

        }
        public override void FillDataRow()
        {
            drow["CourseId"] = this.CourseId;
            drow["courseName"] = this.courseName;
            drow["studentMin"] = this.studentMin;
            drow["studentMax"] = this.studentMax;
            drow["coursePrice"] = this.coursePrice;
            
        }
        public override string ToString()
        {
            return this.courseName;
        }
         



    }
}
    

