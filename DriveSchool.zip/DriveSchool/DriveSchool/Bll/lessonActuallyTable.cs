﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
   public class lessonActuallyTable : GeneralTable
    {
        public lessonActuallyTable() : base("lessonActually", "lessonActuallyId")
        {
            foreach (DataRow item in table.Rows)
            {
                list.Add(new lessonActually(item));
            }
        }
        public List<lessonActually> GetList()
        {
            return base.list.Cast<lessonActually>().ToList();
        }
    }
}
