﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
  public class courseActuallyTable : GeneralTable
    {
        public courseActuallyTable() : base("courseActually", "courseActuallyaId")
        {
            foreach (DataRow item in table.Rows)
            {
                list.Add(new courseActually(item));
            }
        }
        public List<courseActually> GetList()
        {
            return base.list.Cast<courseActually>().ToList();
        }
    }
}
