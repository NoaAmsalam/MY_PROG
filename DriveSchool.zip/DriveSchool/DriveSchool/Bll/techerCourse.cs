﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
   public class techerCourse : GeneralRow
    {
        //קוד קורס
        private int courseId;

        public int CourseId
        {
            get { return courseId; }
            set { courseId = value; }
        }
        //ת.ז. מורה
        private string teacherId;

        public string TeacherId
        {
            get { return teacherId; }
            set { teacherId = value; }
        }
        public techerCourse()
        {

        }
        //בניה מופע למלקה ע"פ שורה קיימת
        public techerCourse(DataRow dr)
        {
            drow = dr;
            FillFields();
        }
        public techerCourse(int courseId)
        {
            techerCourseTable c = new techerCourseTable();
            drow = c.Find(courseId);
            FillFields();
        }
        //פעולה מילוי התכונות /השדות מתוך הdrow 
        public override void FillFields()
        {
            courseId = Convert.ToInt32(drow["courseId"]);
            teacherId = drow["teacherId"].ToString();
        }
        public override void FillDataRow()
        {
            drow["courseId"] = this.courseId;
            drow["teacherId"] = this.teacherId;
        }
        public Course GetCourse()
        {
            CourseTable lc = new CourseTable();
            return lc.GetList().FirstOrDefault(x => x.CourseId == this.courseId);
        }
        public teacher GetTeacher()
        {
            teachertable lc = new teachertable();
            return lc.GetList().FirstOrDefault(x => x.TeacherId == this.teacherId);
        }
        public override string ToString()
        {
            return this.teacherId + courseId;
        }
    }
}
