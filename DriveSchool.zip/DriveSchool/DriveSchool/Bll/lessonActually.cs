﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
   public class lessonActually : GeneralRow
    {
        //קוד שיעור אקטואלי
        private int lessonActuallyId;

        public int LessonActuallyId
        {
            get { return lessonActuallyId; }
            set { lessonActuallyId = value; }
        }

        //קוד שיעור
        private int licenseTostudentid;

        public int LicenseTostudentid
        {
            get { return licenseTostudentid; }
            set { licenseTostudentid = value; }
        }


        //public lesson GetLesson()
        //{
        //    Bll.lessonTable lt = new lessonTable();
        //    return lt.GetList().FirstOrDefault(x => x.Lessonid == this.lessonid);
        //}
        //ת.ז. מורה
        private string techerId;

        public string TecherId
        {
            get { return techerId; }
            set { techerId = value; }
        }
        public teacher GetTeacher()
        {
            Bll.teachertable lt = new teachertable();
            return lt.GetList().FirstOrDefault(x => x.TeacherId == this.techerId );
        }

        private string studentId;
        //ת.ז. תלמיד
        public string StudentId
        {
            get { return studentId; }
            set { studentId = value; }
        }
        public student GetStudent()
        {
            Bll.studentTable lt = new studentTable();
            return lt.GetList().FirstOrDefault(x => x.StudentId == this.studentId);
        }
        //תאריך שיעור
        private DateTime dateLesson;

        public DateTime DateLesson
        {
            get { return dateLesson; }
            set {
                //if (value > DateTime.Today)
                //    throw new Exception("תאריך לא רלוונטי");
                dateLesson = value; }
        }
        //שעת שיעור
        private string timeLesson;

        public string TimeLesson
        {
            get { return timeLesson; }
            set { timeLesson = value; }
        }
        private bool isglobal;

        public bool Isglobal
        {
            get { return isglobal; }
            set { isglobal = value; }
        }

        //בונה למופע חדש 
        public lessonActually()
        {

        }
        //בניה מופע למלקה ע"פ שורה קיימת
        public lessonActually(DataRow dr)
        {
            drow = dr;
            FillFields();
        }
        public lessonActually(int lessonActuallyId)
        {
            lessonActuallyTable c = new lessonActuallyTable();
            drow = c.Find(lessonActuallyId);
            FillFields();
        }
        //פעולה מילוי התכונות /השדות מתוך הdrow 
        public override void FillFields()
        {
            lessonActuallyId = Convert.ToInt32(drow["lessonActuallyId"]);
            licenseTostudentid = Convert.ToInt32(drow["licenseTostudentid"]);
            timeLesson =drow["timeLesson"].ToString();
            dateLesson = Convert.ToDateTime(drow["dateLesson"]);
            isglobal = Convert.ToBoolean(drow["isglobal"]);
            techerId = drow["TecherId"].ToString();
            studentId = drow["studentId"].ToString();
        }
        public override void FillDataRow()
        {
            drow["lessonActuallyId"] = this.lessonActuallyId;
            drow["licenseTostudentid"] = this.LicenseTostudentid;
            drow["isglobal"] = this.isglobal;
            drow["timeLesson"] = this.timeLesson;
            drow["dateLesson"] = this.dateLesson;
            drow["TecherId"] = this.techerId;
            drow["studentId"] = this.studentId;
        }
        public teacher getTeacher()
        {
            teachertable tt = new teachertable();
            return tt.GetList().FirstOrDefault(x => x.TeacherId == this.techerId);
        }
        public licencesStudent GetLicences()
        {
            licencesStudentTable tt = new licencesStudentTable();
            return tt.GetList().FirstOrDefault(x => x.LicenceStudentId == this.licenseTostudentid);
        }
        public student getStudent()
        {
            studentTable t = new studentTable();
            return t.GetList().FirstOrDefault(x => x.StudentId == this.studentId);
        }

    }
}
