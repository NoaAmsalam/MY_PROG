﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
   public class lesson : GeneralRow
    {
        //קוד שיעור
        private int lessonid;

        public int Lessonid
        {
            get { return lessonid; }
            set { lessonid = value; }
        }

        //שם שיעור
        private string lessonName;

        public string LessonName
        {
            get { return lessonName; }
            set {if (value == "")
                    throw new Exception("שדה חובה");
                lessonName = value; }
        }

        //קוד רישיון
        private int licenceId;

        public int LicenceId
        {
            get { return licenceId; }
            set { licenceId = value; }
        }
        public licences GetLicences()
        {
            licencesTable lc = new licencesTable();
            return lc.GetList().FirstOrDefault(x => x.LicenceId == this.licenceId);
        }

        //מספר תלמידים מינמלי
        private int studentMin;

        public int StudentMin
        {
            get { return studentMin; }
            set
            {
                if (value <= 0)
                {
                    throw new Exception("מספר תלמידים מינמלי נמוך מהמותר");
                }
                studentMin = value; }
        }

        //מספר תלמידים מקסימלי
        private int studentMax;

        public int StudentMax
        {
            get { return studentMin; }
            set
            {
                if (value <= 0)
                {
                    throw new Exception("מספר תלמידים מקסימלי נמוך מהמותר");
                }
                studentMin = value; }
        }
        //אורך שיעור בדקות
        private int lessonLength;

        public int LessonLength
        {
            get { return lessonLength; }
            set { if (value <= 0)
                    throw new Exception("אורך שיעור לא תקין");
                lessonLength = value; }
        }
        //בונה למופע חדש 
        public lesson()
        {

        }
        //בניה מופע למלקה ע"פ שורה קיימת
        public lesson(DataRow dr)
        {
            drow = dr;
            FillFields();
        }
        public lesson(int Lessonid)
        {
            lessonTable c = new lessonTable();
            drow = c.Find(Lessonid);
            FillFields();
        }
        //פעולה מילוי התכונות /השדות מתוך הdrow 
        public override void FillFields()
        {
            Lessonid = Convert.ToInt32(drow["Lessonid"]);
            licenceId = Convert.ToInt32(drow["licenceId"]);
            studentMin = Convert.ToInt32(drow["studentMin"]);
            studentMax = Convert.ToInt32(drow["studentMax"]);
            lessonLength = Convert.ToInt32(drow["lessonLength"]);
            lessonName = drow["lessonName"].ToString();
        }
        public override void FillDataRow()
        {
            drow["Lessonid"] = this.Lessonid;
            drow["licenceId"] = this.licenceId;
            drow["studentMin"] = this.studentMin;
            drow["studentMax"] = this.studentMax;
            drow["lessonLength"] = this.lessonLength;
            drow["lessonName"] = this.lessonName;
        }
        public override string ToString()
        {
            return this.lessonName;
        }

    }
}
