﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
   public class room: GeneralRow
    {
        //קוד חדר
        private int roomId;

        public int RoomId
        {
            get { return roomId; }
            set { roomId = value; }
        }
        //שם חדר
        private string roomName;

        public string RoomName
        {
            get { return roomName; }
            set {if (value == "")
                    throw new Exception("שדה חובה");
                roomName = value; }
        }
        //כמות תפוסה
        private int amount;

        public int Amount
        {
            get { return amount; }
            set {
                if (value <= 0)
                    throw new Exception("כמות לא תיקנית");
                    amount = value; }
        }
        //בונה למופע חדש 
        public room()
        {

        }
        //בניה מופע למלקה ע"פ שורה קיימת
        public room(DataRow dr)
        {
            drow = dr;
            FillFields();
        }
        public room(int roomId)
        {
            roomTable c = new roomTable();
            drow = c.Find(roomId);
            FillFields();
        }
        //פעולה מילוי התכונות /השדות מתוך הdrow 
        public override void FillFields()
        {
            roomId = Convert.ToInt32(drow["roomId"]);
            amount = Convert.ToInt32(drow["amount"]);
            roomName = drow["roomName"].ToString();
        }
        public override void FillDataRow()
        {
            drow["roomId"] = this.roomId;
            drow["roomName"] = this.roomName;
            drow["amount"] = this.amount;
        }
        public override string ToString()
        {
            return this.roomName;
        }



    }
}


    

