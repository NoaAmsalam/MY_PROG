﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
   public class roomTable : GeneralTable
    {
        public roomTable() : base("rooms", "roomId")
        {
            foreach (DataRow item in table.Rows)
            {
                list.Add(new room(item));
            }
        }
        public List<room> GetList()
        {
            return base.list.Cast<room>().ToList();
        }
    }
}
