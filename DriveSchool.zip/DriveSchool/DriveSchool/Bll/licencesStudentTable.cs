﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
   public class licencesStudentTable : GeneralTable
    {
        public licencesStudentTable() : base("licencesStudent", "licenceStudentId")
        {
            foreach (DataRow item in table.Rows)
            {
                list.Add(new licencesStudent(item));
            }
        }
        public List<licencesStudent> GetList()
        {
            return base.list.Cast<licencesStudent>().ToList();
        }
    }
}
