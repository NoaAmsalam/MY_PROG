﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
   public class licences : GeneralRow
    {
        //קוד רישיון
        private int licenceId;

        public int LicenceId
        {
            get { return licenceId; }
            set { licenceId = value; }
        }
        //שם רישיון
        private string licenceName;

        public string LicenceName
        {
            get { return licenceName; }
            set {
                if (value == "")
                    throw new Exception("שדה חובה");
                licenceName = value; }
        }
        //מספר שיעורים מינמלי
        private int lessonMin;

        public int LessonMin
        {
            get { return lessonMin; }
            set {
                if (value <= 0)
                    throw new Exception("כמות לא תיקנית"); 
                lessonMin = value; }
        }

        //גיל מינמלי
        private double ageMin;

        public double AgeMin
        {
            get { return ageMin; }
            set { ageMin = value; }
        }
        //מחיר שיעור בודד
        private int priceLesson;

        public int PriceLesson
        {
            get { return priceLesson; }
            set {
                if (value <= 0)
                    throw new Exception(" מחיר לא תיקני");
                priceLesson = value; }
        }

        //מחיר גלובלי
        private int globalPrice;

        public int GlobalPrice
        {
            get { return globalPrice; }
            set {
                if (value <= 0)
                    throw new Exception(" מחיר לא תיקני");
                globalPrice = value; }
        }


        //בונה למופע חדש 
        public licences()
        {
        }
        //בניה מופע למלקה ע"פ שורה קיימת
        public licences(DataRow dr)
        {
            drow = dr;
            FillFields();
        }
        public licences(int licenceId)
        {
            CityTable c = new CityTable();
            drow = c.Find(licenceId);
            FillFields();
        }
        //פעולה מילוי התכונות /השדות מתוך הdrow 
        public override void FillFields()
        {
            licenceId = Convert.ToInt32(drow["licenceId"]);
            LessonMin = Convert.ToInt32(drow["LessonMin"]);
            ageMin = Convert.ToDouble(drow["ageMin"]);
            licenceName = drow["licenceName"].ToString();
            priceLesson = Convert.ToInt32(drow["priceLesson"]);
            globalPrice = Convert.ToInt32(drow["globalPrice"]);

        }
        public override void FillDataRow()
        {
            drow["licenceId"] = this.licenceId;
            drow["licenceName"] = this.licenceName;
            drow["LessonMin"] = this.LessonMin;
            drow["ageMin"] = this.ageMin;
            drow["globalPrice"] = this.globalPrice;
            drow["priceLesson"] = this.priceLesson;
        }
         public List <licencesTeacher> GetLicencesTeacher()
        {
            licencesTeacherTable tt = new licencesTeacherTable();
            return tt.GetList().Where(x => x.LicenceId == this.licenceId).ToList ();

        }
        public licences GetLicences()
        {
            licencesTable kt = new licencesTable();
            return kt.GetList().FirstOrDefault(x => x.LicenceId == this.licenceId);
        }
      
        public override string ToString()
        {
            return this.licenceName;
        }






    }
}
   
