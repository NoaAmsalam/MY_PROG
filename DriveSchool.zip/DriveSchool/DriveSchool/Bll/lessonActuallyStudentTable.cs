﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
    public class lessonActuallyStudentTable : GeneralTable
    {
        public lessonActuallyStudentTable() : base("lessonActuallyStudent", "lessonActuallyId")
        {
            foreach (DataRow item in table.Rows)
            {
                list.Add(new lessonActuallyStudent(item));
            }
        }
        public List<lessonActuallyStudent> GetList()
        {
            return base.list.Cast<lessonActuallyStudent>().ToList();
        }
    }
}
