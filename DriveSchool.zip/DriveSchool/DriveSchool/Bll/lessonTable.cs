﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DriveSchool.Bll
{
   public class lessonTable : GeneralTable
    {
        public lessonTable() : base("Lesson", "Lessonid")
        {
            foreach (DataRow item in table.Rows)
            {
                list.Add(new lesson(item));
            }
        }
        public List<lesson> GetList()
        {
            return base.list.Cast<lesson>().ToList();
        }
    }
}
